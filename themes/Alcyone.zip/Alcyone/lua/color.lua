local colors = {

    Text = 0xFFFFFF,
    Text1 = 0x302E2E,
    Accent = 0xE01B24,

}

return colors
