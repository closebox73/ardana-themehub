local colors = {

    Text = 0xFFFFFF,
    Accent1 = 0xF66151,
    Accent2 = 0xF5C211,
    Accent3 = 0x26A269,
    Accent4 = 0x1C71D8,

}

return colors
