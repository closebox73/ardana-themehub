-- =====================================================
-- Ardana Theme Coordinator
-- =====================================================
--
-- color.lua   -> hot reload
-- scale.lua   -> startup only
-- providers   -> shared Ardana providers
-- renderers   -> auto loaded from current folder
--
-- =====================================================

local M = {}

require(
    "cairo"
)

pcall(
    require,
    "cairo_xlib"
)

-- =====================================================
-- Paths
-- =====================================================

local BASE =
    debug.getinfo(
        1,
        "S"
    ).source:sub(
        2
    ):match(
        "(.*/)"
    )

-- Parent lua directory
--
-- Example:
-- BASE
-- ~/.config/Ardana/themes/Thuban/lua/Thuban/
--
-- THEME_LUA
-- ~/.config/Ardana/themes/Thuban/lua/
--
local THEME_LUA =
    BASE:match(
        "(.*/)[^/]+/$"
    )

local PROVIDER_DIR =
    os.getenv(
        "HOME"
    ) ..
    "/.config/Ardana/providers/"

-- =====================================================
-- State
-- =====================================================

local colors = {}
local scale = {}

local providers = {}

local color_mtime = 0

local renderers = {}

-- =====================================================
-- File Modification Time
-- =====================================================

local function get_mtime(
    path
)

    local f =
        io.popen(
            "stat -c %Y " ..
            string.format(
                "%q",
                path
            ) ..
            " 2>/dev/null"
        )

    if not f then
        return nil
    end

    local mtime =
        tonumber(
            f:read(
                "*a"
            )
        )

    f:close()

    return mtime

end

-- =====================================================
-- Color Loader
-- =====================================================

local function load_colors()

    local path =
        THEME_LUA ..
        "color.lua"

    local ok,
        result =
        pcall(
            dofile,
            path
        )

    if not ok then

        print(
            "[Ardana] Failed to load color.lua:",
            result
        )

        return false

    end

    if type(
        result
    ) ~= "table" then

        print(
            "[Ardana] Invalid color.lua"
        )

        return false

    end

    colors =
        result

    return true

end

-- =====================================================
-- Color Hot Reload
-- =====================================================

local function check_color_changes()

    local path =
        THEME_LUA ..
        "color.lua"

    local mtime =
        get_mtime(
            path
        )

    if not mtime then
        return
    end

    if mtime ~= color_mtime then

        color_mtime =
            mtime

        if load_colors() then

            print(
                "[Ardana] Color reloaded."
            )

        end

    end

end

-- =====================================================
-- Scale Loader
-- =====================================================

local function load_scale()

    local path =
        THEME_LUA ..
        "scale.lua"

    local ok,
        result =
        pcall(
            dofile,
            path
        )

    if not ok then

        print(
            "[Ardana] Failed to load scale.lua:",
            result
        )

        return false

    end

    if type(
        result
    ) ~= "table" then

        print(
            "[Ardana] Invalid scale.lua"
        )

        return false

    end

    scale =
        result

    return true

end

-- =====================================================
-- Provider Loader
-- =====================================================

local function load_provider(
    name
)

    local path =
        PROVIDER_DIR ..
        name ..
        ".lua"

    local ok,
        provider =
        pcall(
            dofile,
            path
        )

    if not ok then

        print(
            "[Ardana] Failed to load provider:",
            name
        )

        print(
            provider
        )

        return nil

    end

    if type(
        provider
    ) ~= "table" then

        print(
            "[Ardana] Invalid provider:",
            name
        )

        return nil

    end

    return provider

end

-- =====================================================
-- Provider Update
-- =====================================================

local function update_providers()

    for name,
        provider
        in pairs(
            providers
        ) do

        if provider
            and type(
                provider.update
            ) == "function" then

            local ok,
                err =
                pcall(
                    provider.update
                )

            if not ok then

                print(
                    "[Ardana] Provider update failed:",
                    name,
                    err
                )

            end

        end

    end

end

-- =====================================================
-- Renderer Loader
-- =====================================================

local function load_renderers()

    local pipe =
        io.popen(
            "find " ..
            string.format(
                "%q",
                BASE
            ) ..
            " -maxdepth 1 -type f -name '*.lua' -printf '%f\n' | sort"
        )

    if not pipe then

        print(
            "[Ardana] Failed to scan renderers."
        )

        return

    end

    for filename in pipe:lines() do

        -- Skip coordinator
        if filename ~= "main.lua" then

            local path =
                BASE ..
                filename

            local ok,
                renderer =
                pcall(
                    dofile,
                    path
                )

            if ok
                and type(
                    renderer
                ) == "table"
                and type(
                    renderer.draw
                ) == "function" then

                table.insert(
                    renderers,
                    renderer
                )

            else

                print(
                    "[Ardana] Invalid renderer:",
                    filename
                )

            end

        end

    end

    pipe:close()

end

-- =====================================================
-- Initial Load
-- =====================================================

load_colors()
load_scale()

color_mtime =
    get_mtime(
        THEME_LUA ..
        "color.lua"
    )
    or 0

-- Shared Providers
providers.time =
    load_provider(
        "time"
    )

providers.weather =
    load_provider(
        "weather"
    )

-- Theme Renderers
load_renderers()

-- =====================================================
-- Public State
-- =====================================================

M.colors =
    colors

M.scale =
    scale

M.providers =
    providers

-- =====================================================
-- Draw
-- =====================================================

function M.draw(
    ctx
)

    -- Hot reload colors
    check_color_changes()

    -- Update providers
    update_providers()

    -- Refresh public state
    M.colors =
        colors

    M.scale =
        scale

    M.providers =
        providers

    -- Draw all renderers
    for _,
        renderer
        in ipairs(
            renderers
        ) do

        renderer.draw(
            ctx,
            M
        )

    end

end

-- =====================================================
-- Conky Hook
-- =====================================================

function conky_draw_main()
    if not conky_window then
        return
    end

    local surface =
        cairo_xlib_surface_create(
            conky_window.display,
            conky_window.drawable,
            conky_window.visual,
            conky_window.width,
            conky_window.height
        )

    local ctx =
        cairo_create(
            surface
        )

    M.draw(
        ctx
    )

    cairo_destroy(
        ctx
    )

    cairo_surface_destroy(
        surface
    )
end

return M
