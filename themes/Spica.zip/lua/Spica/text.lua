-- =====================================================
-- Text Renderer
-- =====================================================
--
-- Universal text renderer for Ardana themes.
--
-- Supports unlimited text fields with individual settings
-- for font, size, position, alignment, style, and color.
--
-- The `text` field supports both static values and dynamic
-- functions, allowing renderers to display data from Conky
-- variables, providers, or any value exposed by the theme
-- coordinator.
--
-- Examples:
--
-- Static / Conky text:
--     text = conky_parse("${time %H:%M}")
--
-- Dynamic provider data:
--     text = function(theme)
--         return theme.player.title
--     end
--
-- Dynamic fallback:
--     text = function(theme)
--         if not theme.player.available then
--             return "No media played"
--         end
--
--         return theme.player.title
--     end
--
-- This makes the renderer reusable with any provider
-- without requiring changes to the renderer itself.
--
-- =====================================================

local M = {}

-- =====================================================
-- Text Settings
-- =====================================================

local text_settings = {

    {
        text = function(theme)
            return os.date("%d")
        end,

        font_name = "Roboto Condensed",
        font_size = 92,

        h_align = "l",
        v_align = "t",

        bold = true,

        x = 0,
        y = 13,

        colour = {
            {1, "Text", 1}
        }
    },

    {
        text = function(theme)

            local weather =
                theme.providers.weather.get()

            local description =
                weather.description or ""

            if #description > 0 then

                description =
                    description:sub(1, 1):upper()
                    .. description:sub(2)

            end

            return string.format(
                "Welcome back! Today the weather in %s is %s",
                weather.city or "",
                description
            )

        end,

        font_name = "Roboto Condensed",
        font_size = 14.5,

        h_align = "l",
        v_align = "t",

        bold = false,

        x = 4,
        y = 100,

        colour = {
            {1, "Text", 1}
        }
    },

    {
        text = function(theme)

            local weather =
                theme.providers.weather.get()

            return string.format(
                "with temp %s, Wind speed %s and Humidity %d%%",
                weather.temperature_text or "",
                weather.wind_speed_text or "",
                weather.humidity or 0
            )

        end,

        font_name = "Roboto Condensed",
        font_size = 14.5,

        h_align = "l",
        v_align = "t",

        bold = false,

        x = 4,
        y = 120,

        colour = {
            {1, "Text", 1}
        }
    },

    {
        text = function(theme)
            return os.date("%B"):upper()
        end,

        font_name = "Roboto Condensed",
        font_size = 92,

        h_align = "r",
        v_align = "t",

        bold = true,

        x = 470,
        y = 155,

        colour = {
            {1, "Text", 1}
        }
    },

    -- =================================================
    -- Date
    -- =================================================

    {
        text = function(theme)

            local day =
                os.date("%A"):upper()

            local result = ""

            for i = 1, #day do

                if i > 1 then
                    result =
                        result .. "  "
                end

                result =
                    result
                    .. day:sub(i, i)

            end

            return result

        end,

        font_name = "Quicksand",
        font_size = 26,

        h_align = "r",
        v_align = "t",

        bold = true,

        x = 470,
        y = 235,

        colour = {
            {1, "Text", 1}
        }
    },

    {
        text = function(theme)

            local time =
                theme.providers.time.get()

            if time.format == "12" then

                return string.format(
                    "-- %02d : %02d %s --",
                    time.hour12,
                    time.minute,
                    time.am_pm
                )

            end

            return string.format(
                "-- %02d : %02d --",
                time.hour,
                time.minute
            )

        end,

        font_name = "Roboto Condensed",
        font_size = 16,

        h_align = "r",
        v_align = "t",

        bold = true,

        x = 470,
        y = 268,

        colour = {
            {1, "Text", 1}
        }
    },

}

-- =====================================================
-- Color
-- =====================================================

local function resolve_color(
    color_name,
    colors
)

    if type(color_name) == "number" then
        return color_name
    end

    if type(color_name) == "string" then

        return colors[color_name]
            or colors.Text
            or 0xffffff

    end

    return 0xffffff

end

-- =====================================================
-- RGBA
-- =====================================================

local function color_to_rgba(
    color,
    alpha
)

    return
        ((color / 0x10000) % 0x100) / 255,
        ((color / 0x100) % 0x100) / 255,
        (color % 0x100) / 255,
        alpha

end

-- =====================================================
-- Text Renderer
-- =====================================================

local function draw_text(
    cr,
    settings,
    colors,
    scale,
    theme
)

    local text =
        settings.text

    if type(text) == "function" then

        text =
            text(
                theme
            )

    end

    text =
        tostring(
            text or ""
        )

    local font_name =
        settings.font_name or "Sans"

    local font_size =
        (settings.font_size or 14)
        * scale

    local x =
        (settings.x or 0)
        * scale

    local y =
        (settings.y or 0)
        * scale

    local h_align =
        settings.h_align or "l"

    local v_align =
        settings.v_align or "b"

    local bold =
        settings.bold or false

    local italic =
        settings.italic or false

    local slant =
        CAIRO_FONT_SLANT_NORMAL

    local weight =
        CAIRO_FONT_WEIGHT_NORMAL

    if italic then

        slant =
            CAIRO_FONT_SLANT_ITALIC

    end

    if bold then

        weight =
            CAIRO_FONT_WEIGHT_BOLD

    end

    cairo_save(
        cr
    )

    cairo_select_font_face(
        cr,
        font_name,
        slant,
        weight
    )

    cairo_set_font_size(
        cr,
        font_size
    )

    local extents =
        cairo_text_extents_t:create()

    cairo_text_extents(
        cr,
        text,
        extents
    )

    local draw_x =
        x

    local draw_y =
        y

    -- =================================================
    -- Horizontal alignment
    -- =================================================

    if h_align == "c" then

        draw_x =
            x -
            extents.width / 2

    elseif h_align == "r" then

        draw_x =
            x -
            extents.width

    end

    -- =================================================
    -- Vertical alignment
    -- =================================================

    if v_align == "m" then

        draw_y =
            y -
            (
                extents.height / 2
                + extents.y_bearing
            )

    elseif v_align == "t" then

        draw_y =
            y -
            extents.y_bearing

    end

    -- =================================================
    -- Color
    -- =================================================

    local colour =
        settings.colour
        or {
            {1, "Text", 1}
        }

    local first =
        colour[1]

    local color_value =
        resolve_color(
            first[2],
            colors
        )

    local alpha =
        first[3] or 1

    cairo_set_source_rgba(
        cr,
        color_to_rgba(
            color_value,
            alpha
        )
    )

    -- =================================================
    -- Draw
    -- =================================================

    cairo_move_to(
        cr,
        draw_x,
        draw_y
    )

    cairo_show_text(
        cr,
        text
    )

    cairo_restore(
        cr
    )

end

-- =====================================================
-- Draw
-- =====================================================

function M.draw(
    ctx,
    theme
)

    if not conky_window then
        return
    end

    local scale_value =
        1.0

    if theme
        and theme.scale
        and tonumber(
            theme.scale.Scale
        ) then

        scale_value =
            tonumber(
                theme.scale.Scale
            )

    end

    local colors =
        theme.colors

    -- =================================================
    -- Cairo Surface
    -- =================================================

    local cs =
        cairo_xlib_surface_create(
            conky_window.display,
            conky_window.drawable,
            conky_window.visual,
            conky_window.width,
            conky_window.height
        )

    local cr =
        cairo_create(
            cs
        )

    -- =================================================
    -- Render all text
    -- =================================================

    for _, settings in ipairs(
        text_settings
    ) do

        draw_text(
            cr,
            settings,
            colors,
            scale_value,
            theme
        )

    end

    -- =================================================
    -- Cleanup
    -- =================================================

    cairo_destroy(
        cr
    )

    cairo_surface_destroy(
        cs
    )

end

return M
