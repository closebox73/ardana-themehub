local colors = {

    Text = 0xF6F5F4,

}

return colors
