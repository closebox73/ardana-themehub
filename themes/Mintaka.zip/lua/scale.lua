local scale = {

    Scale = 1.0,

}

return scale
