local colors = {

    Text = 0xFFFFFF,
    Accent = 0x3584E4,

}

return colors
