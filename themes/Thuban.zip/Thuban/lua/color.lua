local colors = {

    Text = 0x000000,
    Accent = 0x3584E4,

}

return colors
