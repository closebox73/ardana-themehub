-- =====================================================
-- Calendar Renderer
-- =====================================================
--
-- Description:
-- Monthly calendar renderer.
-- Month title can be rendered separately via text.lua.
--
-- =====================================================

local M = {}

M.layer = 40

-- =====================================================
-- Configuration
-- =====================================================

local config = {

    -- Position
    x = -8,
    y = 585,

    -- Font
    font_name = "FantasqueSansMono Nerd Font",
    font_size = 14,

    -- Grid
    column_width = 22,
    row_height = 18,

    -- Colors
    weekday_color = "Text",
    day_color = "Text",
    today_color = "Accent",

    -- Opacity
    weekday_alpha = 0.90,
    past_alpha = 0.30,
    day_alpha = 1.00,
    today_alpha = 1.00,

}

-- =====================================================
-- Helpers
-- =====================================================

local function hex_to_rgb(
    value
)

    if type(value) ~= "number" then

        return 1, 1, 1

    end

    local r =
        math.floor(
            value / 0x10000
        ) % 0x100

    local g =
        math.floor(
            value / 0x100
        ) % 0x100

    local b =
        value % 0x100

    return
        r / 255,
        g / 255,
        b / 255

end

-- =====================================================
-- Set Color
-- =====================================================

local function set_color(
    ctx,
    theme,
    name,
    alpha
)

    local value =
        theme.colors[name]
        or 0xffffff

    local r,
        g,
        b =
        hex_to_rgb(
            value
        )

    cairo_set_source_rgba(
        ctx,
        r,
        g,
        b,
        alpha or 1
    )

end

-- =====================================================
-- Draw Text
-- =====================================================

local function draw_text(
    ctx,
    text,
    x,
    y,
    width,
    align
)

    local extents =
        cairo_text_extents_t:create()

    cairo_text_extents(
        ctx,
        text,
        extents
    )

    local text_x

    if align == "r" then

        text_x =
            x +
            width -
            extents.width -
            extents.x_bearing

    elseif align == "c" then

        text_x =
            x +
            (
                width -
                extents.width
            ) / 2 -
            extents.x_bearing

    else

        text_x =
            x -
            extents.x_bearing

    end

    cairo_move_to(
        ctx,
        text_x,
        y
    )

    cairo_show_text(
        ctx,
        text
    )

end

-- =====================================================
-- Calendar Data
-- =====================================================

local weekdays = {
    "SU",
    "MO",
    "TU",
    "WE",
    "TH",
    "FR",
    "SA",
}

local function get_calendar()

    local now =
        os.date(
            "*t"
        )

    local year =
        now.year

    local month =
        now.month

    local today =
        now.day

    -- =============================================
    -- First Day of Month
    -- =============================================

    local first =
        os.time(
            {
                year = year,
                month = month,
                day = 1,
                hour = 12,
            }
        )

    -- Sunday = 0
    local first_weekday =
        tonumber(
            os.date(
                "%w",
                first
            )
        )

    -- =============================================
    -- Last Day of Month
    -- =============================================

    local next_month =
        os.time(
            {
                year = year,
                month = month + 1,
                day = 1,
                hour = 12,
            }
        )

    local last_day =
        os.date(
            "*t",
            next_month - 86400
        ).day

    return {

        first_weekday =
            first_weekday,

        last_day =
            last_day,

        today =
            today,

    }

end

-- =====================================================
-- Draw
-- =====================================================

function M.draw(
    ctx,
    theme
)

    -- =============================================
    -- Scale
    -- =============================================

    local scale =
        (
            theme.scale
            and theme.scale.Scale
        )
        or 1.0

    -- =============================================
    -- Scaled Configuration
    -- =============================================

    local base_x =
        config.x *
        scale

    local base_y =
        config.y *
        scale

    local font_size =
        config.font_size *
        scale

    local column_width =
        config.column_width *
        scale

    local row_height =
        config.row_height *
        scale

    -- =============================================
    -- Calendar Data
    -- =============================================

    local data =
        get_calendar()

    -- =============================================
    -- Font
    -- =============================================

    cairo_select_font_face(
        ctx,
        config.font_name,
        CAIRO_FONT_SLANT_NORMAL,
        CAIRO_FONT_WEIGHT_NORMAL
    )

    cairo_set_font_size(
        ctx,
        font_size
    )

    -- =============================================
    -- Weekday Header
    -- =============================================

    set_color(
        ctx,
        theme,
        config.weekday_color,
        config.weekday_alpha
    )

    for column = 0, 6 do

        local x =
            base_x +
            (
                column *
                column_width
            )

        draw_text(
            ctx,
            weekdays[
                column + 1
            ],
            x,
            base_y,
            column_width,
            "r"
        )

    end

    -- =============================================
    -- Days
    -- =============================================

    for day = 1,
        data.last_day
    do

        local index =
            data.first_weekday +
            day -
            1

        local column =
            index % 7

        local row =
            math.floor(
                index / 7
            )

        local x =
            base_x +
            (
                column *
                column_width
            )

        local y =
            base_y +
            (
                (
                    row + 1
                ) *
                row_height
            )

        -- =========================================
        -- Day State
        -- =========================================

        if day < data.today then

            -- Past Day
            set_color(
                ctx,
                theme,
                config.day_color,
                config.past_alpha
            )

        elseif day == data.today then

            -- Today
            set_color(
                ctx,
                theme,
                config.today_color,
                config.today_alpha
            )

        else

            -- Future Day
            set_color(
                ctx,
                theme,
                config.day_color,
                config.day_alpha
            )

        end

        -- =========================================
        -- Draw Day
        -- =========================================

        draw_text(
            ctx,
            tostring(
                day
            ),
            x,
            y,
            column_width,
            "r"
        )

    end

end

return M
