local colors = {

    Text = 0xFFFFFF,
    Accent1 = 0xF66151,
    Accent2 = 0xF9F06B,
    Accent3 = 0x8FF0A4,
    Accent4 = 0x99C1F1,

}

return colors
