-- =====================================================
-- Ardana Shape Renderer
-- =====================================================
--
-- Flexible rectangle renderer
-- Supports:
-- - Rectangle
-- - Square
-- - Rounded rectangle
-- - Capsule
-- - Per-corner radius
-- - Fill opacity
-- - Border color / opacity
--
-- =====================================================

local M = {}

M.layer = 10

-- =====================================================
-- Configuration
-- =====================================================

local shapes = {

    {
        x = 5,
        y = 5,

        width = 6,
        height = 55,

        -- Fill
        color = "Accent1",
        opacity = 1,

        -- Radius
        radius = 0,

    },

    {
        x = 5,
        y = 60,

        width = 6,
        height = 55,

        -- Fill
        color = "Accent2",
        opacity = 1,

        -- Radius
        radius = 0,

    },

    {
        x = 5,
        y = 115,

        width = 6,
        height = 55,

        -- Fill
        color = "Accent3",
        opacity = 1,

        -- Radius
        radius = 0,

    },

    {
        x = 5,
        y = 170,

        width = 6,
        height = 55,

        -- Fill
        color = "Accent4",
        opacity = 1,

        -- Radius
        radius = 0,

    },

}

-- =====================================================
-- Helper
-- =====================================================

local function clamp(
    value,
    minimum,
    maximum
)

    if value < minimum then
        return minimum
    end

    if value > maximum then
        return maximum
    end

    return value

end

-- =====================================================
-- Color Helper
-- =====================================================

local function get_color(
    theme,
    name
)

    local hex =
        theme.colors[name]
        or 0xffffff

    local r =
        (
            hex >> 16
        )
        & 0xff

    local g =
        (
            hex >> 8
        )
        & 0xff

    local b =
        hex
        & 0xff

    return
        r / 255,
        g / 255,
        b / 255

end

-- =====================================================
-- Radius Helper
-- =====================================================

local function get_radius(
    radius,
    width,
    height
)

    local maximum =
        math.min(
            width,
            height
        )
        / 2

    local tl = 0
    local tr = 0
    local br = 0
    local bl = 0

    if type(radius) == "number" then

        tl = radius
        tr = radius
        br = radius
        bl = radius

    elseif type(radius) == "table" then

        tl =
            radius.top_left
            or 0

        tr =
            radius.top_right
            or 0

        br =
            radius.bottom_right
            or 0

        bl =
            radius.bottom_left
            or 0

    end

    tl =
        clamp(
            tl,
            0,
            maximum
        )

    tr =
        clamp(
            tr,
            0,
            maximum
        )

    br =
        clamp(
            br,
            0,
            maximum
        )

    bl =
        clamp(
            bl,
            0,
            maximum
        )

    return
        tl,
        tr,
        br,
        bl

end

-- =====================================================
-- Rounded Rectangle Path
-- =====================================================

local function rounded_rect(
    ctx,
    x,
    y,
    width,
    height,
    radius
)

    local tl,
        tr,
        br,
        bl =
            get_radius(
                radius,
                width,
                height
            )

    cairo_new_path(
        ctx
    )

    -- Start top
    cairo_move_to(
        ctx,
        x + tl,
        y
    )

    -- Top edge
    cairo_line_to(
        ctx,
        x + width - tr,
        y
    )

    -- Top right
    cairo_arc(
        ctx,
        x + width - tr,
        y + tr,
        tr,
        -math.pi / 2,
        0
    )

    -- Right edge
    cairo_line_to(
        ctx,
        x + width,
        y + height - br
    )

    -- Bottom right
    cairo_arc(
        ctx,
        x + width - br,
        y + height - br,
        br,
        0,
        math.pi / 2
    )

    -- Bottom edge
    cairo_line_to(
        ctx,
        x + bl,
        y + height
    )

    -- Bottom left
    cairo_arc(
        ctx,
        x + bl,
        y + height - bl,
        bl,
        math.pi / 2,
        math.pi
    )

    -- Left edge
    cairo_line_to(
        ctx,
        x,
        y + tl
    )

    -- Top left
    cairo_arc(
        ctx,
        x + tl,
        y + tl,
        tl,
        math.pi,
        math.pi * 1.5
    )

    cairo_close_path(
        ctx
    )

end

-- =====================================================
-- Draw Shape
-- =====================================================

local function draw_shape(
    ctx,
    theme,
    shape
)

    local scale =
        (
            theme.scale
            and theme.scale.Scale
        )
        or 1

    local x =
        (
            shape.x
            or 0
        )
        * scale

    local y =
        (
            shape.y
            or 0
        )
        * scale

    local width =
        (
            shape.width
            or 0
        )
        * scale

    local height =
        (
            shape.height
            or 0
        )
        * scale

    -- Ignore invalid shapes
    if width <= 0
        or height <= 0
    then

        return

    end

    local r,
        g,
        b =
            get_color(
                theme,
                shape.color
            )

    local opacity =
        shape.opacity

    if opacity == nil then
        opacity = 1
    end

    -- Create path
    local radius =
        shape.radius

    if type(radius) == "number" then

        radius =
            radius
            * scale

    elseif type(radius) == "table" then

        radius = {

            top_left =
                (
                    radius.top_left
                    or 0
                )
                * scale,

            top_right =
                (
                    radius.top_right
                    or 0
                )
                * scale,

            bottom_right =
                (
                    radius.bottom_right
                    or 0
                )
                * scale,

            bottom_left =
                (
                    radius.bottom_left
                    or 0
                )
                * scale,

        }

    end

    rounded_rect(
        ctx,
        x,
        y,
        width,
        height,
        radius
    )

    -- =============================================
    -- Fill
    -- =============================================

    if opacity > 0 then

        cairo_set_source_rgba(
            ctx,
            r,
            g,
            b,
            opacity
        )

        cairo_fill_preserve(
            ctx
        )

    end

    -- =============================================
    -- Border
    -- =============================================

    local border =
        shape.border

    if border
        and (
            border.width
            or 0
        ) > 0
    then

        local br,
            bg,
            bb =
                get_color(
                    theme,
                    border.color
                )

        local border_opacity =
            border.opacity

        if border_opacity == nil then
            border_opacity = 1
        end

        cairo_set_source_rgba(
            ctx,
            br,
            bg,
            bb,
            border_opacity
        )

        cairo_set_line_width(
            ctx,
            border.width
            * scale
        )

        cairo_stroke(
            ctx
        )

    else

        cairo_new_path(
            ctx
        )

    end

end

-- =====================================================
-- Draw
-- =====================================================

function M.draw(
    ctx,
    theme
)

    for _,
        shape
        in ipairs(
            shapes
        ) do

        draw_shape(
            ctx,
            theme,
            shape
        )

    end

end

return M
