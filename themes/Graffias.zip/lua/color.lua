local colors = {

    Text = 0x1B1C1E,
    Accent = 0xF5C211,

}

return colors
