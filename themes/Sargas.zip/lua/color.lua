local colors = {

    Text = 0xFFFFFF,
    Accent = 0xE66100,

}

return colors
