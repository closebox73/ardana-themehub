-- =====================================================
-- Ring Renderer
-- =====================================================
--
-- Universal ring meter renderer for Ardana themes.
--
-- Supports unlimited rings with individual settings for
-- position, radius, thickness, angles, colors, alpha,
-- and custom value sources.
--
-- Value Sources:
--
--   Conky:
--       name = "cpu"
--       arg  = "cpu0"
--
--   Provider:
--       value = function(theme)
--           return ...
--       end
--
-- =====================================================

local M = {}

M.layer = 20

-- =====================================================
-- Ring Settings
-- =====================================================

local ring_settings = {

    -- =================================================
    -- CPU
    -- =================================================

    {
        name = "cpu",
        arg = "cpu0",

        max = 100,

        x = 38,
        y = 540,

        radius = 34,
        thickness = 9,

        start_angle = 220,
        end_angle = 500,

        bg_colour = {
            "Text",
            0.2
        },

        fg_colour = {
            "Accent",
            1
        }
    },

    -- =================================================
    -- Memory
    -- =================================================

    {
        name = "memperc",
        arg = "",

        max = 100,

        x = 124,
        y = 545,

        radius = 34,
        thickness = 9,

        start_angle = 220,
        end_angle = 500,

        bg_colour = {
            "Text",
            0.2
        },

        fg_colour = {
            "Accent",
            1
        }
    },

    {
        name = "acpitemp",
        arg = "",

        max = 100,

        x = 210,
        y = 545,

        radius = 34,
        thickness = 9,

        start_angle = 220,
        end_angle = 500,

        bg_colour = {
            "Text",
            0.2
        },

        fg_colour = {
            "Accent",
            1
        }
    }

}

-- =====================================================
-- Color
-- =====================================================

local function resolve_color(
    color_name,
    colors
)

    if type(
        color_name
    ) == "number" then

        return color_name

    end

    if type(
        color_name
    ) == "string" then

        return
            colors[
                color_name
            ]
            or colors.Text
            or 0xffffff

    end

    return 0xffffff

end

-- =====================================================
-- RGBA
-- =====================================================

local function color_to_rgba(
    color,
    alpha
)

    return
        (
            (
                color / 0x10000
            ) % 0x100
        ) / 255,

        (
            (
                color / 0x100
            ) % 0x100
        ) / 255,

        (
            color % 0x100
        ) / 255,

        alpha

end

-- =====================================================
-- Get Ring Value
-- =====================================================

local function get_value(
    settings,
    theme
)

    -- =============================================
    -- Custom Value
    -- =============================================

    if type(
        settings.value
    ) == "function" then

        local ok,
            value =
            pcall(
                settings.value,
                theme
            )

        if ok then

            return
                tonumber(
                    value
                )
                or 0

        end

        return 0

    end

    -- =============================================
    -- Conky Value
    -- =============================================

    local name =
        settings.name
        or ""

    local arg =
        settings.arg
        or ""

    if name == "" then
        return 0
    end

    local command

    if arg ~= "" then

        command =
            string.format(
                "${%s %s}",
                name,
                arg
            )

    else

        command =
            string.format(
                "${%s}",
                name
            )

    end

    local value =
        tonumber(
            conky_parse(
                command
            )
        )

    return value or 0

end

-- =====================================================
-- Draw Ring
-- =====================================================

local function draw_ring(
    ctx,
    settings,
    theme,
    colors,
    scale
)

    -- =================================================
    -- Value
    -- =================================================

    local value =
        get_value(
            settings,
            theme
        )

    local max =
        tonumber(
            settings.max
        )
        or 100

    if max <= 0 then
        return
    end

    local percentage =
        value /
        max

    percentage =
        math.max(
            0,
            math.min(
                percentage,
                1
            )
        )

    -- =================================================
    -- Scale
    -- =================================================

    local x =
        (
            settings.x
            or 0
        )
        * scale

    local y =
        (
            settings.y
            or 0
        )
        * scale

    local radius =
        (
            settings.radius
            or 0
        )
        * scale

    local thickness =
        (
            settings.thickness
            or 1
        )
        * scale

    -- =================================================
    -- Angles
    -- =================================================

    local start_angle =
        settings.start_angle
        or 0

    local end_angle =
        settings.end_angle
        or 360

    local angle_start =
        start_angle
        * (
            2
            * math.pi
            / 360
        )
        - math.pi / 2

    local angle_end =
        end_angle
        * (
            2
            * math.pi
            / 360
        )
        - math.pi / 2

    local progress_angle =
        angle_start
        + (
            percentage
            * (
                angle_end
                - angle_start
            )
        )

    -- =================================================
    -- Background Color
    -- =================================================

    local bg =
        settings.bg_colour
        or {
            "Text",
            0.2
        }

    local bg_color =
        resolve_color(
            bg[1],
            colors
        )

    local bg_alpha =
        bg[2]
        or 1

    -- =================================================
    -- Foreground Color
    -- =================================================

    local fg =
        settings.fg_colour
        or {
            "Text",
            1
        }

    local fg_color =
        resolve_color(
            fg[1],
            colors
        )

    local fg_alpha =
        fg[2]
        or 1

    -- =================================================
    -- Draw Background
    -- =================================================

    cairo_save(
        ctx
    )

    cairo_new_path(
        ctx
    )

    cairo_arc(
        ctx,
        x,
        y,
        radius,
        angle_start,
        angle_end
    )

    cairo_set_line_width(
        ctx,
        thickness
    )

    cairo_set_source_rgba(
        ctx,
        color_to_rgba(
            bg_color,
            bg_alpha
        )
    )

    cairo_stroke(
        ctx
    )

    -- =================================================
    -- Draw Foreground
    -- =================================================

    if percentage > 0 then

        cairo_new_path(
            ctx
        )

        cairo_arc(
            ctx,
            x,
            y,
            radius,
            angle_start,
            progress_angle
        )

        cairo_set_line_width(
            ctx,
            thickness
        )

        cairo_set_source_rgba(
            ctx,
            color_to_rgba(
                fg_color,
                fg_alpha
            )
        )

        cairo_stroke(
            ctx
        )

    end

    cairo_restore(
        ctx
    )

end

-- =====================================================
-- Draw
-- =====================================================

function M.draw(
    ctx,
    theme
)

    if not ctx then
        return
    end

    if not theme then
        return
    end

    -- =================================================
    -- Scale
    -- =================================================

    local scale =
        (
            theme.scale
            and tonumber(
                theme.scale.Scale
            )
        )
        or 1.0

    -- =================================================
    -- Colors
    -- =================================================

    local colors =
        theme.colors
        or {}

    -- =================================================
    -- Render Rings
    -- =================================================

    for _, settings in ipairs(
        ring_settings
    ) do

        draw_ring(
            ctx,
            settings,
            theme,
            colors,
            scale
        )

    end

end

return M
