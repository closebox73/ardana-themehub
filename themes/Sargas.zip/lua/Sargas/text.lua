-- =====================================================
-- Text Renderer
-- =====================================================
--
-- Universal text renderer for Ardana themes.
--
-- Supports unlimited text fields with individual settings
-- for font, size, position, alignment, style, and color.
--
-- The `text` field supports both static values and dynamic
-- functions, allowing renderers to display data from Conky
-- variables, providers, or any value exposed by the theme
-- coordinator.
--
-- Examples:
--
-- Static / Conky text:
--     text = conky_parse("${time %H:%M}")
--
-- Dynamic provider data:
--     text = function(theme)
--         return theme.player.title
--     end
--
-- Dynamic fallback:
--     text = function(theme)
--         if not theme.player.available then
--             return "No media played"
--         end
--
--         return theme.player.title
--     end
--
-- This makes the renderer reusable with any provider
-- without requiring changes to the renderer itself.
--
-- =====================================================

local M = {}

M.layer = 30

-- =====================================================
-- Text Settings
-- =====================================================

local text_settings = {

    {
        text = function(theme)

            return os.date("%Y")

        end,

        font_name = "Bebas Neue",
        font_size = 74,

        h_align = "l",
        v_align = "t",

        bold = false,

        x = 0,
        y = 10,

        colour = {
            {1, "Text", 1}
        }
    },

    {
        text = function(theme)

            return os.date("%A")

        end,

        font_name = "Bebas Neue",
        font_size = 74,

        h_align = "l",
        v_align = "t",

        bold = false,

        x = 0,
        y = 77,

        colour = {
            {1, "Text", 1}
        }
    },

    {
        text = function(theme)

            return os.date("%d")

        end,

        font_name = "Bebas Neue",
        font_size = 74,

        h_align = "l",
        v_align = "t",

        bold = false,

        x = 0,
        y = 144,

        colour = {
            {1, "Text", 1}
        }
    },

    {
        text = function(theme)

            return os.date("%B")

        end,

        font_name = "Bebas Neue",
        font_size = 74,

        h_align = "l",
        v_align = "t",

        bold = false,

        x = 0,
        y = 211,

        colour = {
            {1, "Text", 1}
        }
    },

    {
        text = function(theme)

            local time =
                theme.providers.time.get()

            local hour =
                string.format(
                    "%02d",
                    time.format == "12"
                    and time.hour12
                    or time.hour
                )

            local minute =
                string.format(
                    "%02d",
                    time.minute
                )

            local result = {
                {hour, "Text"},
                {":", "Accent"},
                {minute, "Accent"}
            }

            if time.format == "12" then

                result[#result + 1] = {
                    " " .. time.am_pm,
                    "Accent"
                }

            end

            return result

        end,

        font_name = "Bebas Neue",
        font_size = 74,

        h_align = "l",
        v_align = "t",

        bold = true,

        x = 0,
        y = 278
    },

    {
        text = function(theme)

            local weather =
                theme.providers.weather.get()

            local city =
                weather.city or ""

            return string.format(
                "Today weather in %s",
                city
            )

        end,

        font_name = "Inter",
        font_size = 14,

        h_align = "l",
        v_align = "t",

        bold = false,

        x = 0,
        y = 360,

        colour = {
            {1, "Text", 1}
        }
    },

    {
        text = function(theme)

            local weather =
                theme.providers.weather.get()

            local description =
                weather.description or ""

            local temperature =
                weather.temperature_text or ""

            return string.format(
                "is %s with temperature %s",
                description,
                temperature
            )

        end,

        font_name = "Inter",
        font_size = 14,

        h_align = "l",
        v_align = "t",

        bold = false,

        x = 0,
        y = 378,

        colour = {
            {1, "Text", 1}
        }
    },

    {
        text = function(theme)

            local weather =
                theme.providers.weather.get()

            local feels_like =
                weather.feels_like_text or ""

            local humidity =
                tostring(
                    weather.humidity or 0
                ) .. "%"

            return string.format(
                "it feels like %s and humidity is %s.",
                feels_like,
                humidity
            )

        end,

        font_name = "Inter",
        font_size = 14,

        h_align = "l",
        v_align = "t",

        bold = false,

        x = 0,
        y = 396,

        colour = {
            {1, "Text", 1}
        }
    },

    {
        text = function(theme)

            local player =
                theme.providers.playerctl.get()

            return player.artist

        end,

        font_name = "Inter",
        font_size = 15,

        h_align = "l",
        v_align = "t",

        bold = true,

        x = 0,
        y = 440,

        colour = {
            {1, "Text", 1}
        }
    },

    {
        text = function(theme)

            local player =
                theme.providers.playerctl.get()

            if not player.available then
                return "~ No media played"
            end

            return "~ " .. player.title

        end,

        font_name = "Inter",
        font_size = 17,

        h_align = "l",
        v_align = "t",

        bold = true,

        x = 0,
        y = 460,

        colour = {
            {1, "Accent", 1}
        }
    },

    {
        text = "CPU",

        font_name = "Bebas Neue",
        font_size = 16,

        h_align = "c",
        v_align = "t",

        bold = false,

        x = 39,
        y = 565,

        colour = {
            {1, "Text", 1}
        }
    },

    {
        text = "RAM",

        font_name = "Bebas Neue",
        font_size = 16,

        h_align = "c",
        v_align = "t",

        bold = false,

        x = 124,
        y = 565,

        colour = {
            {1, "Text", 1}
        }
    },

    {
        text = "TEMP",

        font_name = "Bebas Neue",
        font_size = 16,

        h_align = "c",
        v_align = "t",

        bold = false,

        x = 209,
        y = 565,

        colour = {
            {1, "Text", 1}
        }
    }

}

-- =====================================================
-- Color
-- =====================================================

local function resolve_color(
    color_name,
    colors
)

    if type(color_name) == "number" then
        return color_name
    end

    if type(color_name) == "string" then

        return colors[color_name]
            or colors.Text
            or 0xffffff

    end

    return 0xffffff

end

-- =====================================================
-- RGBA
-- =====================================================

local function color_to_rgba(
    color,
    alpha
)

    return
        ((color / 0x10000) % 0x100) / 255,
        ((color / 0x100) % 0x100) / 255,
        (color % 0x100) / 255,
        alpha

end

-- =====================================================
-- Text Renderer
-- =====================================================

local function draw_text(
    cr,
    settings,
    colors,
    scale,
    theme
)

    local text =
        settings.text

    if type(text) == "function" then

        text =
            text(
                theme
            )

    end

    local font_name =
        settings.font_name or "Sans"

    local font_size =
        (settings.font_size or 14)
        * scale

    local x =
        (settings.x or 0)
        * scale

    local y =
        (settings.y or 0)
        * scale

    local h_align =
        settings.h_align or "l"

    local v_align =
        settings.v_align or "b"

    local bold =
        settings.bold or false

    local italic =
        settings.italic or false

    local slant =
        CAIRO_FONT_SLANT_NORMAL

    local weight =
        CAIRO_FONT_WEIGHT_NORMAL

    if italic then
        slant =
            CAIRO_FONT_SLANT_ITALIC
    end

    if bold then
        weight =
            CAIRO_FONT_WEIGHT_BOLD
    end

    cairo_save(cr)

    cairo_select_font_face(
        cr,
        font_name,
        slant,
        weight
    )

    cairo_set_font_size(
        cr,
        font_size
    )

    -- =================================================
    -- Normalize text
    -- =================================================

    local segments = {}

    if type(text) == "table" then

        for _, segment in ipairs(text) do

            if type(segment) == "table" then

                local value =
                    tostring(
                        segment[1] or ""
                    )

                local color =
                    segment[2] or "Text"

                local alpha =
                    segment[3] or 1

                segments[#segments + 1] = {
                    text = value,
                    color = color,
                    alpha = alpha
                }

            end

        end

    else

        segments[1] = {
            text = tostring(text or ""),
            color =
                (
                    settings.colour
                    and settings.colour[1]
                    and settings.colour[1][2]
                )
                or "Text",
            alpha =
                (
                    settings.colour
                    and settings.colour[1]
                    and settings.colour[1][3]
                )
                or 1
        }

    end

    -- =================================================
    -- Calculate total width
    -- =================================================

    local total_width = 0

    local extents_list = {}

    for _, segment in ipairs(segments) do

        local extents =
            cairo_text_extents_t:create()

        cairo_text_extents(
            cr,
            segment.text,
            extents
        )

        extents_list[#extents_list + 1] =
            extents

        total_width =
            total_width
            + extents.x_advance

    end

    -- =================================================
    -- Horizontal alignment
    -- =================================================

    local draw_x =
        x

    if h_align == "c" then

        draw_x =
            x
            - total_width / 2

    elseif h_align == "r" then

        draw_x =
            x
            - total_width

    end

    -- =================================================
    -- Vertical alignment
    -- =================================================

    local draw_y =
        y

    if #extents_list > 0 then

        local first_extents =
            extents_list[1]

        if v_align == "m" then

            draw_y =
                y
                - (
                    first_extents.height / 2
                    + first_extents.y_bearing
                )

        elseif v_align == "t" then

            draw_y =
                y
                - first_extents.y_bearing

        end

    end

    -- =================================================
    -- Draw segments
    -- =================================================

    for index, segment in ipairs(segments) do

        local color_value =
            resolve_color(
                segment.color,
                colors
            )

        cairo_set_source_rgba(
            cr,
            color_to_rgba(
                color_value,
                segment.alpha
            )
        )

        cairo_move_to(
            cr,
            draw_x,
            draw_y
        )

        cairo_show_text(
            cr,
            segment.text
        )

        draw_x =
            draw_x
            + extents_list[index].x_advance

    end

    cairo_restore(cr)

end

-- =====================================================
-- Draw
-- =====================================================

function M.draw(
    ctx,
    theme
)

    if not conky_window then
        return
    end

    local scale_value =
        1.0

    if theme
        and theme.scale
        and tonumber(
            theme.scale.Scale
        ) then

        scale_value =
            tonumber(
                theme.scale.Scale
            )

    end

    local colors =
        theme.colors

    -- =================================================
    -- Cairo Surface
    -- =================================================

    local cs =
        cairo_xlib_surface_create(
            conky_window.display,
            conky_window.drawable,
            conky_window.visual,
            conky_window.width,
            conky_window.height
        )

    local cr =
        cairo_create(
            cs
        )

    -- =================================================
    -- Render all text
    -- =================================================

    for _, settings in ipairs(
        text_settings
    ) do

        draw_text(
            cr,
            settings,
            colors,
            scale_value,
            theme
        )

    end

    -- =================================================
    -- Cleanup
    -- =================================================

    cairo_destroy(
        cr
    )

    cairo_surface_destroy(
        cs
    )

end

return M
