local scale = {

    Scale = 1.00,

}

return scale
