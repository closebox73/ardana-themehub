local colors = {

    Text = 0xFFFFFF,

}

return colors
