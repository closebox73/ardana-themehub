local colors = {

    Text = 0xFFFFFF,
    Text1 = 0x5E5C64,

}

return colors
