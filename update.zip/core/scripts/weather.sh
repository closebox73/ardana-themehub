#!/bin/bash

# =====================================================
# Ardana Weather Fetcher
# =====================================================
#
# Fetches current weather data from OpenWeatherMap
# and stores the result as a local JSON cache.
#
# Configuration:
#   ~/.config/Ardana/config/weather.conf
#   ~/.config/Ardana/config/unit.conf
#
# Cache:
#   ~/.cache/Ardana/weather.json
#
# =====================================================


# =====================================================
# Paths
# =====================================================

BASE="$HOME/.config/Ardana"

WEATHER_CONFIG="$BASE/config/weather.conf"
UNIT_CONFIG="$BASE/config/unit.conf"

CACHE_DIR="$HOME/.cache/Ardana"

WEATHER_FILE="$CACHE_DIR/weather.json"


# =====================================================
# Load Configuration
# =====================================================

if [ ! -f "$WEATHER_CONFIG" ]; then

    exit 1

fi

if [ ! -f "$UNIT_CONFIG" ]; then

    exit 1

fi

source "$WEATHER_CONFIG"
source "$UNIT_CONFIG"


# =====================================================
# Validate Configuration
# =====================================================

if [ -z "$API_KEY" ]; then

    exit 1

fi

if [ -z "$LAT" ]; then

    exit 1

fi

if [ -z "$LON" ]; then

    exit 1

fi

if [ -z "$UNIT" ]; then

    exit 1

fi


# =====================================================
# Defaults
# =====================================================

LANG="${LANG:-en}"


# =====================================================
# Create Cache Directory
# =====================================================

mkdir -p "$CACHE_DIR"


# =====================================================
# OpenWeatherMap URL
# =====================================================

URL="https://api.openweathermap.org/data/2.5/weather?lat=${LAT}&lon=${LON}&appid=${API_KEY}&units=${UNIT}&lang=${LANG}"


# =====================================================
# Fetch Weather
# =====================================================

TEMP_FILE="${WEATHER_FILE}.tmp"

curl \
    -s \
    --connect-timeout 10 \
    --max-time 20 \
    "$URL" \
    -o "$TEMP_FILE"


# =====================================================
# Validate Result
# =====================================================

if [ ! -s "$TEMP_FILE" ]; then

    rm -f "$TEMP_FILE"

    exit 1

fi


# =====================================================
# Validate JSON
# =====================================================

if ! jq empty "$TEMP_FILE" 2>/dev/null; then

    rm -f "$TEMP_FILE"

    exit 1

fi


# =====================================================
# Validate OpenWeatherMap Response
# =====================================================

if jq -e '.cod and (.cod | tonumber?) and ((.cod | tonumber?) != 200)' "$TEMP_FILE" >/dev/null 2>&1; then

    rm -f "$TEMP_FILE"

    exit 1

fi


# =====================================================
# Save Cache
# =====================================================

mv \
    "$TEMP_FILE" \
    "$WEATHER_FILE"


exit 0
