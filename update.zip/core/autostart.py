import json
import os
import subprocess


ARDANA_DIR = os.path.expanduser(
    "~/.config/Ardana"
)

AUTOSTART_STATE = os.path.join(
    ARDANA_DIR,
    "autostart.json"
)


def main():

    if not os.path.isfile(
        AUTOSTART_STATE
    ):
        return

    try:

        with open(
            AUTOSTART_STATE,
            "r",
            encoding="utf-8"
        ) as file:

            state = json.load(
                file
            )

    except Exception:

        return

    if not state.get(
        "enabled",
        False
    ):
        return

    configs = state.get(
        "configs",
        []
    )

    if not isinstance(
        configs,
        list
    ):
        return

    for conf_path in configs:

        if not os.path.isfile(
            conf_path
        ):
            continue

        try:

            subprocess.Popen(
                [
                    "conky",
                    "-c",
                    conf_path
                ],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                start_new_session=True
            )

        except Exception:

            pass


if __name__ == "__main__":
    main()
