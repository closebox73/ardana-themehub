-- =====================================================
-- Ardana Weather Provider
-- =====================================================
--
-- Description:
-- Manages weather data for Ardana themes.
--
-- Responsibilities:
--   - Trigger weather fetch script
--   - Read weather cache
--   - Parse weather data
--   - Provide shared weather state
--
-- =====================================================

local M = {}

-- =====================================================
-- Paths
-- =====================================================

local HOME =
    os.getenv(
        "HOME"
    )

local BASE =
    HOME ..
    "/.config/Ardana"

local WEATHER_SCRIPT =
    BASE ..
    "/scripts/weather.sh"

local WEATHER_CONFIG =
    BASE ..
    "/config/weather.conf"

local UNIT_CONFIG =
    BASE ..
    "/config/unit.conf"

local WEATHER_FILE =
    HOME ..
    "/.cache/Ardana/weather.json"

-- =====================================================
-- Configuration
-- =====================================================

local CACHE_TTL = 600

-- =====================================================
-- State
-- =====================================================

local state = {

    loaded = false,
    available = false,
    unit = "metric",

    city = "",
    country = "",

    condition = "",
    description = "",
    icon = "",
    icon_code = "",

    temperature = 0,
    temp_max = 0,
    temp_min = 0,
    feels_like = 0,

    temperature_text = "",
    temp_max_text = "",
    temp_min_text = "",
    feels_like_text = "",

    humidity = 0,
    pressure = 0,

    visibility = 0,
    visibility_text = "",

    wind_speed = 0,
    wind_speed_text = "",
    wind_degree = 0,
    wind_direction = "",

    sunrise = "",
    sunset = "",

}

-- =====================================================
-- Helpers
-- =====================================================

local function trim(
    value
)

    local result =
        (
            value
            or ""
        ):gsub(
            "^%s*(.-)%s*$",
            "%1"
        )

    return result

end


local function run_command(
    command
)

    local pipe =
        io.popen(
            command
        )

    if not pipe then
        return ""
    end

    local output =
        pipe:read(
            "*a"
        )

    pipe:close()

    return trim(
        output
    )

end

-- =====================================================
-- JSON Helpers
-- =====================================================

local function json_string(
    filter
)

    local command =
        "jq -r '"
        .. filter
        .. " // empty' "
        .. string.format(
            "%q",
            WEATHER_FILE
        )
        .. " 2>/dev/null"

    return run_command(
        command
    )

end


local function json_number(
    filter
)

    local value =
        json_string(
            filter
        )

    return tonumber(
        value
    )
    or 0

end

-- =====================================================
-- Wind Direction
-- =====================================================

local function get_wind_direction(
    degree
)

    degree =
        tonumber(
            degree
        )

    if not degree then
        return ""
    end

    if
        (degree >= 0 and degree <= 22)
        or degree > 337
    then

        return "North"

    elseif degree <= 67 then

        return "North East"

    elseif degree <= 112 then

        return "East"

    elseif degree <= 157 then

        return "South East"

    elseif degree <= 202 then

        return "South"

    elseif degree <= 247 then

        return "South West"

    elseif degree <= 292 then

        return "West"

    elseif degree <= 337 then

        return "North West"

    end

    return ""

end

-- =====================================================
-- Time Formatting
-- =====================================================

local function format_time(
    timestamp
)

    timestamp =
        tonumber(
            timestamp
        )

    if not timestamp
        or timestamp <= 0
    then

        return ""

    end

    return os.date(
        "%H:%M",
        timestamp
    )

end

-- =====================================================
-- Check Cache
-- =====================================================

local function cache_exists()
    local file =
        io.open(
            WEATHER_FILE,
            "r"
        )

    if not file then
        return false
    end

    file:close()

    return true
end

-- =====================================================
-- Cache Age
-- =====================================================

local function cache_age()

    local modified =
        tonumber(
            run_command(
                "stat -c %Y "
                .. string.format(
                    "%q",
                    WEATHER_FILE
                )
                .. " 2>/dev/null"
            )
        )

    if not modified then

        return math.huge

    end

    return
        os.time()
        - modified

end

-- =====================================================
-- Fetch Weather
-- =====================================================

local function fetch_weather()
    local command =
        "bash "
        .. string.format(
            "%q",
            WEATHER_SCRIPT
        )
        .. " >/dev/null 2>&1"

    os.execute(
        command
    )
end

-- =====================================================
-- Unit
-- =====================================================

local function get_unit()

    local unit =
        run_command(
            "grep '^UNIT=' "
            .. string.format(
                "%q",
                UNIT_CONFIG
            )
            .. " 2>/dev/null "
            .. "| cut -d'=' -f2 "
            .. "| tr -d '\"'"
        )

    if unit == "imperial" then
        return "imperial"
    end

    return "metric"

end

-- =====================================================
-- Temperature Formatting
-- =====================================================

local function format_temperature(
    value,
    unit
)
    value =
        tonumber(
            value
        )
        or 0

    local suffix =
    "°C"

    if unit == "imperial" then
        suffix =
        "°F"
    end

    return
        tostring(
            math.floor(
                value
            )
        )
        .. suffix
end

-- =====================================================
-- Visibility Formatting
-- =====================================================

local function format_visibility(
    value,
    unit
)

    value =
        tonumber(
            value
        )
        or 0

    if unit == "imperial" then

        local miles =
            math.floor(
                (
                    value
                    / 1609.344
                )
                + 0.5
            )

        return
            tostring(
                miles
            )
            .. " mi"

    end

    local kilometers =
        math.floor(
            (
                value
                / 1000
            )
            + 0.5
        )

    return
        tostring(
            kilometers
        )
        .. " km"

end

-- =====================================================
-- Wind Formatting
-- =====================================================

local function format_wind_speed(
    value,
    unit
)

    value =
        tonumber(
            value
        )
        or 0

    if unit == "imperial" then

        value =
            math.floor(
                value
                + 0.5
            )

        return
            tostring(
                value
            )
            .. " mph"

    end

    -- OWM metric returns m/s
    value =
        value * 3.6

    value =
        math.floor(
            value
            + 0.5
        )

    return
        tostring(
            value
        )
        .. " km/h"

end

-- =====================================================
-- Weather Icons
-- =====================================================

local WEATHER_ICONS = {

    -- Clear
    ["01d"] = "",
    ["01n"] = "",

    -- Clouds
    ["02d"] = "",
    ["02n"] = "",
    ["03d"] = "",
    ["03n"] = "",
    ["04d"] = "",
    ["04n"] = "",

    -- Shower Rain
    ["09d"] = "",
    ["09n"] = "",

    -- Rain
    ["10d"] = "",
    ["10n"] = "",

    -- Thunderstorm
    ["11d"] = "",
    ["11n"] = "",

    -- Snow
    ["13d"] = "",
    ["13n"] = "",

    -- Mist
    ["50d"] = "",
    ["50n"] = "",

}

local function get_weather_icon(
    code
)

    return WEATHER_ICONS[
        code
    ]
    or ""

end

-- =====================================================
-- Load Weather
-- =====================================================

local function load_weather()

    if not cache_exists() then
        fetch_weather()

        if not cache_exists() then
            state.available =
                false

            return false
        end
    end

    state.unit =
        get_unit()

    state.city =
        json_string(
            ".name"
        )

    state.country =
        json_string(
            ".sys.country"
        )

    state.condition =
        json_string(
            ".weather[0].main"
        )

    state.description =
        json_string(
            ".weather[0].description"
        )

    local icon_code =
        json_string(
            ".weather[0].icon"
        )

    state.icon_code =
        icon_code

    state.icon =
        get_weather_icon(
            icon_code
        )

    state.temperature =
        json_number(
            ".main.temp"
        )

    state.temp_max =
        json_number(
            ".main.temp_max"
        )

    state.temp_min =
        json_number(
            ".main.temp_min"
        )

    state.feels_like =
        json_number(
            ".main.feels_like"
        )

    state.temperature_text =
        format_temperature(
            state.temperature,
            state.unit
        )

    state.temp_max_text =
        format_temperature(
            state.temp_max,
            state.unit
        )

    state.temp_min_text =
        format_temperature(
            state.temp_min,
            state.unit
        )

    state.feels_like_text =
        format_temperature(
            state.feels_like,
            state.unit
        )

    state.humidity =
        json_number(
            ".main.humidity"
        )

    state.pressure =
        json_number(
            ".main.pressure"
        )

    -- OWM visibility is meters
    -- Convert to kilometers
    state.visibility =
        json_number(
            ".visibility"
        )

    state.visibility_text =
        format_visibility(
            state.visibility,
            state.unit
        )

    state.wind_speed =
        json_number(
            ".wind.speed"
        )

    state.wind_speed_text =
        format_wind_speed(
            state.wind_speed,
            state.unit
        )

    state.wind_degree =
        json_number(
            ".wind.deg"
        )

    state.wind_direction =
        get_wind_direction(
            state.wind_degree
        )

    state.sunrise =
        format_time(
            json_number(
                ".sys.sunrise"
            )
        )

    state.sunset =
        format_time(
            json_number(
                ".sys.sunset"
            )
        )

    state.available =
        true

    return true

end

-- =====================================================
-- Update
-- =====================================================

function M.update()

    -- =============================================
    -- Cache Missing
    -- =============================================

    if not cache_exists() then

        fetch_weather()

        if cache_exists() then

            load_weather()

            state.loaded =
                true

        else

            state.available =
                false

        end

        return

    end

    -- =============================================
    -- Initial Load
    -- =============================================

    if not state.loaded then

        load_weather()

        state.loaded =
            true

        return

    end

    -- =============================================
    -- Cache Expired
    -- =============================================

    if cache_age() >= CACHE_TTL then

        fetch_weather()

        if cache_exists() then

            load_weather()

        end

    end

end

-- =====================================================
-- Get
-- =====================================================

function M.get()

    return state

end

return M
