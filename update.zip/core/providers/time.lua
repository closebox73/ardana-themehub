-- =========================================================
-- Ardana Time Provider
-- =========================================================
-- Provides current local time and 12/24-hour formatting.
-- Configuration:
--   ~/.config/Ardana/config/time.conf
-- =========================================================

local M = {}

local HOME =
    os.getenv("HOME")

local CONFIG_PATH =
    HOME
    .. "/.config/Ardana/config/time.conf"


-- =========================================================
-- State
-- =========================================================

local state = {

    hour = 0,
    minute = 0,
    second = 0,

    hour12 = 12,

    am_pm = "AM",

    format = "24",

    formatted = "00:00",

}


-- =========================================================
-- Configuration
-- =========================================================

local config_mtime = nil


local function get_config_mtime()

    local handle =
        io.popen(
            "stat -c %Y "
            .. CONFIG_PATH
            .. " 2>/dev/null"
        )

    if not handle then
        return nil
    end

    local result =
        handle:read(
            "*a"
        )

    handle:close()

    return tonumber(
        result
    )

end


local function read_config()

    local file =
        io.open(
            CONFIG_PATH,
            "r"
        )

    if not file then
        return
    end

    for line in file:lines() do

        local key,
            value =
            line:match(
                '^([%w_]+)%s*=%s*"?([^"]*)"?$'
            )

        if key
            and value
        then

            if key == "TIME_FORMAT" then

                if value == "12"
                    or value == "24"
                then

                    state.format =
                        value

                end

            end

        end

    end

    file:close()

end


local function check_config()

    local mtime =
        get_config_mtime()

    if not mtime then
        return
    end

    if config_mtime ~= mtime then

        config_mtime =
            mtime

        read_config()

    end

end


-- =========================================================
-- Time
-- =========================================================

local function update_time()

    local now =
        os.date("*t")

    state.hour =
        now.hour

    state.minute =
        now.min

    state.second =
        now.sec


    -- ---------------------------------------------
    -- AM / PM
    -- ---------------------------------------------

    if state.hour >= 12 then

        state.am_pm =
            "PM"

    else

        state.am_pm =
            "AM"

    end


    -- ---------------------------------------------
    -- 12-hour conversion
    -- ---------------------------------------------

    state.hour12 =
        state.hour % 12

    if state.hour12 == 0 then

        state.hour12 =
            12

    end


    -- ---------------------------------------------
    -- Formatted time
    -- ---------------------------------------------

    if state.format == "12" then

        state.formatted =
            string.format(
                "%02d:%02d %s",
                state.hour12,
                state.minute,
                state.am_pm
            )

    else

        state.formatted =
            string.format(
                "%02d:%02d",
                state.hour,
                state.minute
            )

    end

end


-- =========================================================
-- Update
-- =========================================================

function M.update()

    check_config()

    update_time()

end


-- =========================================================
-- Get
-- =========================================================

function M.get()

    return state

end


-- =========================================================
-- Initialize
-- =========================================================

function M.init()

    config_mtime = nil

    check_config()

    update_time()

end


return M
