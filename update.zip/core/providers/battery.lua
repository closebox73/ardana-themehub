-- =====================================================
-- Ardana Battery Provider
-- =====================================================
--
-- Description:
-- Automatically detects BAT0-BAT5 and provides
-- battery percentage and remaining time.
--
-- Output:
--   available
--   percent
--   percent_text
--   time_remaining
--
-- =====================================================

local M = {}

-- =====================================================
-- Configuration
-- =====================================================

local UPDATE_INTERVAL = 5

local POWER_SUPPLY =
    "/sys/class/power_supply/"

-- =====================================================
-- State
-- =====================================================

local state = {

    available = false,

    name = nil,

    percent = 100,

    percent_text = "100%",

    time_remaining = "",

    last_update = 0,

}

-- =====================================================
-- Helpers
-- =====================================================

local function read_file(
    path
)

    local file =
        io.open(
            path,
            "r"
        )

    if not file then
        return nil
    end

    local value =
        file:read(
            "*l"
        )

    file:close()

    return value

end

-- =====================================================
-- Detect Battery
-- =====================================================

local function detect_battery()

    for i = 0, 5 do

        local name =
            "BAT" .. i

        local file =
            io.open(
                POWER_SUPPLY ..
                name ..
                "/status",
                "r"
            )

        if file then

            file:close()

            return name

        end

    end

    return nil

end

-- =====================================================
-- Format Time
-- =====================================================

local function format_time(
    hours
)

    if not hours
        or hours <= 0
    then

        return ""

    end

    local total_minutes =
        math.floor(
            hours * 60
        )

    local h =
        math.floor(
            total_minutes / 60
        )

    local m =
        total_minutes % 60

    return string.format(
        "%02d:%02d",
        h,
        m
    )

end

-- =====================================================
-- Desktop Default
-- =====================================================

local function set_default_state()

    state.available =
        false

    state.percent =
        100

    state.percent_text =
        "100%"

    state.time_remaining =
        ""

end

-- =====================================================
-- Update
-- =====================================================

function M.update()

    local now =
        os.time()

    if
        now -
        state.last_update
        < UPDATE_INTERVAL
    then

        return

    end

    state.last_update =
        now

    -- =============================================
    -- Detect Battery
    -- =============================================

    if not state.name then

        state.name =
            detect_battery()

    end

    -- =============================================
    -- No Battery
    -- =============================================

    if not state.name then

        set_default_state()

        return

    end

    local base =
        POWER_SUPPLY ..
        state.name

    -- =============================================
    -- Check Battery
    -- =============================================

    local status =
        read_file(
            base ..
            "/status"
        )

    if not status then

        state.name = nil

        set_default_state()

        return

    end

    -- =============================================
    -- Percentage
    -- =============================================

    local capacity =
        tonumber(
            read_file(
                base ..
                "/capacity"
            )
        )

    if capacity then

        state.available =
            true

        state.percent =
            capacity

        state.percent_text =
            tostring(
                capacity
            )
            .. "%"

    else

        set_default_state()

    end

    -- =============================================
    -- Remaining Time
    -- =============================================

    local energy_now =
        tonumber(
            read_file(
                base ..
                "/energy_now"
            )
        )

    local power_now =
        tonumber(
            read_file(
                base ..
                "/power_now"
            )
        )

    if
        energy_now
        and power_now
        and power_now > 0
    then

        local hours =
            energy_now /
            power_now

        state.time_remaining =
            format_time(
                hours
            )

    else

        state.time_remaining =
            ""

    end

end

-- =====================================================
-- Get
-- =====================================================

function M.get()

    return state

end

return M
