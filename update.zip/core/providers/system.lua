-- =====================================================
-- Ardana System Provider
-- =====================================================

local M = {}

-- =====================================================
-- Configuration
-- =====================================================

local CPU_INTERVAL = 1
local RAM_INTERVAL = 2

local VOLUME_INTERVAL = 2
local BRIGHTNESS_INTERVAL = 2

local HISTORY_SIZE = 60


-- =====================================================
-- State
-- =====================================================

local state = {

    -- CPU
    cpu_usage = 0,

    cpu_history = {},

    cpu_model = "Unknown",
    cpu_cores = 0,
    cpu_threads = 0,

    -- RAM
    ram_used = 0,
    ram_total = 0,
    ram_percent = 0,

    ram_history = {},

    -- Volume
    volume = 0,
    muted = false,

    -- Brightness
    brightness = 100,

    -- Internal
    last_cpu = 0,
    last_ram = 0,
    last_volume = 0,
    last_brightness = 0,

    initialized = false,

}


-- =====================================================
-- Internal State
-- =====================================================

local cpu_previous = {

    total = 0,
    idle = 0,

}


-- =====================================================
-- Helper
-- =====================================================

local function push_history(
    history,
    value
)

    table.insert(
        history,
        value
    )

    if #history > HISTORY_SIZE then

        table.remove(
            history,
            1
        )

    end

end


local function command_exists(
    command
)

    local result =
        os.execute(
            "command -v "
            .. command
            .. " >/dev/null 2>&1"
        )

    return result == true
        or result == 0

end


-- =====================================================
-- CPU Information
-- =====================================================

local function load_cpu_info()

    local file =
        io.open(
            "/proc/cpuinfo",
            "r"
        )

    if not file then

        return

    end

    local model = nil
    local cores = 0
    local threads = 0

    for line in file:lines() do

        -- CPU model
        if not model then

            model =
                line:match(
                    "^model name%s*:%s*(.+)"
                )

        end

        -- Logical processors
        if line:match(
            "^processor%s*:"
        ) then

            threads =
                threads + 1

        end

        -- Physical core count
        local cpu_cores =
            line:match(
                "^cpu cores%s*:%s*(%d+)"
            )

        if cpu_cores then

            cores =
                tonumber(
                    cpu_cores
                )
                or 0

        end

    end

    file:close()

    -- Fallback model
    state.cpu_model =
        model
        or "Unknown"

    -- Fallback cores
    state.cpu_cores =
        cores

    -- Logical processors
    state.cpu_threads =
        threads

end


-- =====================================================
-- CPU Usage
-- =====================================================

local function read_cpu_stat()

    local file =
        io.open(
            "/proc/stat",
            "r"
        )

    if not file then

        return 0,
            0

    end

    local line =
        file:read(
            "*l"
        )
        or ""

    file:close()

    local user,
        nice,
        system,
        idle,
        iowait,
        irq,
        softirq,
        steal =
            line:match(
                "cpu%s+"
                .. "(%d+)%s+"
                .. "(%d+)%s+"
                .. "(%d+)%s+"
                .. "(%d+)%s+"
                .. "(%d+)%s+"
                .. "(%d+)%s+"
                .. "(%d+)%s+"
                .. "(%d+)"
            )

    user =
        tonumber(
            user
        )
        or 0

    nice =
        tonumber(
            nice
        )
        or 0

    system =
        tonumber(
            system
        )
        or 0

    idle =
        tonumber(
            idle
        )
        or 0

    iowait =
        tonumber(
            iowait
        )
        or 0

    irq =
        tonumber(
            irq
        )
        or 0

    softirq =
        tonumber(
            softirq
        )
        or 0

    steal =
        tonumber(
            steal
        )
        or 0

    local total =
        user
        + nice
        + system
        + idle
        + iowait
        + irq
        + softirq
        + steal

    local idle_total =
        idle
        + iowait

    return
        total,
        idle_total

end


local function update_cpu(
    now
)

    if
        now
        - state.last_cpu
        < CPU_INTERVAL
    then

        return

    end

    state.last_cpu =
        now

    local total,
        idle =
            read_cpu_stat()

    if cpu_previous.total > 0 then

        local total_diff =
            total
            - cpu_previous.total

        local idle_diff =
            idle
            - cpu_previous.idle

        if total_diff > 0 then

            state.cpu_usage =
                math.floor(
                    (
                        1
                        - (
                            idle_diff
                            / total_diff
                        )
                    )
                    * 100
                    + 0.5
                )

        end

    end

    cpu_previous.total =
        total

    cpu_previous.idle =
        idle

    push_history(
        state.cpu_history,
        state.cpu_usage
    )

end


-- =====================================================
-- RAM
-- =====================================================

local function update_ram(
    now
)

    if
        now
        - state.last_ram
        < RAM_INTERVAL
    then

        return

    end

    state.last_ram =
        now

    local file =
        io.open(
            "/proc/meminfo",
            "r"
        )

    if not file then

        return

    end

    local total = 0
    local available = 0

    for line in file:lines() do

        if line:match(
            "^MemTotal:"
        ) then

            total =
                tonumber(
                    line:match(
                        "(%d+)"
                    )
                )
                or 0

        elseif line:match(
            "^MemAvailable:"
        ) then

            available =
                tonumber(
                    line:match(
                        "(%d+)"
                    )
                )
                or 0

        end

    end

    file:close()

    local used =
        total
        - available

    if used < 0 then

        used = 0

    end

    state.ram_total =
        total

    state.ram_used =
        used

    if total > 0 then

        state.ram_percent =
            math.floor(
                (
                    used
                    / total
                )
                * 100
                + 0.5
            )

    else

        state.ram_percent = 0

    end

    push_history(
        state.ram_history,
        state.ram_percent
    )

end


-- =====================================================
-- Volume
-- =====================================================

local function update_volume(
    now
)

    if
        now
        - state.last_volume
        < VOLUME_INTERVAL
    then

        return

    end

    state.last_volume =
        now

    if not command_exists(
        "pactl"
    ) then

        return

    end

    local volume_pipe =
        io.popen(
            "pactl get-sink-volume "
            .. "@DEFAULT_SINK@ "
            .. "2>/dev/null"
        )

    if volume_pipe then

        local output =
            volume_pipe:read(
                "*a"
            )
            or ""

        volume_pipe:close()

        local volume =
            tonumber(
                output:match(
                    "(%d+)%%"
                )
            )

        if volume then

            state.volume =
                volume

        end

    end

    local mute_pipe =
        io.popen(
            "pactl get-sink-mute "
            .. "@DEFAULT_SINK@ "
            .. "2>/dev/null"
        )

    if mute_pipe then

        local output =
            mute_pipe:read(
                "*a"
            )
            or ""

        mute_pipe:close()

        state.muted =
            output:match(
                "yes"
            )
            ~= nil

    end

end


-- =====================================================
-- Brightness
-- =====================================================

local function find_backlight()

    local pipe =
        io.popen(
            "ls -1 "
            .. "/sys/class/backlight/ "
            .. "2>/dev/null"
        )

    if not pipe then

        return nil

    end

    local name =
        pipe:read(
            "*l"
        )

    pipe:close()

    if not name
        or name == ""
    then

        return nil

    end

    return
        "/sys/class/backlight/"
        .. name

end


local brightness_path =
    find_backlight()


local function update_brightness(
    now
)

    if
        now
        - state.last_brightness
        < BRIGHTNESS_INTERVAL
    then

        return

    end

    state.last_brightness =
        now

    -- Desktop tanpa brightness control
    if not brightness_path then

        state.brightness = 100

        return

    end

    local current_file =
        io.open(
            brightness_path
            .. "/brightness",
            "r"
        )

    local max_file =
        io.open(
            brightness_path
            .. "/max_brightness",
            "r"
        )

    if not current_file
        or not max_file
    then

        if current_file then

            current_file:close()

        end

        if max_file then

            max_file:close()

        end

        state.brightness = 100

        return

    end

    local current =
        tonumber(
            current_file:read(
                "*l"
            )
        )
        or 0

    local maximum =
        tonumber(
            max_file:read(
                "*l"
            )
        )
        or 0

    current_file:close()
    max_file:close()

    if maximum > 0 then

        state.brightness =
            math.floor(
                (
                    current
                    / maximum
                )
                * 100
                + 0.5
            )

    else

        state.brightness = 100

    end

end


-- =====================================================
-- Init
-- =====================================================

function M.init()

    load_cpu_info()

    local total,
        idle =
            read_cpu_stat()

    cpu_previous.total =
        total

    cpu_previous.idle =
        idle

    state.initialized =
        true

end


-- =====================================================
-- Update
-- =====================================================

function M.update()

    if not state.initialized then

        M.init()

    end

    local now =
        os.time()

    update_cpu(
        now
    )

    update_ram(
        now
    )

    update_volume(
        now
    )

    update_brightness(
        now
    )

end


-- =====================================================
-- Get
-- =====================================================

function M.get()

    return state

end


return M
