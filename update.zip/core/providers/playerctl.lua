-- =====================================================
-- Ardana Playerctl Provider
-- =====================================================

local M = {}

-- =====================================================
-- Config
-- =====================================================

local UPDATE_INTERVAL = 1

-- =====================================================
-- State
-- =====================================================

local state = {

    available = false,
    player = "",
    status = "Stopped",
    icon = "",

    title = "",
    artist = "",
    album = "",

    position = 0,
    length = 0,

    position_text = "00:00",
    length_text = "00:00",

    last_update = 0,
}

-- =====================================================
-- Helpers
-- =====================================================

local function trim(
    value
)
    local result =
        (
            value
            or ""
        ):gsub(
            "^%s*(.-)%s*$",
            "%1"
        )

    return result
end

local function format_time(
    value
)

    local seconds =
        math.floor(
            tonumber(value) or 0
        )

    local minutes =
        math.floor(
            seconds / 60
        )

    seconds =
        seconds % 60

    return string.format(
        "%02d:%02d",
        minutes,
        seconds
    )

end


local function run_command(
    command
)
    local pipe =
        io.popen(
            command
        )

    if not pipe then
        return ""
    end

    local output =
        pipe:read(
            "*a"
        )

    pipe:close()

    return trim(
        output
    )
end

-- =====================================================
-- Player Icons
-- =====================================================

local PLAYER_ICONS = {

    none = "",
    stopped = "",
    playing = "",
    paused = "",
    unknown = "",

}

local function get_player_icon(
    status
)

    if not status
        or status == ""
    then

        return PLAYER_ICONS.none

    end

    if status == "Stopped" then

        return PLAYER_ICONS.stopped

    elseif status == "Playing" then

        return PLAYER_ICONS.playing

    elseif status == "Paused" then

        return PLAYER_ICONS.paused

    end

    return PLAYER_ICONS.unknown

end


local function reset_state()

    state.available = false

    state.player = ""
    state.status = "Stopped"

    state.icon =
        PLAYER_ICONS.none

    state.title = ""
    state.artist = ""
    state.album = ""

    state.position = 0
    state.length = 0

    state.position_text = "00:00"
    state.length_text = "00:00"

end

-- =====================================================
-- Update
-- =====================================================

function M.update()

    local now =
        os.time()

    if
        now - state.last_update
        < UPDATE_INTERVAL
    then
        return
    end

    state.last_update =
        now

    -- =============================================
    -- Check player
    -- =============================================

    local status =
        run_command(
            "playerctl status 2>/dev/null"
        )

    if status == "" then

        reset_state()

        return

    end

    state.available = true

    state.status =
        status

    state.icon =
        get_player_icon(
            status
        )

    -- =============================================
    -- Metadata
    -- =============================================

    local metadata =
        run_command(
            "playerctl metadata --format '{{playerName}}\t{{title}}\t{{artist}}\t{{album}}' 2>/dev/null"
        )

    local player,
        title,
        artist,
        album =
        metadata:match(
            "([^\t]*)\t([^\t]*)\t([^\t]*)\t(.*)"
        )

    state.player =
        player or ""

    state.title =
        title or ""

    state.artist =
        artist or ""

    state.album =
        album or ""

        -- =============================================
        -- Position
        -- =============================================

        local position_output =
            run_command(
                "playerctl position 2>/dev/null"
            )

        local position =
            tonumber(
                position_output
            )

        if position then

            state.position =
                position

        else

            state.position =
                0

        end

        state.position_text =
            format_time(
                state.position
            )

        -- =============================================
        -- Length
        -- =============================================

        state.length =
            tonumber(
                run_command(
                    "playerctl metadata mpris:length 2>/dev/null"
                )
            )
            or 0

        if state.length > 0 then

            state.length =
                state.length / 1000000

        end

        state.length_text =
            format_time(
                state.length
            )

end

-- =====================================================
-- Get
-- =====================================================

function M.get()

    return state

end

-- =====================================================
-- Initial Update
-- =====================================================

M.update()

return M
