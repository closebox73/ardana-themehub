-- =====================================================
-- Ardana Network Provider
-- =====================================================
--
-- Description:
-- Provides shared network statistics.
--
-- Features:
--   - Automatic active interface detection
--   - Automatic Wi-Fi / Wired detection
--   - Wi-Fi SSID
--   - Download speed
--   - Upload speed
--   - Total download
--   - Total upload
--   - Download history
--   - Upload history
--
-- =====================================================

local M = {}

-- =====================================================
-- Configuration
-- =====================================================

local UPDATE_INTERVAL = 1

local HISTORY_SIZE = 60

-- =====================================================
-- State
-- =====================================================

local state = {

    available = false,

    interface = "",

    name = "Disconnected",

    connection_type = "none",

    download = 0,
    upload = 0,

    total_download = 0,
    total_upload = 0,

    download_history = {},
    upload_history = {},

}

-- =====================================================
-- Internal State
-- =====================================================

local last_rx = 0
local last_tx = 0

local last_time = 0

local last_interface = ""

local last_update = 0

-- =====================================================
-- Helpers
-- =====================================================

local function trim(
    value
)

    local result =
        (
            value
            or ""
        ):gsub(
            "^%s*(.-)%s*$",
            "%1"
        )

    return result

end


local function run_command(
    command
)

    local pipe =
        io.popen(
            command
        )

    if not pipe then

        return ""

    end

    local output =
        pipe:read(
            "*a"
        )

    pipe:close()

    return trim(
        output
    )

end


local function file_number(
    path
)

    local file =
        io.open(
            path,
            "r"
        )

    if not file then

        return 0

    end

    local value =
        file:read(
            "*l"
        )

    file:close()

    return tonumber(
        value
    )
    or 0

end


local function file_string(
    path
)

    local file =
        io.open(
            path,
            "r"
        )

    if not file then

        return ""

    end

    local value =
        file:read(
            "*l"
        )

    file:close()

    return trim(
        value
    )

end

-- =====================================================
-- Interface Detection
-- =====================================================

local function detect_interface()

    -- =============================================
    -- Default Route
    -- =============================================

    local interface =
        run_command(
            "ip route show default 2>/dev/null "
            .. "| awk 'NR==1 {print $5}'"
        )

    if interface ~= "" then

        return interface

    end

    -- =============================================
    -- Fallback
    -- =============================================

    local fallback =
        run_command(
            "for i in /sys/class/net/*; do "
            .. "n=$(basename \"$i\"); "
            .. "[ \"$n\" = \"lo\" ] && continue; "
            .. "s=$(cat \"$i/operstate\" 2>/dev/null); "
            .. "[ \"$s\" = \"up\" ] && echo \"$n\" && break; "
            .. "done"
        )

    return fallback

end

-- =====================================================
-- Connection Detection
-- =====================================================

local function is_wireless(
    interface
)

    local path =
        "/sys/class/net/"
        .. interface
        .. "/wireless"

    local handle =
        io.open(
            path,
            "r"
        )

    if handle then

        handle:close()

        return true

    end

    -- Directory check fallback
    local result =
        run_command(
            "[ -d "
            .. string.format(
                "%q",
                path
            )
            .. " ] && echo yes"
        )

    return result == "yes"

end


local function get_wifi_name()

    return run_command(
        "iwgetid -r 2>/dev/null"
    )

end


local function update_connection_info(
    interface
)

    if is_wireless(interface) then

        state.connection_type =
            "wifi"

        local ssid =
            get_wifi_name()

        if ssid ~= "" then

            state.name =
                ssid

        else

            state.name =
                "Wi-Fi"

        end

    else

        state.connection_type =
            "wired"

        state.name =
            "Wired"

    end

end

-- =====================================================
-- History
-- =====================================================

local function add_history(
    history,
    value
)

    table.insert(
        history,
        value
    )

    if #history > HISTORY_SIZE then

        table.remove(
            history,
            1
        )

    end

end

-- =====================================================
-- Reset Interface State
-- =====================================================

local function reset_interface_state()

    last_rx = 0
    last_tx = 0

    last_time = 0

    state.download = 0
    state.upload = 0

    state.total_download = 0
    state.total_upload = 0

    state.download_history = {}
    state.upload_history = {}

end

-- =====================================================
-- Update
-- =====================================================

function M.update()

    local now =
        os.time()

    -- =============================================
    -- Update Interval
    -- =============================================

    if last_update > 0
        and now - last_update < UPDATE_INTERVAL
    then

        return

    end

    last_update =
        now

    -- =============================================
    -- Detect Interface
    -- =============================================

    local interface =
        detect_interface()

    -- =============================================
    -- No Connection
    -- =============================================

    if interface == "" then

        state.available =
            false

        state.interface =
            ""

        state.name =
            "Disconnected"

        state.connection_type =
            "none"

        state.download =
            0

        state.upload =
            0

        return

    end

    -- =============================================
    -- Interface Changed
    -- =============================================

    if interface ~= last_interface then

        reset_interface_state()

        last_interface =
            interface

        state.interface =
            interface

    end

    -- =============================================
    -- Connection Information
    -- =============================================

    update_connection_info(
        interface
    )

    -- =============================================
    -- Statistics Paths
    -- =============================================

    local base =
        "/sys/class/net/"
        .. interface
        .. "/statistics/"

    local rx =
        file_number(
            base
            .. "rx_bytes"
        )

    local tx =
        file_number(
            base
            .. "tx_bytes"
        )

    -- =============================================
    -- First Sample
    -- =============================================

    if last_time == 0 then

        last_rx =
            rx

        last_tx =
            tx

        last_time =
            now

        state.total_download =
            rx

        state.total_upload =
            tx

        state.available =
            true

        return

    end

    -- =============================================
    -- Calculate Delta
    -- =============================================

    local elapsed =
        now
        - last_time

    if elapsed <= 0 then

        return

    end

    local rx_delta =
        rx
        - last_rx

    local tx_delta =
        tx
        - last_tx

    -- =============================================
    -- Prevent Negative Values
    -- =============================================

    if rx_delta < 0 then

        rx_delta =
            0

    end

    if tx_delta < 0 then

        tx_delta =
            0

    end

    -- =============================================
    -- Speed
    -- =============================================

    state.download =
        rx_delta
        / elapsed

    state.upload =
        tx_delta
        / elapsed

    -- =============================================
    -- Total
    -- =============================================

    state.total_download =
        rx

    state.total_upload =
        tx

    -- =============================================
    -- History
    -- =============================================

    add_history(
        state.download_history,
        state.download
    )

    add_history(
        state.upload_history,
        state.upload
    )

    -- =============================================
    -- Save Previous Values
    -- =============================================

    last_rx =
        rx

    last_tx =
        tx

    last_time =
        now

    state.available =
        true

end

-- =====================================================
-- Get
-- =====================================================

function M.get()

    return state

end

return M
