#!/usr/bin/env python3

import os
import shutil
import subprocess

import gi

gi.require_version(
    "Gtk",
    "3.0",
)

from gi.repository import Gtk

from widgets.common import (
    create_link_row,
    create_section,
)

from widgets.update_card import UpdateCard


# =========================================================
# Ardana Installation Paths
# =========================================================

HOME = os.path.expanduser("~")

ARDANA_DIR = os.path.join(
    HOME,
    ".config",
    "Ardana",
)

THEMEHUB_DIR = os.path.join(
    HOME,
    ".local",
    "share",
    "ArdanaThemeHub",
)

ICON_DIR = os.path.join(
    HOME,
    ".local",
    "share",
    "icons",
    "hicolor",
)

DESKTOP_FILE = os.path.join(
    HOME,
    ".local",
    "share",
    "applications",
    "ardana-themehub.desktop",
)



# =========================================================
# Uninstall Button Styling
# =========================================================

UNINSTALL_CSS = """
.ardana-uninstall-button {
    min-height: 44px;
    font-size: 15px;
    font-weight: 600;
}
"""

class AboutPage(Gtk.Box):

    def __init__(
        self,
    ):

        super().__init__(
            orientation=Gtk.Orientation.VERTICAL
        )

        css_provider = Gtk.CssProvider()
        css_provider.load_from_data(
            UNINSTALL_CSS.encode("utf-8")
        )

        screen = self.get_screen()

        Gtk.StyleContext.add_provider_for_screen(
            screen,
            css_provider,
            Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION,
        )

        # =========================
        # Header
        # =========================

        header = Gtk.Box(
            orientation=Gtk.Orientation.VERTICAL
        )

        header.set_margin_start(
            28
        )

        header.set_margin_end(
            20
        )

        header.set_margin_top(
            20
        )

        header.set_margin_bottom(
            14
        )

        self.pack_start(
            header,
            False,
            False,
            0
        )

        # =========================
        # Header row
        # Same structure as Dashboard
        # =========================

        header_row = Gtk.Box(
            orientation=Gtk.Orientation.HORIZONTAL,
            spacing=20
        )

        header.pack_start(
            header_row,
            False,
            False,
            0
        )

        # =========================
        # Header left
        # =========================

        header_left = Gtk.Box(
            orientation=Gtk.Orientation.VERTICAL,
            spacing=5
        )

        header_left.set_valign(
            Gtk.Align.START
        )

        title = Gtk.Label(
            label="About"
        )

        title.set_xalign(
            0
        )

        title.set_valign(
            Gtk.Align.START
        )

        title.get_style_context().add_class(
            "page-title"
        )

        header_left.pack_start(
            title,
            False,
            False,
            0
        )

        subtitle = Gtk.Label(
            label="Learn more about Ardana ThemeHub"
        )

        subtitle.set_xalign(
            0
        )

        subtitle.set_valign(
            Gtk.Align.START
        )

        subtitle.get_style_context().add_class(
            "page-subtitle"
        )

        header_left.pack_start(
            subtitle,
            False,
            False,
            0
        )

        # =========================
        # Combine header
        # =========================

        header_row.pack_start(
            header_left,
            True,
            True,
            0
        )

        # =========================
        # Scroll area
        # Same structure as Dashboard
        # =========================

        scroll = Gtk.ScrolledWindow()

        scroll.set_policy(
            Gtk.PolicyType.NEVER,
            Gtk.PolicyType.AUTOMATIC
        )

        scroll.set_vexpand(
            True
        )

        scroll.set_margin_bottom(
            12
        )

        self.pack_start(
            scroll,
            True,
            True,
            0
        )

        # =========================
        # Scroll content
        # No horizontal margin here
        # =========================

        scroll_content = Gtk.Box(
            orientation=Gtk.Orientation.VERTICAL
        )

        scroll_content.set_valign(
            Gtk.Align.START
        )

        scroll.add(
            scroll_content
        )

        # =========================
        # About content
        # Equivalent to Dashboard theme_grid
        # =========================

        about_content = Gtk.Box(
            orientation=Gtk.Orientation.VERTICAL,
            spacing=24
        )

        about_content.set_valign(
            Gtk.Align.START
        )

        about_content.set_hexpand(
            True
        )

        about_content.set_margin_start(
            20
        )

        about_content.set_margin_end(
            20
        )

        about_content.set_margin_bottom(
            20
        )

        scroll_content.pack_start(
            about_content,
            False,
            False,
            0
        )

        # =========================
        # Update Card
        # =========================

        about_content.pack_start(
            UpdateCard(),
            False,
            False,
            0
        )

        # =========================
        # Ardana ThemeHub
        # =========================

        about_content.pack_start(
            self.build_about(),
            False,
            False,
            0
        )

        # =========================
        # Official Resources
        # =========================

        about_content.pack_start(
            self.build_resources(),
            False,
            False,
            0
        )

        # =========================
        # Support Development
        # =========================

        about_content.pack_start(
            self.build_support(),
            False,
            False,
            0
        )

        # =========================
        # Danger Zone
        # =========================

        about_content.pack_start(
            self.build_danger_zone(),
            False,
            False,
            0
        )

    # =====================================================
    # Ardana ThemeHub
    # =====================================================

    def build_about(
        self,
    ):

        section = create_section(
            "Ardana ThemeHub"
        )

        description = Gtk.Label(
            label=(
                "Ardana ThemeHub is the central place for managing Ardana "
                "themes. Discover new themes, install them, manage installed "
                "themes, and customize supported options from one application. "
                "\n\n"
                "Each Ardana theme is designed as a complete package that "
                "works together with the Ardana runtime. Themes may include "
                "multiple Conky configurations, Lua scripts, visual components, "
                "colors, scaling settings, and other resources required for the "
                "theme to function correctly."
                "\n\n"
                "Because themes are connected to their runtime structure, theme "
                "files and folders should remain together and should not be "
                "separated or moved individually. Ardana ThemeHub manages themes "
                "as complete packages to ensure that every configuration and "
                "component can continue to work properly."
            )
        )

        description.set_line_wrap(
            True
        )

        description.set_xalign(
            0
        )

        description.set_yalign(
            0
        )

        section.pack_start(
            description,
            False,
            False,
            0
        )

        return section

    # =====================================================
    # Official Resources
    # =====================================================

    def build_resources(
        self,
    ):

        section = create_section(
            "Official Resources"
        )

        section.pack_start(
            create_link_row(
                "GitHub",
                "Source code and development",
                "https://github.com/closebox73/",
            ),
            False,
            False,
            0
        )

        section.pack_start(
            create_link_row(
                "Documentation",
                "Ardana documentation and guides",
                "https://malformed-blog.blogspot.com",
            ),
            False,
            False,
            0
        )

        return section

    # =====================================================
    # Support Development
    # =====================================================

    def build_support(
        self,
    ):

        section = create_section(
            "Support Development"
        )

        section.pack_start(
            create_link_row(
                "Ko-fi",
                "Support the project",
                "https://ko-fi.com/closebox73x",
            ),
            False,
            False,
            0
        )

        section.pack_start(
            create_link_row(
                "PayPal",
                "Support development",
                "https://paypal.me/closebox73",
            ),
            False,
            False,
            0
        )

        return section


    # =====================================================
    # Danger Zone
    # =====================================================

    def build_danger_zone(
        self,
    ):

        section = create_section(
            "Danger Zone"
        )

        description = Gtk.Label(
            label=(
                "Remove Ardana Core, Ardana ThemeHub, "
                "the Ardana application icon, and the "
                "Ardana ThemeHub launcher from this system."
            )
        )

        description.set_line_wrap(
            True
        )

        description.set_xalign(
            0
        )

        description.set_yalign(
            0
        )

        section.pack_start(
            description,
            False,
            False,
            0
        )

        button = Gtk.Button(
            label="Uninstall Ardana"
        )

        button.set_halign(
            Gtk.Align.FILL
        )

        button.set_hexpand(
            True
        )

        button.get_style_context().add_class(
            "destructive-action"
        )

        button.get_style_context().add_class(
            "ardana-uninstall-button"
        )

        button.connect(
            "clicked",
            self.on_uninstall_clicked,
        )

        section.pack_start(
            button,
            False,
            False,
            8
        )

        return section

    def on_uninstall_clicked(
        self,
        button,
    ):

        dialog = Gtk.MessageDialog(
            transient_for=self.get_toplevel(),
            modal=True,
            message_type=Gtk.MessageType.WARNING,
            buttons=Gtk.ButtonsType.CANCEL,
            text="Uninstall Ardana ThemeHub?",
        )

        dialog.format_secondary_text(
            "This will remove Ardana Core, Ardana ThemeHub, "
            "the Ardana application icon, and the ThemeHub "
            "launcher from this system."
        )

        dialog.add_button(
            "Uninstall",
            Gtk.ResponseType.YES,
        )

        response = dialog.run()

        dialog.destroy()

        if response != Gtk.ResponseType.YES:
            return

        self.uninstall_ardana()

    def uninstall_ardana(
        self,
    ):

        # Remove only Ardana-owned directories/files.
        for path in (
            ARDANA_DIR,
            THEMEHUB_DIR,
            DESKTOP_FILE,
        ):

            try:

                if os.path.isdir(path):
                    shutil.rmtree(path)

                elif os.path.isfile(path):
                    os.remove(path)

            except Exception as error:

                print(
                    "[Ardana ThemeHub] "
                    "Failed to remove:",
                    path,
                    error,
                )

        # Remove Ardana icons only.
        for size in (
            "32x32",
            "48x48",
            "128x128",
            "256x256",
            "512x512",
        ):

            icon_path = os.path.join(
                ICON_DIR,
                size,
                "apps",
                "Ardana.png",
            )

            try:

                if os.path.isfile(
                    icon_path
                ):
                    os.remove(
                        icon_path
                    )

            except Exception as error:

                print(
                    "[Ardana ThemeHub] "
                    "Failed to remove icon:",
                    icon_path,
                    error,
                )

        # Refresh icon cache if available.
        try:

            subprocess.run(
                [
                    "gtk-update-icon-cache",
                    ICON_DIR,
                ],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                check=False,
            )

        except Exception:
            pass

        # Refresh desktop database if available.
        applications_dir = os.path.dirname(
            DESKTOP_FILE
        )

        try:

            subprocess.run(
                [
                    "update-desktop-database",
                    applications_dir,
                ],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                check=False,
            )

        except Exception:
            pass

        # Ardana ThemeHub is about to disappear.
        # Close this application after cleanup.
        Gtk.main_quit()
