import os
import subprocess
import signal
import json

import gi

gi.require_version("Gtk", "3.0")
gi.require_version("GdkPixbuf", "2.0")

from gi.repository import (
    Gtk,
    Gdk,
    GdkPixbuf
)

from dialogs.customize import CustomizeDialog


ARDANA_DIR = os.path.expanduser(
    "~/.config/Ardana"
)

THEMES_DIR = os.path.join(
    ARDANA_DIR,
    "themes"
)

AUTOSTART_STATE = os.path.join(
    ARDANA_DIR,
    "autostart.json"
)

AUTOSTART_DIR = os.path.expanduser(
    "~/.config/autostart"
)

AUTOSTART_DESKTOP = os.path.join(
    AUTOSTART_DIR,
    "ardana-themehub.desktop"
)

AUTOSTART_LAUNCHER = os.path.join(
    ARDANA_DIR,
    "autostart.py"
)

# =====================================================
# Autostart State
# =====================================================

def load_autostart_state():

    default = {
        "enabled": False,
        "configs": []
    }

    if not os.path.isfile(
        AUTOSTART_STATE
    ):
        return default

    try:

        with open(
            AUTOSTART_STATE,
            "r",
            encoding="utf-8"
        ) as file:

            data = json.load(
                file
            )

        if not isinstance(
            data,
            dict
        ):
            return default

        enabled = bool(
            data.get(
                "enabled",
                False
            )
        )

        configs = data.get(
            "configs",
            []
        )

        if not isinstance(
            configs,
            list
        ):
            configs = []

        return {
            "enabled": enabled,
            "configs": configs
        }

    except Exception as error:

        print(
            "Failed to load autostart state:",
            error
        )

        return default


def save_autostart_state(
    state
):

    try:

        os.makedirs(
            ARDANA_DIR,
            exist_ok=True
        )

        with open(
            AUTOSTART_STATE,
            "w",
            encoding="utf-8"
        ) as file:

            json.dump(
                state,
                file,
                indent=4
            )

        return True

    except Exception as error:

        print(
            "Failed to save autostart state:",
            error
        )

        return False


def add_autostart_config(
    conf_path
):

    state = load_autostart_state()

    conf_path = os.path.realpath(
        conf_path
    )

    configs = state.get(
        "configs",
        []
    )

    if conf_path not in configs:

        configs.append(
            conf_path
        )

    state["configs"] = configs

    save_autostart_state(
        state
    )


def remove_autostart_config(
    conf_path
):

    state = load_autostart_state()

    conf_path = os.path.realpath(
        conf_path
    )

    configs = state.get(
        "configs",
        []
    )

    state["configs"] = [
        path
        for path in configs
        if path != conf_path
    ]

    save_autostart_state(
        state
    )


class ThemePreview(Gtk.DrawingArea):

    def __init__(self, image_path):

        super().__init__()

        self.image_path = image_path
        self.pixbuf = None

        self.set_hexpand(True)
        self.set_vexpand(True)

        self.load_image()

        self.connect(
            "draw",
            self.on_draw
        )

    # =====================================================
    # Preferred size
    # =====================================================

    def load_image(self):

        if not os.path.isfile(
            self.image_path
        ):
            return

        try:

            self.pixbuf = (
                GdkPixbuf.Pixbuf.new_from_file(
                    self.image_path
                )
            )

        except Exception:

            self.pixbuf = None

    def on_draw(
        self,
        widget,
        cr
    ):

        if self.pixbuf is None:
            return False

        width = self.get_allocated_width()
        height = self.get_allocated_height()

        if width <= 0 or height <= 0:
            return False

        image_width = self.pixbuf.get_width()
        image_height = self.pixbuf.get_height()

        if image_width <= 0 or image_height <= 0:
            return False

        scale_x = width / image_width
        scale_y = height / image_height

        scale = max(
            scale_x,
            scale_y
        )

        new_width = int(
            image_width * scale
        )

        new_height = int(
            image_height * scale
        )

        scaled = self.pixbuf.scale_simple(
            new_width,
            new_height,
            GdkPixbuf.InterpType.BILINEAR
        )

        if scaled is None:
            return False

        x = (width - new_width) / 2
        y = (height - new_height) / 2

        # =========================
        # Rounded corners
        # =========================

        radius = 3

        cr.new_sub_path()

        cr.arc(
            width - radius,
            radius,
            radius,
            -1.5708,
            0
        )

        cr.arc(
            width - radius,
            height - radius,
            radius,
            0,
            1.5708
        )

        cr.arc(
            radius,
            height - radius,
            radius,
            1.5708,
            3.1416
        )

        cr.arc(
            radius,
            radius,
            radius,
            3.1416,
            4.7124
        )

        cr.close_path()

        cr.clip()

        Gdk.cairo_set_source_pixbuf(
            cr,
            scaled,
            x,
            y
        )

        cr.paint()

        return False


class ThemeCard(Gtk.Box):

    def __init__(
        self,
        theme_name,
        theme_path,
        applied=False
    ):

        super().__init__(
            orientation=Gtk.Orientation.VERTICAL,
            spacing=0
        )

        self.theme_name = theme_name
        self.theme_path = theme_path

        self.metadata = self.load_metadata()

        version = self.metadata.get(
            "version",
            "0.0"
        )

        self.get_style_context().add_class(
            "theme-card"
        )

        # =========================
        # Preview
        # =========================

        preview_path = os.path.join(
            theme_path,
            "preview.jpg"
        )

        preview = ThemePreview(
            preview_path
        )

        preview.set_size_request(
            396,
            223
        )

        preview.set_margin_top(
            10
        )

        preview.set_halign(
            Gtk.Align.CENTER
        )

        self.pack_start(
            preview,
            False,
            False,
            0
        )

        # =========================
        # Information
        # =========================

        info = Gtk.Box(
            orientation=Gtk.Orientation.VERTICAL,
            spacing=10
        )

        info.set_border_width(
            16
        )

        # =========================
        # Theme title
        # =========================

        title_row = Gtk.Box(
            orientation=Gtk.Orientation.HORIZONTAL,
            spacing=8
        )

        name_label = Gtk.Label(
            label=theme_name
        )

        name_label.set_xalign(
            0
        )

        name_label.get_style_context().add_class(
            "theme-name"
        )

        title_row.pack_start(
            name_label,
            False,
            False,
            0
        )

        version_label = Gtk.Label(
            label=f"v{version}"
        )

        version_label.set_xalign(
            0
        )

        version_label.get_style_context().add_class(
            "theme-name"
        )

        title_row.pack_start(
            version_label,
            False,
            False,
            0
        )

        # =========================
        # Customize
        # =========================

        customize_button = Gtk.Button()

        customize_icon = Gtk.Label(
            label="󰒓"
        )

        customize_icon.get_style_context().add_class(
            "customize-icon"
        )

        customize_button.add(
            customize_icon
        )

        customize_button.set_tooltip_text(
            "Customize"
        )

        customize_button.set_relief(
            Gtk.ReliefStyle.NONE
        )

        customize_button.set_halign(
            Gtk.Align.END
        )

        customize_button.connect(
            "clicked",
            self.on_customize_clicked
        )

        title_row.pack_end(
            customize_button,
            False,
            False,
            0
        )

        info.pack_start(
            title_row,
            False,
            False,
            0
        )

        # =========================
        # Config toggles
        # =========================

        conf_files = []

        for filename in os.listdir(
            self.theme_path
        ):

            if not filename.endswith(
                ".conf"
            ):
                continue

            conf_path = os.path.join(
                self.theme_path,
                filename
            )

            if os.path.isfile(
                conf_path
            ):

                conf_files.append(
                    conf_path
                )

        conf_files.sort(
            key=str.lower
        )

        for conf_path in conf_files:

            filename = os.path.basename(
                conf_path
            )

            config_name = os.path.splitext(
                filename
            )[0]

            toggle_row = Gtk.Box(
                orientation=Gtk.Orientation.HORIZONTAL,
                spacing=8
            )

            toggle_label = Gtk.Label(
                label=config_name
            )

            toggle_label.set_xalign(
                0
            )

            toggle_label.get_style_context().add_class(
                "theme-info"
            )

            toggle_row.pack_start(
                toggle_label,
                True,
                True,
                0
            )

            switch = Gtk.Switch()

            active = self.is_conky_running(
                conf_path
            )

            switch.set_active(
                active
            )

            switch.set_halign(
                Gtk.Align.END
            )

            switch.connect(
                "state-set",
                self.on_config_toggle,
                conf_path
            )

            toggle_row.pack_end(
                switch,
                False,
                False,
                0
            )

            info.pack_start(
                toggle_row,
                False,
                False,
                0
            )

        self.pack_start(
            info,
            False,
            False,
            0
        )

    # =====================================================
    # Metadata
    # =====================================================

    def load_metadata(
        self
    ):

        metadata_path = os.path.join(
            self.theme_path,
            "metadata.json"
        )

        if not os.path.isfile(
            metadata_path
        ):
            return {}

        try:

            with open(
                metadata_path,
                "r",
                encoding="utf-8"
            ) as file:

                return json.load(
                    file
                )

        except Exception as e:

            print(
                "Failed to load metadata:",
                e
            )

            return {}

    # =====================================================
    # Conky control
    # =====================================================

    def is_conky_running(
        self,
        conf_path
    ):

        try:

            result = subprocess.run(
                [
                    "pgrep",
                    "-af",
                    "conky"
                ],
                capture_output=True,
                text=True,
                check=False
            )

        except Exception:

            return False

        conf_path = os.path.realpath(
            conf_path
        )

        for line in result.stdout.splitlines():

            parts = line.split(
                None,
                1
            )

            if len(parts) < 2:
                continue

            command = parts[1]

            if conf_path in command:

                return True

        return False

    def start_conky(
        self,
        conf_path
    ):

        try:

            subprocess.Popen(
                [
                    "conky",
                    "-c",
                    conf_path
                ],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                start_new_session=True
            )

        except Exception as e:

            print(
                "Failed to start Conky:",
                e
            )

    def stop_conky(
        self,
        conf_path
    ):

        conf_path = os.path.realpath(
            conf_path
        )

        try:

            result = subprocess.run(
                [
                    "pgrep",
                    "-af",
                    "conky"
                ],
                capture_output=True,
                text=True,
                check=False
            )

            for line in result.stdout.splitlines():

                parts = line.split(
                    None,
                    1
                )

                if len(parts) < 2:
                    continue

                pid = int(
                    parts[0]
                )

                command = parts[1]

                if conf_path not in command:
                    continue

                if pid == os.getpid():
                    continue

                os.kill(
                    pid,
                    signal.SIGTERM
                )

        except Exception as e:

            print(
                "Failed to stop Conky:",
                e
            )

    def on_config_toggle(
        self,
        switch,
        state,
        conf_path
    ):

        if state:

            self.start_conky(
                conf_path
            )

            add_autostart_config(
                conf_path
            )

        else:

            self.stop_conky(
                conf_path
            )

            remove_autostart_config(
                conf_path
            )

        return False

    # =====================================================
    # Customize
    # =====================================================

    def on_customize_clicked(
        self,
        button,
    ):

        parent = self.get_toplevel()

        dialog = CustomizeDialog(
            parent=parent,
            theme_name=self.theme_name,
            theme_path=self.theme_path,
            metadata=self.metadata,
        )

        dialog.run()


class DashboardPage(Gtk.Box):

    def __init__(self):

        super().__init__(
            orientation=Gtk.Orientation.VERTICAL
        )

        # =========================
        # Header
        # =========================

        header = Gtk.Box(
            orientation=Gtk.Orientation.VERTICAL
        )

        header.set_margin_start(
            28
        )

        header.set_margin_end(
            20
        )

        header.set_margin_top(
            20
        )

        header.set_margin_bottom(
            14
        )

        self.pack_start(
            header,
            False,
            False,
            0
        )

        # =========================
        # Header row
        # =========================

        header_row = Gtk.Box(
            orientation=Gtk.Orientation.HORIZONTAL,
            spacing=20
        )

        header.pack_start(
            header_row,
            False,
            False,
            0
        )

        # =========================
        # Left side
        # =========================

        header_left = Gtk.Box(
            orientation=Gtk.Orientation.VERTICAL,
            spacing=5
        )

        header_left.set_valign(
            Gtk.Align.START
        )

        title = Gtk.Label(
            label="Installed Themes"
        )

        title.set_xalign(
            0
        )

        title.set_valign(
            Gtk.Align.START
        )

        title.get_style_context().add_class(
            "page-title"
        )

        header_left.pack_start(
            title,
            False,
            False,
            0
        )

        subtitle = Gtk.Label(
            label="Themes installed on your system"
        )

        subtitle.set_xalign(
            0
        )

        subtitle.set_valign(
            Gtk.Align.START
        )

        subtitle.get_style_context().add_class(
            "page-subtitle"
        )

        header_left.pack_start(
            subtitle,
            False,
            False,
            0
        )

        # =========================
        # Right side
        # =========================

        header_controls = Gtk.Box(
            orientation=Gtk.Orientation.HORIZONTAL,
            spacing=6
        )

        header_controls.set_halign(
            Gtk.Align.END
        )

        header_controls.set_valign(
            Gtk.Align.START
        )

        # =========================
        # Stop All
        # =========================

        stop_all_button = Gtk.Button(
            label="Stop All"
        )



        stop_all_button.get_style_context().add_class(
            "dashboard-control"
        )

        stop_all_button.set_tooltip_text(
            "Stop all running Ardana themes"
        )

        stop_all_button.set_size_request(
            100,
            -1
        )

        stop_all_button.connect(
            "clicked",
            self.on_stop_all_clicked
        )

        header_controls.pack_start(
            stop_all_button,
            False,
            False,
            0
        )

        # =========================
        # Search
        # =========================

        search = Gtk.SearchEntry()

        search.set_placeholder_text(
            "Search themes..."
        )

        search.get_style_context().add_class(
            "dashboard-control"
        )

        search.set_width_chars(
            32
        )

        search.connect(
            "search-changed",
            self.on_search_changed
        )

        self.search_entry = search

        header_controls.pack_start(
            search,
            False,
            False,
            0
        )

        # =========================
        # Combine
        # =========================

        header_row.pack_start(
            header_left,
            True,
            True,
            0
        )

        header_row.pack_end(
            header_controls,
            False,
            False,
            0
        )

        # =========================
        # Theme scroll area
        # =========================

        scroll = Gtk.ScrolledWindow()

        scroll.set_policy(
            Gtk.PolicyType.NEVER,
            Gtk.PolicyType.AUTOMATIC
        )

        scroll.set_vexpand(
            True
        )

        scroll.set_margin_bottom(
            12
        )

        self.pack_start(
            scroll,
            True,
            True,
            0
        )

        # =========================
        # Theme content
        # =========================

        theme_content = Gtk.Box(
            orientation=Gtk.Orientation.VERTICAL
        )

        theme_content.set_valign(
            Gtk.Align.START
        )

        scroll.add(
            theme_content
        )

        # =========================
        # Theme grid
        # =========================

        theme_grid = Gtk.Grid()

        theme_grid.set_valign(
            Gtk.Align.START
        )

        theme_grid.set_hexpand(
            True
        )

        theme_grid.set_column_spacing(
            18
        )

        theme_grid.set_row_spacing(
            18
        )

        theme_grid.set_margin_start(
            20
        )

        theme_grid.set_margin_end(
            20
        )

        theme_grid.set_margin_bottom(
            20
        )

        theme_grid.set_column_homogeneous(
            True
        )

        theme_content.pack_start(
            theme_grid,
            False,
            False,
            0
        )

        self.theme_grid = theme_grid

        # =========================
        # Load themes
        # =========================

        self.load_themes()

    # =====================================================
    # Stop All
    # =====================================================

    def on_stop_all_clicked(
        self,
        button
    ):

        running_configs = []

        if not os.path.isdir(
            THEMES_DIR
        ):
            return

        for root, dirs, files in os.walk(
            THEMES_DIR
        ):

            for filename in files:

                if not filename.endswith(
                    ".conf"
                ):
                    continue

                conf_path = os.path.realpath(
                    os.path.join(
                        root,
                        filename
                    )
                )

                if self.is_conky_running(
                    conf_path
                ):
                    running_configs.append(
                        conf_path
                    )

        for conf_path in running_configs:

            self.stop_conky_for_config(
                conf_path
            )

        self.load_themes()

    # =====================================================
    # Stop All helpers
    # =====================================================

    def is_conky_running(
        self,
        conf_path
    ):

        conf_path = os.path.realpath(
            conf_path
        )

        try:

            result = subprocess.run(
                [
                    "pgrep",
                    "-af",
                    "conky"
                ],
                capture_output=True,
                text=True,
                check=False
            )

        except Exception:

            return False

        for line in result.stdout.splitlines():

            parts = line.split(
                None,
                1
            )

            if len(parts) < 2:
                continue

            command = parts[1]

            if conf_path in command:
                return True

        return False

    def stop_conky_for_config(
        self,
        conf_path
    ):

        conf_path = os.path.realpath(
            conf_path
        )

        try:

            result = subprocess.run(
                [
                    "pgrep",
                    "-af",
                    "conky"
                ],
                capture_output=True,
                text=True,
                check=False
            )

            for line in result.stdout.splitlines():

                parts = line.split(
                    None,
                    1
                )

                if len(parts) < 2:
                    continue

                try:
                    pid = int(parts[0])
                except ValueError:
                    continue

                command = parts[1]

                if conf_path not in command:
                    continue

                if pid == os.getpid():
                    continue

                os.kill(
                    pid,
                    signal.SIGTERM
                )

        except Exception as error:

            print(
                "Failed to stop Conky:",
                error
            )

    # =====================================================
    # Theme search
    # =====================================================

    def on_search_changed(
        self,
        search
    ):

        query = (
            search
            .get_text()
            .strip()
            .lower()
        )

        # =========================
        # Remove current layout
        # =========================

        for child in self.theme_grid.get_children():

            self.theme_grid.remove(
                child
            )

        # =========================
        # Filter all cards
        # =========================

        visible_cards = []

        for card in self.theme_cards:

            if (
                not query
                or query in card.theme_name.lower()
            ):

                visible_cards.append(
                    card
                )

        # =========================
        # Rebuild grid
        # =========================

        for index, card in enumerate(
            visible_cards
        ):

            column = index % 2
            row = index // 2

            self.theme_grid.attach(
                card,
                column,
                row,
                1,
                1
            )

        # =========================
        # Keep 2-column layout
        # =========================

        if len(visible_cards) % 2 == 1:

            spacer = Gtk.Box()

            spacer.set_hexpand(
                True
            )

            self.theme_grid.attach(
                spacer,
                1,
                len(visible_cards) // 2,
                1,
                1
            )

        self.theme_grid.show_all()

    # =====================================================
    # Theme loading
    # =====================================================

    def load_themes(self):

        # Remove existing cards
        for child in self.theme_grid.get_children():

            self.theme_grid.remove(
                child
            )

        if not os.path.isdir(
            THEMES_DIR
        ):
            return

        theme_names = []

        for name in os.listdir(
            THEMES_DIR
        ):

            theme_path = os.path.join(
                THEMES_DIR,
                name
            )

            if not os.path.isdir(
                theme_path
            ):
                continue

            preview_path = os.path.join(
                theme_path,
                "preview.jpg"
            )

            if not os.path.isfile(
                preview_path
            ):
                continue

            theme_names.append(
                name
            )

        theme_names.sort(
            key=str.lower
        )

        self.theme_cards = []

        for index, theme_name in enumerate(
            theme_names
        ):

            theme_path = os.path.join(
                THEMES_DIR,
                theme_name
            )

            card = ThemeCard(
                theme_name,
                theme_path,
                False
            )

            self.theme_cards.append(
                card
            )

            card.set_hexpand(
                True
            )

            card.set_halign(
                Gtk.Align.FILL
            )

            card.set_valign(
                Gtk.Align.START
            )

            column = index % 2
            row = index // 2

            self.theme_grid.attach(
                card,
                column,
                row,
                1,
                1
            )


        # =========================
        # Keep 2-column layout
        # =========================

        if len(theme_names) % 2 == 1:

            spacer = Gtk.Box()

            spacer.set_hexpand(
                True
            )

            self.theme_grid.attach(
                spacer,
                1,
                len(theme_names) // 2,
                1,
                1
            )


        self.theme_grid.show_all()

    # =====================================================
    # Enable Autostart
    # =====================================================

    def enable_autostart(
        self,
    ):

        try:

            os.makedirs(
                AUTOSTART_DIR,
                exist_ok=True
            )

            desktop_content = f"""[Desktop Entry]
Type=Application
Name=Ardana ThemeHub
Exec=python3 {AUTOSTART_LAUNCHER}
Terminal=false
X-GNOME-Autostart-enabled=true
"""

            with open(
                AUTOSTART_DESKTOP,
                "w",
                encoding="utf-8"
            ) as file:

                file.write(
                    desktop_content
                )

            self.create_autostart_launcher()

            print(
                "Ardana autostart enabled"
            )

        except Exception as error:

            print(
                "Failed to enable autostart:",
                error
            )


    # =====================================================
    # Disable Autostart
    # =====================================================

    def disable_autostart(
        self,
    ):

        try:

            if os.path.isfile(
                AUTOSTART_DESKTOP
            ):

                os.remove(
                    AUTOSTART_DESKTOP
                )

            print(
                "Ardana autostart disabled"
            )

        except Exception as error:

            print(
                "Failed to disable autostart:",
                error
            )

    # =====================================================
    # Create Autostart Launcher
    # =====================================================

    def create_autostart_launcher(
        self,
    ):

        launcher_content = """import json
import os
import subprocess


ARDANA_DIR = os.path.expanduser(
    "~/.config/Ardana"
)

AUTOSTART_STATE = os.path.join(
    ARDANA_DIR,
    "autostart.json"
)


def main():

    if not os.path.isfile(
        AUTOSTART_STATE
    ):
        return

    try:

        with open(
            AUTOSTART_STATE,
            "r",
            encoding="utf-8"
        ) as file:

            state = json.load(
                file
            )

    except Exception:

        return

    if not state.get(
        "enabled",
        False
    ):
        return

    configs = state.get(
        "configs",
        []
    )

    if not isinstance(
        configs,
        list
    ):
        return

    for conf_path in configs:

        if not os.path.isfile(
            conf_path
        ):
            continue

        try:

            subprocess.Popen(
                [
                    "conky",
                    "-c",
                    conf_path
                ],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                start_new_session=True
            )

        except Exception:

            pass


if __name__ == "__main__":
    main()
"""

        try:

            with open(
                AUTOSTART_LAUNCHER,
                "w",
                encoding="utf-8"
            ) as file:

                file.write(
                    launcher_content
                )

        except Exception as error:

            print(
                "Failed to create autostart launcher:",
                error
            )
