import os
import subprocess

import gi

gi.require_version("Gtk", "3.0")
from gi.repository import Gtk


# =====================================================
# Paths
# =====================================================

HOME = os.path.expanduser("~")

ARDANA_DIR = os.path.join(
    HOME,
    ".config",
    "Ardana",
)

CONFIG_DIR = os.path.join(
    ARDANA_DIR,
    "config",
)

WEATHER_CONFIG = os.path.join(
    CONFIG_DIR,
    "weather.conf",
)

UNIT_CONFIG = os.path.join(
    CONFIG_DIR,
    "unit.conf",
)

TIME_CONFIG = os.path.join(
    CONFIG_DIR,
    "time.conf",
)

WEATHER_SCRIPT = os.path.join(
    ARDANA_DIR,
    "scripts",
    "weather.sh",
)

WEATHER_CACHE = os.path.join(
    HOME,
    ".cache",
    "Ardana",
    "weather.json",
)


# =====================================================
# Configuration Helpers
# =====================================================

def read_config(path):

    values = {}

    if not os.path.isfile(path):
        return values

    try:

        with open(
            path,
            "r",
            encoding="utf-8",
        ) as file:

            for line in file:

                line = line.strip()

                if not line:
                    continue

                if line.startswith("#"):
                    continue

                if "=" not in line:
                    continue

                key, value = line.split(
                    "=",
                    1,
                )

                key = key.strip()
                value = value.strip()

                if (
                    len(value) >= 2
                    and value[0] in "\"'"
                    and value[-1] == value[0]
                ):
                    value = value[1:-1]

                values[key] = value

    except OSError:

        pass

    return values


def write_config(
    path,
    values,
    header=None,
):

    os.makedirs(
        os.path.dirname(path),
        exist_ok=True,
    )

    lines = []

    if header:

        lines.append(
            f"# {header}"
        )

        lines.append("")

    for key, value in values.items():

        lines.append(
            f'{key}="{value}"'
        )

    lines.append("")

    try:

        with open(
            path,
            "w",
            encoding="utf-8",
        ) as file:

            file.write(
                "\n".join(lines)
            )

        return True

    except OSError:

        return False


def clear_weather_cache():

    try:

        if os.path.isfile(
            WEATHER_CACHE
        ):

            os.remove(
                WEATHER_CACHE
            )

    except OSError:

        pass


# =====================================================
# Settings Page
# =====================================================

class SettingsPage(Gtk.Box):

    def __init__(self):

        super().__init__(
            orientation=Gtk.Orientation.VERTICAL,
        )

        # =================================================
        # Scroll
        # =================================================

        self.scrolled = Gtk.ScrolledWindow()

        self.scrolled.set_policy(
            Gtk.PolicyType.NEVER,
            Gtk.PolicyType.AUTOMATIC,
        )

        self.scrolled.set_hexpand(
            True,
        )

        self.scrolled.set_vexpand(
            True,
        )

        self.pack_start(
            self.scrolled,
            True,
            True,
            0,
        )

        # =================================================
        # Content
        # =================================================

        self.content = Gtk.Box(
            orientation=Gtk.Orientation.VERTICAL,
            spacing=18,
        )

        self.content.set_margin_start(28)
        self.content.set_margin_end(28)
        self.content.set_margin_top(28)
        self.content.set_margin_bottom(28)

        self.scrolled.add(
            self.content
        )

        # =================================================
        # Header
        # =================================================

        self.create_header()

        # =================================================
        # Location
        # =================================================

        self.add_section_title(
            "Location & Weather"
        )

        self.create_weather_card()

        # =================================================
        # Unit
        # =================================================

        self.add_section_title(
            "Unit"
        )

        self.create_unit_cards()

        # =================================================
        # Time Format
        # =================================================

        self.add_section_title(
            "Time Format"
        )

        self.create_time_cards()

        # =================================================
        # Load Configuration
        # =================================================

        self.loading_settings = False

        self.load_settings()


    # =====================================================
    # Header
    # =====================================================

    def create_header(self):

        header = Gtk.Box(
            orientation=Gtk.Orientation.VERTICAL,
            spacing=4,
        )

        self.content.pack_start(
            header,
            False,
            False,
            0,
        )

        title = Gtk.Label(
            label="Settings"
        )

        title.set_xalign(0)

        title.get_style_context().add_class(
            "page-title"
        )

        header.pack_start(
            title,
            False,
            False,
            0,
        )

        subtitle = Gtk.Label(
            label="Configure Ardana runtime settings."
        )

        subtitle.set_xalign(0)

        subtitle.set_line_wrap(True)

        subtitle.get_style_context().add_class(
            "page-subtitle"
        )

        header.pack_start(
            subtitle,
            False,
            False,
            0,
        )


    # =====================================================
    # Section Title
    # =====================================================

    def add_section_title(
        self,
        text,
    ):

        label = Gtk.Label(
            label=text
        )

        label.set_xalign(0)

        label.get_style_context().add_class(
            "customize-section-title"
        )

        self.content.pack_start(
            label,
            False,
            False,
            0,
        )


    # =====================================================
    # Weather Card
    # =====================================================

    def create_weather_card(self):

        self.weather_card = Gtk.Box(
            orientation=Gtk.Orientation.VERTICAL,
            spacing=12,
        )

        self.weather_card.get_style_context().add_class(
            "card"
        )

        self.content.pack_start(
            self.weather_card,
            False,
            False,
            0,
        )

        # =================================================
        # Main Layout
        # Left  : 67%
        # Right : 33%
        # =================================================

        self.weather_grid = Gtk.Grid()

        self.weather_grid.set_column_spacing(24)
        self.weather_grid.set_hexpand(True)

        self.weather_card.pack_start(
            self.weather_grid,
            False,
            False,
            0,
        )

        # =================================================
        # Left - Configuration
        # =================================================

        self.weather_left = Gtk.Box(
            orientation=Gtk.Orientation.VERTICAL,
            spacing=12,
        )

        self.weather_left.set_hexpand(True)

        self.weather_grid.attach(
            self.weather_left,
            0,
            0,
            1,
            1,
        )

        # =================================================
        # Right - Location
        # =================================================

        self.weather_right = Gtk.Box(
            orientation=Gtk.Orientation.VERTICAL,
            spacing=8,
        )

        self.weather_grid.attach(
            self.weather_right,
            1,
            0,
            1,
            1,
        )

        # Keep the right side at approximately 33%.
        self.weather_grid.connect(
            "size-allocate",
            self.on_weather_grid_allocate,
        )

        # =================================================
        # API Key
        # =================================================

        api_label = Gtk.Label(
            label="OpenWeatherMap API Key"
        )

        api_label.set_xalign(0)

        api_label.get_style_context().add_class(
            "heading"
        )

        self.weather_left.pack_start(
            api_label,
            False,
            False,
            0,
        )

        self.api_key = Gtk.Entry()

        self.api_key.set_hexpand(True)

        # API key remains visible.
        self.api_key.set_visibility(True)

        self.api_key.set_placeholder_text(
            "Enter your OpenWeatherMap API key"
        )

        self.weather_left.pack_start(
            self.api_key,
            False,
            False,
            0,
        )

        # =================================================
        # Coordinates
        # =================================================

        coordinate_label = Gtk.Label(
            label="Coordinates"
        )

        coordinate_label.set_xalign(0)

        coordinate_label.get_style_context().add_class(
            "heading"
        )

        self.weather_left.pack_start(
            coordinate_label,
            False,
            False,
            0,
        )

        coordinates = Gtk.Box(
            orientation=Gtk.Orientation.HORIZONTAL,
            spacing=12,
        )

        coordinates.set_hexpand(True)

        self.weather_left.pack_start(
            coordinates,
            False,
            False,
            0,
        )

        # =================================================
        # Latitude
        # =================================================

        latitude_box = Gtk.Box(
            orientation=Gtk.Orientation.VERTICAL,
            spacing=5,
        )

        latitude_box.set_hexpand(True)

        coordinates.pack_start(
            latitude_box,
            True,
            True,
            0,
        )

        latitude_label = Gtk.Label(
            label="Latitude"
        )

        latitude_label.set_xalign(0)

        latitude_label.get_style_context().add_class(
            "dim"
        )

        latitude_box.pack_start(
            latitude_label,
            False,
            False,
            0,
        )

        self.latitude = Gtk.Entry()

        self.latitude.set_hexpand(True)

        self.latitude.set_placeholder_text(
            "-90 to 90"
        )

        latitude_box.pack_start(
            self.latitude,
            False,
            False,
            0,
        )

        # =================================================
        # Longitude
        # =================================================

        longitude_box = Gtk.Box(
            orientation=Gtk.Orientation.VERTICAL,
            spacing=5,
        )

        longitude_box.set_hexpand(True)

        coordinates.pack_start(
            longitude_box,
            True,
            True,
            0,
        )

        longitude_label = Gtk.Label(
            label="Longitude"
        )

        longitude_label.set_xalign(0)

        longitude_label.get_style_context().add_class(
            "dim"
        )

        longitude_box.pack_start(
            longitude_label,
            False,
            False,
            0,
        )

        self.longitude = Gtk.Entry()

        self.longitude.set_hexpand(True)

        self.longitude.set_placeholder_text(
            "-180 to 180"
        )

        longitude_box.pack_start(
            self.longitude,
            False,
            False,
            0,
        )

        warning_label = Gtk.Label(
            label=(
                "⚠ Warning: Use your own OpenWeatherMap API key "
                "to avoid free-tier usage limits. "
                "A free API key is available from OpenWeatherMap."
            )
        )

        warning_label.set_xalign(0)
        warning_label.set_line_wrap(True)
        warning_label.set_hexpand(True)

        warning_label.get_style_context().add_class(
            "warning"
        )

        self.weather_left.pack_start(
            warning_label,
            False,
            False,
            0,
        )

        # =================================================
        # Refresh
        # =================================================

        refresh_row = Gtk.Box(
            orientation=Gtk.Orientation.HORIZONTAL,
        )

        refresh_row.set_halign(
            Gtk.Align.END
        )

        self.weather_left.pack_start(
            refresh_row,
            False,
            False,
            0,
        )

        self.refresh_button = Gtk.Button(
            label="Refresh"
        )

        self.api_key.connect(
            "changed",
            self.on_weather_input_changed,
        )

        self.latitude.connect(
            "changed",
            self.on_weather_input_changed,
        )

        self.longitude.connect(
            "changed",
            self.on_weather_input_changed,
        )

        self.refresh_button.connect(
            "clicked",
            self.on_refresh,
        )

        refresh_row.pack_end(
            self.refresh_button,
            False,
            False,
            0,
        )

        # =================================================
        # Location Result
        # =================================================

        location_title = Gtk.Label(
            label="Location"
        )

        location_title.set_xalign(0)

        location_title.get_style_context().add_class(
            "heading"
        )

        self.weather_right.pack_start(
            location_title,
            False,
            False,
            0,
        )

        self.location_label = Gtk.Label(
            label="Not available"
        )

        self.location_label.set_xalign(0)

        self.location_label.set_line_wrap(True)

        self.location_label.get_style_context().add_class(
            "dim"
        )

        self.weather_right.pack_start(
            self.location_label,
            False,
            False,
            0,
        )

    def on_weather_grid_allocate(
        self,
        grid,
        allocation,
    ):

        width = allocation.width

        if width <= 0:
            return

        spacing = grid.get_column_spacing()

        usable_width = width - spacing

        right_width = int(
            usable_width * 0.3
        )

        if right_width > 0:

            self.weather_right.set_size_request(
                right_width,
                -1,
            )


    # =====================================================
    # Unit Cards
    # =====================================================

    def create_unit_cards(self):

        row = Gtk.Box(
            orientation=Gtk.Orientation.HORIZONTAL,
            spacing=12,
        )

        row.set_hexpand(True)

        self.content.pack_start(
            row,
            False,
            False,
            0,
        )

        self.metric_button = self.create_option_card(
            row,
            "Metric",
            "Celsius, kilometers, etc.",
            self.on_metric,
        )

        self.imperial_button = self.create_option_card(
            row,
            "Imperial",
            "Fahrenheit, miles, etc.",
            self.on_imperial,
        )


    # =====================================================
    # Time Cards
    # =====================================================

    def create_time_cards(self):

        row = Gtk.Box(
            orientation=Gtk.Orientation.HORIZONTAL,
            spacing=12,
        )

        row.set_hexpand(True)

        self.content.pack_start(
            row,
            False,
            False,
            0,
        )

        self.time24_button = self.create_option_card(
            row,
            "24-hour",
            "Example: 21:45",
            self.on_time24,
        )

        self.time12_button = self.create_option_card(
            row,
            "12-hour",
            "Example: 09:45 PM",
            self.on_time12,
        )


    # =====================================================
    # Option Card
    # =====================================================

    def create_option_card(
        self,
        parent,
        title,
        description,
        callback,
    ):

        button = Gtk.Button()

        button.set_hexpand(True)
        button.set_vexpand(False)

        button.set_relief(
            Gtk.ReliefStyle.NONE
        )

        button.get_style_context().add_class(
            "settings-card"
        )

        box = Gtk.Box(
            orientation=Gtk.Orientation.VERTICAL,
            spacing=5,
        )

        box.set_margin_start(16)
        box.set_margin_end(16)
        box.set_margin_top(14)
        box.set_margin_bottom(14)

        button.add(
            box
        )

        title_label = Gtk.Label(
            label=title
        )

        title_label.set_xalign(0)

        title_label.get_style_context().add_class(
            "heading"
        )

        box.pack_start(
            title_label,
            False,
            False,
            0,
        )

        description_label = Gtk.Label(
            label=description
        )

        description_label.set_xalign(0)

        description_label.set_line_wrap(True)

        description_label.get_style_context().add_class(
            "dim"
        )

        box.pack_start(
            description_label,
            False,
            False,
            0,
        )

        button.connect(
            "clicked",
            callback,
        )

        parent.pack_start(
            button,
            True,
            True,
            0,
        )

        return button


    # =====================================================
    # Load Settings
    # =====================================================

    def load_settings(self):

        self.loading_settings = True

        weather = read_config(
            WEATHER_CONFIG
        )

        unit = read_config(
            UNIT_CONFIG
        )

        time = read_config(
            TIME_CONFIG
        )

        # -------------------------------------------------
        # Weather
        # -------------------------------------------------

        self.api_key.set_text(
            weather.get(
                "API_KEY",
                "",
            )
        )

        self.latitude.set_text(
            weather.get(
                "LAT",
                "",
            )
        )

        self.longitude.set_text(
            weather.get(
                "LON",
                "",
            )
        )

        # -------------------------------------------------
        # Unit
        # -------------------------------------------------

        current_unit = unit.get(
            "UNIT",
            "metric",
        )

        if current_unit == "imperial":

            self.set_selected(
                self.imperial_button,
                self.metric_button,
            )

        else:

            self.set_selected(
                self.metric_button,
                self.imperial_button,
            )

        # -------------------------------------------------
        # Time
        # -------------------------------------------------

        current_time = time.get(
            "TIME_FORMAT",
            "24",
        )

        if current_time == "12":

            self.set_selected(
                self.time12_button,
                self.time24_button,
            )

        else:

            self.set_selected(
                self.time24_button,
                self.time12_button,
            )

        # -------------------------------------------------
        # Cached Location
        # -------------------------------------------------

        self.load_location()

        self.loading_settings = False

        self.refresh_button.get_style_context().remove_class(
            "refresh-changed"
        )


    # =====================================================
    # Selected Card
    # =====================================================

    def set_selected(
        self,
        selected,
        unselected,
    ):

        selected.get_style_context().add_class(
            "settings-card-selected"
        )

        unselected.get_style_context().remove_class(
            "settings-card-selected"
        )


    # =====================================================
    # Unit
    # =====================================================

    def on_metric(
        self,
        button,
    ):

        current = read_config(
            UNIT_CONFIG
        )

        current_unit = current.get(
            "UNIT",
            "metric",
        )

        self.set_selected(
            self.metric_button,
            self.imperial_button,
        )

        write_config(
            UNIT_CONFIG,
            {
                "UNIT": "metric",
            },
            "Ardana Unit Configuration",
        )

        if current_unit != "metric":

            clear_weather_cache()


    def on_imperial(
        self,
        button,
    ):

        current = read_config(
            UNIT_CONFIG
        )

        current_unit = current.get(
            "UNIT",
            "metric",
        )

        self.set_selected(
            self.imperial_button,
            self.metric_button,
        )

        write_config(
            UNIT_CONFIG,
            {
                "UNIT": "imperial",
            },
            "Ardana Unit Configuration",
        )

        if current_unit != "imperial":

            clear_weather_cache()


    # =====================================================
    # Time Format
    # =====================================================

    def on_time24(
        self,
        button,
    ):

        self.set_selected(
            self.time24_button,
            self.time12_button,
        )

        write_config(
            TIME_CONFIG,
            {
                "TIME_FORMAT": "24",
            },
            "Ardana Time Format Configuration",
        )


    def on_time12(
        self,
        button,
    ):

        self.set_selected(
            self.time12_button,
            self.time24_button,
        )

        write_config(
            TIME_CONFIG,
            {
                "TIME_FORMAT": "12",
            },
            "Ardana Time Format Configuration",
        )

    def on_weather_input_changed(self, entry):

        if self.loading_settings:
            return

        self.refresh_button.get_style_context().add_class(
            "refresh-changed"
        )

    # =====================================================
    # Refresh
    # =====================================================

    def on_refresh(
        self,
        button,
    ):

        api_key = self.api_key.get_text().strip()
        latitude = self.latitude.get_text().strip()
        longitude = self.longitude.get_text().strip()

        # -------------------------------------------------
        # Validate API Key
        # -------------------------------------------------

        if not api_key:

            self.location_label.set_text(
                "OpenWeatherMap API key is required."
            )

            return

        # -------------------------------------------------
        # Validate Coordinates
        # -------------------------------------------------

        try:

            lat = float(latitude)
            lon = float(longitude)

        except ValueError:

            self.location_label.set_text(
                "Latitude and longitude must be valid numbers."
            )

            return

        if not -90 <= lat <= 90:

            self.location_label.set_text(
                "Latitude must be between -90 and 90."
            )

            return

        if not -180 <= lon <= 180:

            self.location_label.set_text(
                "Longitude must be between -180 and 180."
            )

            return

        # -------------------------------------------------
        # Check Weather Script
        # -------------------------------------------------

        if not os.path.isfile(
            WEATHER_SCRIPT
        ):

            self.location_label.set_text(
                "Weather script not found."
            )

            return

        # -------------------------------------------------
        # Read Existing Configuration
        # -------------------------------------------------

        current = read_config(
            WEATHER_CONFIG
        )

        old_lat = current.get(
            "LAT",
            "",
        )

        old_lon = current.get(
            "LON",
            "",
        )

        old_api_key = current.get(
            "API_KEY",
            "",
        )

        location_changed = (
            old_lat != latitude
            or old_lon != longitude
        )

        api_key_changed = (
            old_api_key != api_key
        )

        language = current.get(
            "LANG",
            "en",
        )

        # -------------------------------------------------
        # Save Weather Configuration
        # -------------------------------------------------

        saved = write_config(
            WEATHER_CONFIG,
            {
                "API_KEY": api_key,
                "LAT": latitude,
                "LON": longitude,
                "LANG": language,
            },
            "Ardana Weather Configuration",
        )

        if not saved:

            self.location_label.set_text(
                "Unable to save weather configuration."
            )

            return

        # -------------------------------------------------
        # Invalidate Cache
        # -------------------------------------------------

        if (
            location_changed
            or api_key_changed
        ):

            clear_weather_cache()

        # -------------------------------------------------
        # Refresh
        # -------------------------------------------------

        self.refresh_button.set_sensitive(
            False
        )

        self.location_label.set_text(
            "Refreshing..."
        )

        try:

            result = subprocess.run(
                [
                    "bash",
                    WEATHER_SCRIPT,
                ],
                capture_output=True,
                text=True,
                timeout=30,
            )

            if result.returncode != 0:

                self.location_label.set_text(
                    "Unable to retrieve weather data."
                )

                return

            self.load_location()

            self.refresh_button.get_style_context().remove_class(
                "refresh-changed"
            )

        except (
            subprocess.SubprocessError,
            OSError,
        ):

            self.location_label.set_text(
                "Unable to retrieve weather data."
            )

        finally:

            self.refresh_button.set_sensitive(
                True
            )


    # =====================================================
    # Location
    # =====================================================

    def load_location(self):

        if not os.path.isfile(
            WEATHER_CACHE
        ):

            self.location_label.set_text(
                "Not available"
            )

            return

        try:

            result = subprocess.run(
                [
                    "jq",
                    "-r",
                    (
                        'if .name and .sys.country '
                        'then .name + ", " + .sys.country '
                        'else empty end'
                    ),
                    WEATHER_CACHE,
                ],
                capture_output=True,
                text=True,
                timeout=5,
            )

            location = result.stdout.strip()

            if (
                result.returncode == 0
                and location
            ):

                self.location_label.set_text(
                    location
                )

            else:

                self.location_label.set_text(
                    "Not available"
                )

        except (
            subprocess.SubprocessError,
            OSError,
        ):

            self.location_label.set_text(
                "Not available"
            )
