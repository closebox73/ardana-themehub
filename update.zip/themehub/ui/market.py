#!/usr/bin/env python3

import json
import re
import os
import shutil
import socket
import subprocess
import signal
import tempfile
import threading
import urllib.request
import urllib.parse
import zipfile

import gi

gi.require_version("Gtk", "3.0")
gi.require_version("GdkPixbuf", "2.0")

from gi.repository import (
    GLib,
    Gtk,
    Gdk,
    GdkPixbuf,
)


# =========================================================
# Paths
# =========================================================

HOME = os.path.expanduser("~")

ARDANA_DIR = os.path.join(
    HOME,
    ".config",
    "Ardana",
)

THEMES_DIR = os.path.join(
    ARDANA_DIR,
    "themes",
)

CACHE_DIR = os.path.join(
    HOME,
    ".cache",
    "Ardana",
)

PREVIEW_CACHE_DIR = os.path.join(
    CACHE_DIR,
    "market-previews",
)

FONTS_DIR = os.path.join(
    HOME,
    ".local",
    "share",
    "fonts",
)


# =========================================================
# Repository
# =========================================================

REMOTE_BASE = (
    "https://raw.githubusercontent.com/"
    "closebox73/"
    "ardana-themehub/"
    "main/"
)

REMOTE_INDEX = REMOTE_BASE + "index.json"


# =========================================================
# Helpers
# =========================================================

def version_tuple(value):
    text = str(value or "0").strip()

    if text.lower().startswith("v"):
        text = text[1:]

    result = []

    for part in text.split("."):
        digits = ""

        for char in part:
            if char.isdigit():
                digits += char
            else:
                break

        result.append(
            int(digits) if digits else 0
        )

    while len(result) < 3:
        result.append(0)

    return tuple(result)


def version_is_newer(remote, local):
    return version_tuple(remote) > version_tuple(local)


# =========================================================
# Preview
# =========================================================

class MarketPreview(Gtk.DrawingArea):

    def __init__(self, image_path=None):
        super().__init__()

        self.image_path = image_path
        self.pixbuf = None

        self.set_hexpand(True)
        self.set_vexpand(False)
        self.set_size_request(-1, 170)

        self.connect(
            "draw",
            self.on_draw,
        )

        if image_path:
            self.load_image()

    def load_image(self):
        if not self.image_path:
            return

        if not os.path.isfile(self.image_path):
            return

        try:
            self.pixbuf = (
                GdkPixbuf.Pixbuf.new_from_file(
                    self.image_path
                )
            )
        except Exception:
            self.pixbuf = None

    def on_draw(self, widget, cr):
        if self.pixbuf is None:
            return False

        width = self.get_allocated_width()
        height = self.get_allocated_height()

        if width <= 0 or height <= 0:
            return False

        image_width = self.pixbuf.get_width()
        image_height = self.pixbuf.get_height()

        if image_width <= 0 or image_height <= 0:
            return False

        # Fit the complete preview inside the allocated area.
        # No cropping on either side.
        scale = min(
            width / image_width,
            height / image_height,
        )

        new_width = max(
            1,
            int(image_width * scale),
        )

        new_height = max(
            1,
            int(image_height * scale),
        )

        scaled = self.pixbuf.scale_simple(
            new_width,
            new_height,
            GdkPixbuf.InterpType.BILINEAR,
        )

        if scaled is None:
            return False

        x = (width - new_width) / 2
        y = (height - new_height) / 2

        # Subtle rounded corners for the preview itself.
        radius = 6

        cr.new_path()

        cr.move_to(
            x + radius,
            y,
        )

        cr.line_to(
            x + new_width - radius,
            y,
        )

        cr.arc(
            x + new_width - radius,
            y + radius,
            radius,
            -1.5708,
            0,
        )

        cr.line_to(
            x + new_width,
            y + new_height - radius,
        )

        cr.arc(
            x + new_width - radius,
            y + new_height - radius,
            radius,
            0,
            1.5708,
        )

        cr.line_to(
            x + radius,
            y + new_height,
        )

        cr.arc(
            x + radius,
            y + new_height - radius,
            radius,
            1.5708,
            3.1416,
        )

        cr.line_to(
            x,
            y + radius,
        )

        cr.arc(
            x + radius,
            y + radius,
            radius,
            3.1416,
            4.7124,
        )

        cr.close_path()
        cr.clip()

        Gdk.cairo_set_source_pixbuf(
            cr,
            scaled,
            x,
            y,
        )

        cr.paint()

        return False



# =========================================================
# Market Theme Card
# =========================================================

class MarketThemeCard(Gtk.Box):

    def __init__(
        self,
        page,
        theme,
        installed,
        mode,
    ):
        super().__init__(
            orientation=Gtk.Orientation.VERTICAL,
            spacing=0,
        )

        self.page = page
        self.theme = theme
        self.mode = mode
        self.installed = installed

        self.theme_name = theme.get(
            "name",
            "Unknown Theme",
        )

        self.get_style_context().add_class(
            "theme-card"
        )

        # -------------------------------------------------
        # Preview
        # -------------------------------------------------

        preview = MarketPreview(
            page.get_preview_path(theme)
        )

        preview.set_margin_start(10)
        preview.set_margin_end(10)
        preview.set_margin_top(0)
        preview.set_margin_bottom(0)
        preview.set_halign(Gtk.Align.FILL)

        self.pack_start(
            preview,
            False,
            False,
            0,
        )

        # -------------------------------------------------
        # Information
        # -------------------------------------------------

        info = Gtk.Box(
            orientation=Gtk.Orientation.VERTICAL,
            spacing=2,
        )

        info.set_margin_start(12)
        info.set_margin_end(12)
        info.set_margin_top(0)
        info.set_margin_bottom(5)

        title = Gtk.Label(
            label=self.theme_name
        )

        title.set_xalign(0)
        title.set_ellipsize(3)

        title.set_markup(
            "<span size=\"12000\" weight=\"bold\">"
            + GLib.markup_escape_text(
                self.theme_name
            )
            + "</span>"
        )

        info.pack_start(
            title,
            False,
            False,
            0,
        )

        version = str(
            theme.get(
                "version",
                "0.0",
            )
        )

        author = str(
            theme.get(
                "author",
                "Unknown",
            )
        )

        metadata = Gtk.Label(
            label=(
                f"v{version}"
                f"  •  "
                f"{author}"
            )
        )

        metadata.set_xalign(0)

        metadata.get_style_context().add_class(
            "theme-info"
        )

        info.pack_start(
            metadata,
            False,
            False,
            0,
        )

        # -------------------------------------------------
        # Actions
        # -------------------------------------------------

        action_row = Gtk.Box(
            orientation=Gtk.Orientation.HORIZONTAL,
            spacing=6,
        )

        action_row.set_margin_top(1)
        action_row.set_margin_bottom(5)

        action_row.set_halign(
            Gtk.Align.END
        )

        if mode == "discover":

            if self.theme_name in installed:

                button = Gtk.Button(
                    label="Installed"
                )

                button.set_sensitive(False)

            else:

                button = Gtk.Button(
                    label="Install"
                )

                # Install uses GTK suggested-action styling so it is
                # visually distinct from Update and Delete.
                button.get_style_context().add_class(
                    "suggested-action"
                )

                button.get_style_context().add_class(
                    "market-install-button"
                )

                button.connect(
                    "clicked",
                    page.on_install_clicked,
                    theme,
                )

            action_row.pack_start(
                button,
                False,
                False,
                0,
            )

        else:

            local_version = installed.get(
                self.theme_name,
                theme.get("_local_version", "0.0"),
            )

            remote_version = theme.get(
                "version",
                "0.0",
            )

            is_local_only = theme.get(
                "_local_only",
                False,
            )

            if (
                not is_local_only
                and version_is_newer(
                    remote_version,
                    local_version,
                )
            ):

                update = Gtk.Button(
                    label="Update"
                )

                update.get_style_context().add_class(
                    "market-update-button"
                )

                update.get_style_context().add_class(
                    "market-action-padded"
                )

                update.connect(
                    "clicked",
                    page.on_update_clicked,
                    theme,
                )

                action_row.pack_start(
                    update,
                    False,
                    False,
                    0,
                )

            delete = Gtk.Button(
                label="Delete"
            )

            delete.get_style_context().add_class(
                "market-delete-button"
            )

            delete.get_style_context().add_class(
                "market-delete-button-padded"
            )

            delete.connect(
                "clicked",
                page.on_delete_clicked,
                theme,
            )

            action_row.pack_start(
                delete,
                False,
                False,
                0,
            )

        info.pack_start(
            action_row,
            False,
            False,
            0,
        )

        self.pack_start(
            info,
            False,
            False,
            0,
        )


# =========================================================
# Market Page
# =========================================================

class MarketPage(Gtk.Box):

    def __init__(self):
        super().__init__(
            orientation=Gtk.Orientation.VERTICAL
        )

        self.set_vexpand(True)

        self.mode = "discover"

        # -------------------------------------------------
        # Memory cache
        # -------------------------------------------------

        self.themes = []

        self.busy = False

        # -------------------------------------------------
        # Connection state
        # -------------------------------------------------

        self.connection_online = None
        self.market_load_failed = False
        self.connection_watch_id = None
        self.connection_status_label = None

        # -------------------------------------------------
        # Header
        # -------------------------------------------------

        header = Gtk.Box(
            orientation=Gtk.Orientation.VERTICAL
        )

        header.set_margin_start(28)
        header.set_margin_end(20)
        header.set_margin_top(20)
        header.set_margin_bottom(14)

        self.pack_start(
            header,
            False,
            False,
            0,
        )

        header_row = Gtk.Box(
            orientation=Gtk.Orientation.HORIZONTAL,
            spacing=20,
        )

        header.pack_start(
            header_row,
            False,
            False,
            0,
        )

        # -------------------------------------------------
        # Header left
        # -------------------------------------------------

        left = Gtk.Box(
            orientation=Gtk.Orientation.VERTICAL,
            spacing=5,
        )

        left.set_valign(
            Gtk.Align.START
        )

        title = Gtk.Label(
            label="Market"
        )

        title.set_xalign(0)
        title.set_valign(Gtk.Align.START)

        title.get_style_context().add_class(
            "page-title"
        )

        left.pack_start(
            title,
            False,
            False,
            0,
        )

        self.subtitle = Gtk.Label(
            label="Discover themes for Ardana"
        )

        self.subtitle.set_xalign(0)
        self.subtitle.set_valign(Gtk.Align.START)

        self.subtitle.get_style_context().add_class(
            "page-subtitle"
        )

        left.pack_start(
            self.subtitle,
            False,
            False,
            0,
        )

        header_row.pack_start(
            left,
            True,
            True,
            0,
        )

        # -------------------------------------------------
        # Header controls
        # -------------------------------------------------

        controls = Gtk.Box(
            orientation=Gtk.Orientation.HORIZONTAL,
            spacing=8,
        )

        controls.set_valign(
            Gtk.Align.START
        )

        self.search_entry = Gtk.SearchEntry()

        self.search_entry.set_placeholder_text(
            "Search themes..."
        )

        self.search_entry.set_width_chars(
            26
        )

        self.search_entry.connect(
            "search-changed",
            self.on_search_changed,
        )

        controls.pack_start(
            self.search_entry,
            False,
            False,
            0,
        )

        self.discover_button = Gtk.Button(
            label="Discover"
        )

        self.installed_button = Gtk.Button(
            label="Installed"
        )

        self.discover_button.get_style_context().add_class(
            "market-tab"
        )

        self.installed_button.get_style_context().add_class(
            "market-tab"
        )

        self.discover_button.connect(
            "clicked",
            self.on_discover_clicked,
        )

        self.installed_button.connect(
            "clicked",
            self.on_installed_clicked,
        )

        controls.pack_start(
            self.discover_button,
            False,
            False,
            0,
        )

        controls.pack_start(
            self.installed_button,
            False,
            False,
            0,
        )

        self.refresh_button = Gtk.Button(
            label="Refresh"
        )

        self.refresh_button.connect(
            "clicked",
            self.on_refresh_clicked,
        )

        controls.pack_start(
            self.refresh_button,
            False,
            False,
            0,
        )

        header_row.pack_end(
            controls,
            False,
            False,
            0,
        )

        # -------------------------------------------------
        # Scroll area
        # -------------------------------------------------

        scroll = Gtk.ScrolledWindow()

        scroll.set_policy(
            Gtk.PolicyType.NEVER,
            Gtk.PolicyType.AUTOMATIC,
        )

        scroll.set_vexpand(True)
        scroll.set_margin_bottom(12)

        self.pack_start(
            scroll,
            True,
            True,
            0,
        )

        content = Gtk.Box(
            orientation=Gtk.Orientation.VERTICAL
        )

        content.set_valign(
            Gtk.Align.START
        )

        scroll.add(
            content
        )

        # -------------------------------------------------
        # Grid
        # -------------------------------------------------

        grid = Gtk.Grid()

        grid.set_valign(
            Gtk.Align.START
        )

        grid.set_hexpand(True)

        grid.set_column_spacing(18)
        grid.set_row_spacing(18)

        grid.set_margin_start(20)
        grid.set_margin_end(20)
        grid.set_margin_bottom(20)

        grid.set_column_homogeneous(True)

        content.pack_start(
            grid,
            False,
            False,
            0,
        )

        self.theme_grid = grid

        self.update_mode_buttons()

        # -------------------------------------------------
        # Load
        # -------------------------------------------------

        self.load_market()

    # =====================================================
    # Mode
    # =====================================================

    def on_discover_clicked(
        self,
        button,
    ):

        self.mode = "discover"

        self.subtitle.set_label(
            "Discover themes for Ardana"
        )

        self.update_mode_buttons()
        self.render_themes()

    def on_installed_clicked(
        self,
        button,
    ):

        self.mode = "installed"

        self.subtitle.set_label(
            "Themes installed on your system"
        )

        self.update_mode_buttons()
        self.render_themes()

    def update_mode_buttons(self):

        discover = (
            self.discover_button
            .get_style_context()
        )

        installed = (
            self.installed_button
            .get_style_context()
        )

        discover.remove_class("active")
        installed.remove_class("active")

        if self.mode == "discover":
            discover.add_class("active")
        else:
            installed.add_class("active")

    # =====================================================
    # Market Loading
    # =====================================================

    def load_market(self):

        # Loading the Market is an explicit action.
        # Connection changes never call this automatically.
        threading.Thread(
            target=self._load_market_worker,
            daemon=True,
        ).start()

    def on_refresh_clicked(
        self,
        button,
    ):

        if self.busy:
            return

        # Manual refresh is the only way to load the remote
        # Market again after a connection failure.
        self.market_load_failed = False

        if self.connection_status_label is not None:

            self.connection_status_label.set_text(
                "Loading theme market..."
            )

        self.refresh_button.set_sensitive(
            False
        )

        self.load_market()

    def check_connection(self):

        try:

            with socket.create_connection(
                (
                    "github.com",
                    443,
                ),
                timeout=2,
            ):
                return True

        except OSError:

            return False

    def start_connection_watch(self):

        if self.connection_watch_id is not None:
            return

        self.connection_watch_id = (
            GLib.timeout_add_seconds(
                3,
                self.check_connection_state,
            )
        )

    def check_connection_state(self):

        online = self.check_connection()

        previous = self.connection_online

        self.connection_online = online

        # Only show a recovery message when Market failed to load
        # because the connection was unavailable.
        #
        # IMPORTANT:
        # This does NOT call load_market() and does NOT call
        # render_themes(). The user must press Refresh.
        if (
            self.market_load_failed
            and online
            and previous is False
            and self.connection_status_label is not None
        ):

            self.connection_status_label.set_text(
                "Connection restored. "
                "Click Refresh to load the theme market."
            )

        return True

    def stop_connection_watch(self):

        if self.connection_watch_id is not None:

            GLib.source_remove(
                self.connection_watch_id
            )

            self.connection_watch_id = None

    def _load_market_worker(self):

        try:

            with urllib.request.urlopen(
                REMOTE_INDEX,
                timeout=10,
            ) as response:

                data = json.loads(
                    response.read().decode(
                        "utf-8"
                    )
                )

            themes = data.get(
                "themes",
                []
            )

            if not isinstance(
                themes,
                list,
            ):
                raise ValueError(
                    "Invalid themes list"
                )

            self.themes = themes
            self.market_load_failed = False
            self.connection_online = True

            GLib.idle_add(
                self.market_load_succeeded
            )

        except Exception as error:

            print(
                "[Ardana ThemeHub] "
                "Failed to load market:",
                error,
            )

            self.market_load_failed = True

            GLib.idle_add(
                self.show_market_error
            )

    def market_load_succeeded(self):

        self.refresh_button.set_sensitive(
            True
        )

        self.connection_status_label = None

        self.render_themes()

        return False

    def show_market_error(self):

        self.clear_grid()

        self.market_load_failed = True

        self.connection_online = False

        label = Gtk.Label()

        label.set_xalign(0.5)
        label.set_justify(
            Gtk.Justification.CENTER
        )

        label.set_line_wrap(True)

        label.get_style_context().add_class(
            "page-subtitle"
        )

        label.set_margin_top(40)

        label.set_text(
            "Unable to load the theme market.\n"
            "Connect to the internet, then click Refresh."
        )

        self.connection_status_label = label

        self.theme_grid.attach(
            label,
            0,
            0,
            3,
            1,
        )

        self.refresh_button.set_sensitive(
            True
        )

        self.theme_grid.show_all()

        self.start_connection_watch()

        return False

    # =====================================================
    # Rendering
    # =====================================================

    def render_themes(self):

        self.clear_grid()

        installed = (
            self.get_installed_themes()
        )

        if self.mode == "discover":

            themes = list(self.themes)

        else:

            # Installed is based on the local filesystem, not the
            # remote index. Local-only themes must also be visible.
            remote_by_name = {
                str(theme.get("name", "")): theme
                for theme in self.themes
                if theme.get("name")
            }

            themes = []

            for local_name, local_version in installed.items():

                remote_theme = remote_by_name.get(local_name)

                if remote_theme is not None:
                    theme = dict(remote_theme)
                    theme["_local_version"] = local_version
                else:
                    theme = {
                        "name": local_name,
                        "version": local_version,
                        "author": "Local",
                        "_local_version": local_version,
                        "_local_only": True,
                    }

                themes.append(theme)

        query = (
            self.search_entry
            .get_text()
            .strip()
            .lower()
        )

        if query:

            themes = [
                theme
                for theme in themes
                if (
                    query in str(
                        theme.get(
                            "name",
                            "",
                        )
                    ).lower()
                    or
                    query in str(
                        theme.get(
                            "author",
                            "",
                        )
                    ).lower()
                )
            ]

        themes.sort(
            key=lambda item: str(
                item.get(
                    "name",
                    "",
                )
            ).lower()
        )

        for index, theme in enumerate(
            themes
        ):

            card = MarketThemeCard(
                self,
                theme,
                installed,
                self.mode,
            )

            card.set_hexpand(True)
            card.set_halign(Gtk.Align.FILL)
            card.set_valign(Gtk.Align.START)

            self.theme_grid.attach(
                card,
                index % 3,
                index // 3,
                1,
                1,
            )

        remainder = len(themes) % 3

        if remainder:

            last_row = len(themes) // 3

            for column in range(
                remainder,
                3,
            ):

                spacer = Gtk.Box()

                spacer.set_hexpand(True)

                self.theme_grid.attach(
                    spacer,
                    column,
                    last_row,
                    1,
                    1,
                )

        if not themes:

            text = (
                "No themes found."
                if self.mode == "discover"
                else "No themes are installed."
            )

            label = Gtk.Label(
                label=text
            )

            label.get_style_context().add_class(
                "page-subtitle"
            )

            label.set_margin_top(40)

            self.theme_grid.attach(
                label,
                0,
                0,
                3,
                1,
            )

        self.theme_grid.show_all()

        return False

    def clear_grid(self):

        for child in (
            self.theme_grid.get_children()
        ):
            self.theme_grid.remove(
                child
            )

    # =====================================================
    # Search
    # =====================================================

    def on_search_changed(
        self,
        search,
    ):
        self.render_themes()

    # =====================================================
    # Installed Themes
    # =====================================================

    def get_installed_themes(self):

        result = {}

        if not os.path.isdir(
            THEMES_DIR
        ):
            return result

        for name in os.listdir(
            THEMES_DIR
        ):

            path = os.path.join(
                THEMES_DIR,
                name,
            )

            if not os.path.isdir(path):
                continue

            metadata_path = os.path.join(
                path,
                "metadata.json",
            )

            if not os.path.isfile(
                metadata_path
            ):
                continue

            try:

                with open(
                    metadata_path,
                    "r",
                    encoding="utf-8",
                ) as file:

                    metadata = json.load(
                        file
                    )

                theme_name = metadata.get(
                    "name",
                    name,
                )

                result[
                    theme_name
                ] = str(
                    metadata.get(
                        "version",
                        "0.0",
                    )
                )

            except Exception as error:

                print(
                    "[Ardana ThemeHub] "
                    "Failed to read metadata:",
                    error,
                )

        return result

    # =====================================================
    # Preview
    # =====================================================

    def get_preview_path(
        self,
        theme,
    ):

        # Installed themes use their local preview.jpg.
        if self.mode == "installed":

            theme_name = theme.get(
                "name"
            )

            if not theme_name:
                return None

            local_path = os.path.join(
                THEMES_DIR,
                theme_name,
                "preview.jpg",
            )

            if os.path.isfile(
                local_path
            ):
                return local_path

            return None

        # Discover/Market previews come from the repository
        # as WebP files and are cached locally.
        preview = theme.get(
            "preview"
        )

        if not preview:
            return None

        filename = os.path.basename(
            preview
        )

        if not filename.lower().endswith(
            ".webp"
        ):
            print(
                "[Ardana ThemeHub] "
                "Ignoring non-WebP market preview:",
                filename,
            )
            return None

        os.makedirs(
            PREVIEW_CACHE_DIR,
            exist_ok=True,
        )

        local_path = os.path.join(
            PREVIEW_CACHE_DIR,
            filename,
        )

        if os.path.isfile(
            local_path
        ):
            return local_path

        url = (
            REMOTE_BASE +
            preview.lstrip("/")
        )

        try:

            urllib.request.urlretrieve(
                url,
                local_path,
            )

            return local_path

        except Exception as error:

            print(
                "[Ardana ThemeHub] "
                "Preview download failed:",
                error,
            )

            try:
                if os.path.isfile(
                    local_path
                ):
                    os.remove(
                        local_path
                    )
            except OSError:
                pass

            return None

    # =====================================================
    # Font Dependencies
    # =====================================================

    def get_local_fonts(self):
        """
        Scan ~/.local/share/fonts recursively and return the
        installed font filenames.
        """

        fonts = set()

        if not os.path.isdir(FONTS_DIR):
            return fonts

        for root, dirs, files in os.walk(FONTS_DIR):
            for filename in files:
                fonts.add(filename)

        return fonts

    def get_required_fonts(self, theme):
        """
        Read the font dependency list from the remote market
        index. Fonts are separate resources and are never part
        of the theme ZIP.
        """

        fonts = theme.get("fonts", [])

        if not isinstance(fonts, list):
            return []

        result = []

        for font in fonts:
            filename = os.path.basename(
                str(font).strip()
            )

            if not filename:
                continue

            if filename not in result:
                result.append(filename)

        return result

    def get_missing_fonts(self, theme):
        local_fonts = self.get_local_fonts()

        return [
            filename
            for filename in self.get_required_fonts(theme)
            if filename not in local_fonts
        ]

    def download_missing_fonts(self, theme):
        """
        Download only missing fonts into ~/.local/share/fonts/.
        """

        missing = self.get_missing_fonts(theme)

        if not missing:
            return True

        os.makedirs(
            FONTS_DIR,
            exist_ok=True,
        )

        for filename in missing:

            url = (
                REMOTE_BASE
                + "fonts/"
                + urllib.parse.quote(
                    filename
                )
            )

            destination = os.path.join(
                FONTS_DIR,
                filename,
            )

            temporary = destination + ".download"

            try:

                print(
                    "[Ardana ThemeHub] "
                    "Downloading font:",
                    filename,
                )

                urllib.request.urlretrieve(
                    url,
                    temporary,
                )

                if not os.path.isfile(
                    temporary
                ):
                    raise RuntimeError(
                        "Downloaded font file was not created."
                    )

                os.replace(
                    temporary,
                    destination,
                )

            except Exception as error:

                try:
                    if os.path.isfile(
                        temporary
                    ):
                        os.remove(
                            temporary
                        )
                except OSError:
                    pass

                print(
                    "[Ardana ThemeHub] "
                    "Font download failed:",
                    filename,
                    error,
                )

                return False

        # Refresh fontconfig only when at least one new font
        # was actually installed.
        try:

            subprocess.run(
                [
                    "fc-cache",
                    "-f",
                    FONTS_DIR,
                ],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                check=False,
            )

        except OSError:
            pass

        return True

    # =====================================================
    # Ardana Dashboard Lifecycle
    # =====================================================

    def get_dashboard_page(self):
        """
        Get the actual Ardana DashboardPage instance from the
        current ThemeHub window.
        """

        window = self.get_toplevel()

        if window is None:
            return None

        return getattr(
            window,
            "dashboard_page",
            None,
        )

    def get_running_theme_configs(self, theme_name):
        """
        Return the exact .conf paths currently used by Conky
        for this theme.

        We inspect the process command line before an update/delete
        so the paths remain available.
        """

        theme_dir = os.path.realpath(
            os.path.join(
                THEMES_DIR,
                theme_name,
            )
        )

        if not os.path.isdir(theme_dir):
            return []

        configs = set()

        try:
            result = subprocess.run(
                [
                    "pgrep",
                    "-af",
                    "conky",
                ],
                capture_output=True,
                text=True,
                check=False,
            )
        except Exception as error:
            print(
                "[Ardana ThemeHub] "
                "Failed to inspect Conky:",
                error,
            )
            return []

        for line in result.stdout.splitlines():

            parts = line.split(
                None,
                1,
            )

            if len(parts) != 2:
                continue

            try:
                pid = int(parts[0])
            except ValueError:
                continue

            if pid == os.getpid():
                continue

            command = parts[1]

            if "conky" not in command.lower():
                continue

            if theme_dir not in command:
                continue

            # Conky is normally started as:
            # conky -c /absolute/path/theme/config.conf
            match = re.search(
                r"(?:^|\s)-c\s+([^\s]+)",
                command,
            )

            if match:
                config_path = os.path.realpath(
                    match.group(1)
                )

                if config_path.startswith(
                    theme_dir + os.sep
                ):
                    configs.add(
                        config_path
                    )

        return sorted(configs)

    def stop_config(self, conf_path):
        """
        Stop exactly one Ardana Conky config.
        """

        conf_path = os.path.realpath(
            conf_path
        )

        try:

            result = subprocess.run(
                [
                    "pgrep",
                    "-af",
                    "conky",
                ],
                capture_output=True,
                text=True,
                check=False,
            )

            for line in result.stdout.splitlines():

                parts = line.split(
                    None,
                    1,
                )

                if len(parts) != 2:
                    continue

                try:
                    pid = int(parts[0])
                except ValueError:
                    continue

                if pid == os.getpid():
                    continue

                command = parts[1]

                if conf_path not in command:
                    continue

                os.kill(
                    pid,
                    signal.SIGTERM,
                )

        except Exception as error:

            print(
                "[Ardana ThemeHub] "
                "Failed to stop config:",
                conf_path,
                error,
            )

    def start_config(self, conf_path):
        """
        Start exactly one Ardana Conky config.
        """

        conf_path = os.path.realpath(
            conf_path
        )

        if not os.path.isfile(
            conf_path
        ):
            return

        try:

            subprocess.Popen(
                [
                    "conky",
                    "-c",
                    conf_path,
                ],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                start_new_session=True,
            )

        except Exception as error:

            print(
                "[Ardana ThemeHub] "
                "Failed to start config:",
                conf_path,
                error,
            )

    def stop_theme_configs(self, theme_name):
        """
        Stop all currently running configs belonging to one theme.
        """

        configs = self.get_running_theme_configs(
            theme_name
        )

        for conf_path in configs:
            self.stop_config(
                conf_path
            )

        return configs

    def remove_theme_from_autostart(
        self,
        theme_name,
    ):
        """
        Remove deleted theme configs from Ardana's autostart.json.
        """

        state_path = os.path.join(
            ARDANA_DIR,
            "autostart.json",
        )

        if not os.path.isfile(
            state_path
        ):
            return

        theme_dir = os.path.realpath(
            os.path.join(
                THEMES_DIR,
                theme_name,
            )
        )

        try:

            with open(
                state_path,
                "r",
                encoding="utf-8",
            ) as file:
                state = json.load(file)

            if not isinstance(
                state,
                dict,
            ):
                return

            configs = state.get(
                "configs",
                [],
            )

            if not isinstance(
                configs,
                list,
            ):
                configs = []

            state["configs"] = [
                path
                for path in configs
                if not os.path.realpath(
                    str(path)
                ).startswith(
                    theme_dir + os.sep
                )
            ]

            with open(
                state_path,
                "w",
                encoding="utf-8",
            ) as file:
                json.dump(
                    state,
                    file,
                    indent=4,
                )

        except Exception as error:

            print(
                "[Ardana ThemeHub] "
                "Failed to update autostart state:",
                error,
            )

    def refresh_dashboard_ui(self):
        """
        Refresh only Ardana's DashboardPage UI.

        DashboardPage.load_themes() already clears the existing
        grid and rebuilds the installed-theme cards.
        """

        dashboard = self.get_dashboard_page()

        if dashboard is None:
            print(
                "[Ardana ThemeHub] "
                "DashboardPage is unavailable."
            )
            return False

        try:

            dashboard.load_themes()
            dashboard.show_all()

        except Exception as error:

            print(
                "[Ardana ThemeHub] "
                "Dashboard UI refresh failed:",
                error,
            )

        return False

    def refresh_dashboard(self):
        """
        Ardana dashboard refresh:
        - rebuild DashboardPage cards
        - do NOT globally restart Conky
        """

        GLib.idle_add(
            self.refresh_dashboard_ui
        )

    # =====================================================
    # Install / Update
    # =====================================================

    def on_install_clicked(
        self,
        button,
        theme,
    ):

        self.download_theme(
            theme
        )

    def on_update_clicked(
        self,
        button,
        theme,
    ):

        self.download_theme(
            theme
        )

    def download_theme(
        self,
        theme,
    ):

        if self.busy:
            return

        self.busy = True

        threading.Thread(
            target=self._download_theme_worker,
            args=(theme,),
            daemon=True,
        ).start()

    def _download_theme_worker(
        self,
        theme,
    ):

        theme_name = theme.get(
            "name"
        )

        if not theme_name:
            GLib.idle_add(
                self.action_failed,
                "Theme name is missing",
            )
            return

        running_configs = []
        installation_started = False

        try:

            # -------------------------------------------------
            # If this is an update, remember currently running
            # configs and stop only those configs.
            # -------------------------------------------------

            running_configs = (
                self.stop_theme_configs(
                    theme_name
                )
            )

            # -------------------------------------------------
            # Font dependencies
            # -------------------------------------------------

            if not self.download_missing_fonts(
                theme
            ):
                raise RuntimeError(
                    "Required font download failed."
                )

            # -------------------------------------------------
            # Theme ZIP
            # -------------------------------------------------

            file_path = theme.get(
                "file"
            )

            if not file_path:
                raise ValueError(
                    "Theme file is missing"
                )

            url = (
                REMOTE_BASE +
                str(file_path).lstrip("/")
            )

            with tempfile.TemporaryDirectory(
                prefix="ardana-theme-"
            ) as temp_dir:

                zip_path = os.path.join(
                    temp_dir,
                    "theme.zip",
                )

                urllib.request.urlretrieve(
                    url,
                    zip_path,
                )

                if not zipfile.is_zipfile(
                    zip_path
                ):
                    raise ValueError(
                        "Downloaded theme is not a valid ZIP archive."
                    )

                extracted = (
                    self.extract_theme(
                        zip_path,
                        temp_dir,
                    )
                )

                if extracted is None:
                    raise ValueError(
                        "metadata.json not found"
                    )

                self.install_extracted_theme(
                    extracted,
                    theme,
                )

                installation_started = True

            # -------------------------------------------------
            # If an existing theme was running before update,
            # start the same configs again from the new files.
            # -------------------------------------------------

            for conf_path in running_configs:

                if os.path.isfile(
                    conf_path
                ):
                    self.start_config(
                        conf_path
                    )

            # -------------------------------------------------
            # Refresh Ardana Dashboard UI.
            # -------------------------------------------------

            self.refresh_dashboard()

            GLib.idle_add(
                self.action_finished
            )

        except Exception as error:

            # If the update failed after we stopped an active
            # theme, restore the previously running configs.
            if not installation_started:

                for conf_path in running_configs:

                    if os.path.isfile(
                        conf_path
                    ):
                        self.start_config(
                            conf_path
                        )

            print(
                "[Ardana ThemeHub] "
                "Theme installation failed:",
                error,
            )

            GLib.idle_add(
                self.action_failed,
                str(error),
            )


    def extract_theme(
        self,
        zip_path,
        temp_dir,
    ):

        extract_dir = os.path.join(
            temp_dir,
            "extracted",
        )

        os.makedirs(
            extract_dir,
            exist_ok=True,
        )

        with zipfile.ZipFile(
            zip_path,
            "r",
        ) as archive:

            base = os.path.realpath(
                extract_dir
            )

            for member in archive.infolist():

                target = os.path.realpath(
                    os.path.join(
                        extract_dir,
                        member.filename,
                    )
                )

                if not (
                    target == base
                    or target.startswith(
                        base + os.sep
                    )
                ):

                    raise ValueError(
                        "Unsafe ZIP path"
                    )

            archive.extractall(
                extract_dir
            )

        for root, dirs, files in os.walk(
            extract_dir
        ):

            if "metadata.json" in files:

                return root

        return None

    def install_extracted_theme(
        self,
        extracted_dir,
        theme,
    ):

        os.makedirs(
            THEMES_DIR,
            exist_ok=True,
        )

        theme_name = theme.get(
            "name"
        )

        if not theme_name:
            raise ValueError(
                "Theme name is missing"
            )

        destination = os.path.join(
            THEMES_DIR,
            theme_name,
        )

        backup = destination + ".backup"

        if os.path.exists(
            backup
        ):
            shutil.rmtree(
                backup,
                ignore_errors=True,
            )

        if os.path.exists(
            destination
        ):
            os.replace(
                destination,
                backup,
            )

        try:

            shutil.copytree(
                extracted_dir,
                destination,
            )

        except Exception:

            if os.path.exists(
                destination
            ):
                shutil.rmtree(
                    destination,
                    ignore_errors=True,
                )

            if os.path.exists(
                backup
            ):
                os.replace(
                    backup,
                    destination,
                )

            raise

        if os.path.exists(
            backup
        ):
            shutil.rmtree(
                backup,
                ignore_errors=True,
            )


    # =====================================================
    # Delete
    # =====================================================

    def on_delete_clicked(
        self,
        button,
        theme,
    ):

        theme_name = theme.get(
            "name"
        )

        if not theme_name:
            return

        dialog = Gtk.MessageDialog(
            transient_for=self.get_toplevel(),
            modal=True,
            message_type=Gtk.MessageType.QUESTION,
            buttons=Gtk.ButtonsType.CANCEL,
            text=f"Delete {theme_name}?",
        )

        dialog.format_secondary_text(
            "This will remove the theme from Ardana."
        )

        dialog.add_button(
            "Delete",
            Gtk.ResponseType.YES,
        )

        response = dialog.run()

        dialog.destroy()

        if response != Gtk.ResponseType.YES:
            return

        destination = os.path.join(
            THEMES_DIR,
            theme_name,
        )

        try:

            # Stop all running configs belonging to this theme
            # BEFORE removing its files.
            self.stop_theme_configs(
                theme_name
            )

            if os.path.isdir(
                destination
            ):
                shutil.rmtree(
                    destination
                )

            # Remove stale autostart entries for this theme.
            self.remove_theme_from_autostart(
                theme_name
            )

            # Refresh Market immediately.
            self.render_themes()

            # Refresh Ardana Dashboard immediately.
            self.refresh_dashboard()

        except Exception as error:

            print(
                "[Ardana ThemeHub] "
                "Theme deletion failed:",
                error,
            )


    # =====================================================
    # Async Finish
    # =====================================================

    def action_finished(self):

        self.busy = False

        self.render_themes()

        return False

    def action_failed(
        self,
        error,
    ):

        self.busy = False

        print(
            "[Ardana ThemeHub] "
            "Theme action failed:",
            error,
        )

        return False
