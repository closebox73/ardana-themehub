#!/usr/bin/env python3

import webbrowser

import gi

gi.require_version("Gtk", "3.0")

from gi.repository import Gtk


# =====================================================
# Card
# =====================================================

def create_card(spacing=10):

    card = Gtk.Box(
        orientation=Gtk.Orientation.VERTICAL,
        spacing=spacing,
    )

    card.get_style_context().add_class(
        "card"
    )

    card.set_margin_top(8)
    card.set_margin_bottom(8)

    return card


# =====================================================
# Stat
# =====================================================

def create_stat(title, value):

    box = Gtk.Box(
        orientation=Gtk.Orientation.VERTICAL,
        spacing=6,
    )

    box.set_hexpand(True)

    title_label = Gtk.Label(
        label=title
    )

    title_label.get_style_context().add_class(
        "dim"
    )

    title_label.set_xalign(0.5)

    value_label = Gtk.Label(
        label=value
    )

    value_label.get_style_context().add_class(
        "heading"
    )

    value_label.set_xalign(0.5)

    box.pack_start(
        title_label,
        False,
        False,
        0,
    )

    box.pack_start(
        value_label,
        False,
        False,
        0,
    )

    return box


# =====================================================
# Section
# =====================================================

def create_section(title):

    box = Gtk.Box(
        orientation=Gtk.Orientation.VERTICAL,
        spacing=12,
    )

    label = Gtk.Label(
        label=title
    )

    label.get_style_context().add_class(
        "heading"
    )

    label.set_xalign(0)

    box.pack_start(
        label,
        False,
        False,
        0,
    )

    return box


# =====================================================
# Info Row
# =====================================================

def create_info_row(label_text, value_text):

    row = Gtk.Box(
        orientation=Gtk.Orientation.HORIZONTAL,
        spacing=12,
    )

    label = Gtk.Label(
        label=label_text
    )

    label.set_xalign(0)
    label.set_hexpand(True)

    value = Gtk.Label(
        label=value_text
    )

    value.set_xalign(1)

    value.get_style_context().add_class(
        "dim"
    )

    row.pack_start(
        label,
        True,
        True,
        0,
    )

    row.pack_start(
        value,
        False,
        False,
        0,
    )

    return row


# =====================================================
# Link Button
# =====================================================

def create_link_button(label, url):

    button = Gtk.Button(
        label=label
    )

    button.set_halign(
        Gtk.Align.START
    )

    button.connect(
        "clicked",
        lambda *_: webbrowser.open(url),
    )

    return button


# =====================================================
# Link Row
# =====================================================

def create_link_row(
    title,
    description,
    url,
):

    row = Gtk.Button()

    row.set_hexpand(True)

    row.connect(
        "clicked",
        lambda *_: webbrowser.open(url),
    )

    content = Gtk.Box(
        orientation=Gtk.Orientation.HORIZONTAL,
        spacing=12,
    )

    content.set_margin_top(10)
    content.set_margin_bottom(10)
    content.set_margin_start(16)
    content.set_margin_end(16)

    # -------------------------------------------------
    # Left
    # -------------------------------------------------

    left = Gtk.Box(
        orientation=Gtk.Orientation.VERTICAL,
        spacing=2,
    )

    left.set_hexpand(True)

    title_label = Gtk.Label(
        label=title
    )

    title_label.get_style_context().add_class(
        "brand"
    )

    title_label.set_xalign(0)

    desc_label = Gtk.Label(
        label=description
    )

    desc_label.get_style_context().add_class(
        "dim"
    )

    desc_label.set_xalign(0)

    left.pack_start(
        title_label,
        False,
        False,
        0,
    )

    left.pack_start(
        desc_label,
        False,
        False,
        0,
    )

    # -------------------------------------------------
    # Right
    # -------------------------------------------------

    arrow = Gtk.Image.new_from_icon_name(
        "go-next-symbolic",
        Gtk.IconSize.BUTTON,
    )

    content.pack_start(
        left,
        True,
        True,
        0,
    )

    content.pack_start(
        arrow,
        False,
        False,
        0,
    )

    row.add(content)

    return row


# =====================================================
# Spacer
# =====================================================

def create_spacer(height=24):

    spacer = Gtk.Box()

    spacer.set_size_request(
        -1,
        height,
    )

    return spacer


# =====================================================
# Separator
# =====================================================

def create_separator():

    return Gtk.Separator(
        orientation=Gtk.Orientation.HORIZONTAL,
    )
