#!/usr/bin/env python3

import os
import shutil
import subprocess
import tempfile
import threading
import time
import urllib.request
import zipfile

from datetime import datetime

import gi

gi.require_version(
    "Gtk",
    "3.0",
)

from gi.repository import (
    GLib,
    Gtk,
)

from gi.repository import GdkPixbuf

from dialogs.changelog_dialog import (
    ChangelogDialog,
)

from dialogs.install_dialog import (
    InstallDialog,
)

from widgets.common import (
    create_card,
)


# =====================================================
# Paths
# =====================================================

HOME = os.path.expanduser(
    "~"
)

ARDANA_DIR = os.path.join(
    HOME,
    ".config",
    "Ardana",
)

THEMEHUB_DIR = os.path.join(
    HOME,
    ".local",
    "share",
    "ArdanaThemeHub",
)

ICON_DIR = os.path.join(
    HOME,
    ".local",
    "share",
    "icons",
    "hicolor",
)

LOGO_PATH = os.path.join(
    THEMEHUB_DIR,
    "assets",
    "logo.png",
)

VERSION_FILE = os.path.join(
    THEMEHUB_DIR,
    "version.txt",
)

REMOTE_VERSION = (
    "https://raw.githubusercontent.com/"
    "closebox73/"
    "ardana-themehub/"
    "main/"
    "version.txt"
)

REMOTE_UPDATE = (
    "https://raw.githubusercontent.com/"
    "closebox73/"
    "ardana-themehub/"
    "main/"
    "update.zip"
)

REMOTE_CHANGELOG = (
    "https://raw.githubusercontent.com/"
    "closebox73/"
    "ardana-themehub/"
    "main/"
    "CHANGELOG.md"
)


class UpdateCard(Gtk.Box):

    def __init__(
        self,
    ):

        super().__init__(
            orientation=Gtk.Orientation.VERTICAL,
        )

        self.version = self.load_version()

        self.update_ready = False

        self.changelog_path = os.path.join(
            tempfile.gettempdir(),
            "ardana-themehub-changelog.md",
        )

        self.pack_start(
            self.build(),
            False,
            False,
            0,
        )

        self.set_hexpand(
            True,
        )

    # =====================================================
    # Version
    # =====================================================

    def load_version(
        self,
    ):

        if not os.path.exists(
            VERSION_FILE
        ):
            return self.parse_version(
                ""
            )

        try:

            with open(
                VERSION_FILE,
                "r",
                encoding="utf-8",
            ) as file:

                return self.parse_version(
                    file.read()
                )

        except Exception as error:

            print(
                "Failed to load version:",
                error,
            )

            return self.parse_version(
                ""
            )

    # =====================================================
    # Build
    # =====================================================

    def build(
        self,
    ):

        card = create_card(
            spacing=0
        )

        card.set_hexpand(
            True
        )

        card.pack_start(
            self.build_header(),
            False,
            False,
            0,
        )

        return card

    # =====================================================
    # Header
    # =====================================================

    def build_header(
        self,
    ):

        header = Gtk.Box(
            orientation=Gtk.Orientation.HORIZONTAL,
            spacing=20,
        )

        header.set_hexpand(
            True
        )

        # -------------------------------------------------
        # Artwork
        # -------------------------------------------------

        if os.path.exists(
            LOGO_PATH
        ):

            try:

                pixbuf = (
                    GdkPixbuf.Pixbuf.new_from_file_at_scale(
                        LOGO_PATH,
                        width=208,
                        height=130,
                        preserve_aspect_ratio=True,
                    )
                )

                artwork = Gtk.Image.new_from_pixbuf(
                    pixbuf
                )

            except Exception:

                artwork = Gtk.Image()

        else:

            artwork = Gtk.Image()

        self.artwork = artwork

        header.pack_start(
            artwork,
            False,
            False,
            0,
        )

        # -------------------------------------------------
        # Right
        # -------------------------------------------------

        right = Gtk.Box(
            orientation=Gtk.Orientation.VERTICAL,
            spacing=0,
        )

        right.set_hexpand(
            True
        )

        right.set_valign(
            Gtk.Align.CENTER
        )

        # -------------------------------------------------
        # Text
        # -------------------------------------------------

        text = Gtk.Box(
            orientation=Gtk.Orientation.VERTICAL,
            spacing=8,
        )

        version = self.version[
            "VERSION"
        ]

        channel = self.version[
            "CHANNEL"
        ].title()

        codename = self.version[
            "CODENAME"
        ]

        build = self.version[
            "BUILD"
        ]

        if codename:

            title_text = f"ARDANA -[[ {codename} ]]-"

        else:

            title_text = "ARDANA"

        self.title_label = Gtk.Label()

        self.title_label.set_markup(
            f"<span size='22000' "
            f"weight='bold'>"
            f"{title_text}"
            f"</span>"
        )

        self.title_label.set_xalign(
            0
        )

        version_text = (
            f"{channel} • "
            f"Version {version} • "
            f"Build {build}"
        )

        self.version_label = Gtk.Label(
            label=version_text,
        )

        self.version_label.get_style_context().add_class(
            "dim"
        )

        self.version_label.set_xalign(
            0
        )

        self.status = Gtk.Label()

        self.status.set_markup(
            "You're using the latest version."
        )

        self.status.connect(
            "activate-link",
            self.on_link_clicked,
        )

        self.status.set_xalign(
            0
        )

        text.pack_start(
            self.title_label,
            False,
            False,
            0,
        )

        text.pack_start(
            self.version_label,
            False,
            False,
            0,
        )

        text.pack_start(
            self.status,
            False,
            False,
            0,
        )

        right.pack_start(
            text,
            False,
            False,
            0,
        )

        # -------------------------------------------------
        # Button
        # -------------------------------------------------

        button_box = Gtk.Box(
            orientation=Gtk.Orientation.HORIZONTAL,
        )

        button_box.set_margin_top(
            14
        )

        self.button = Gtk.Button(
            label="Check for Updates",
        )

        self.button.connect(
            "clicked",
            self.check_updates,
        )

        button_box.pack_start(
            self.button,
            False,
            False,
            0,
        )

        right.pack_start(
            button_box,
            False,
            False,
            0,
        )

        header.pack_start(
            right,
            True,
            True,
            0,
        )

        return header

    # =====================================================
    # Check Updates
    # =====================================================

    def check_updates(
        self,
        button,
    ):

        label = self.button.get_label()

        if label == "Update Now":

            if self.update_ready:

                self.show_install_dialog()

            else:

                self.download_update()

            return

        self.button.set_sensitive(
            False
        )

        self.button.get_style_context().remove_class(
            "update-button"
        )

        self.button.set_label(
            "Checking..."
        )

        self.set_status(
            "Checking for updates..."
        )

        threading.Thread(
            target=self._check_updates,
            daemon=True,
        ).start()

    def _check_updates(
        self,
    ):

        try:

            with urllib.request.urlopen(
                REMOTE_VERSION,
                timeout=10,
            ) as response:

                remote = self.parse_version(
                    response.read().decode(
                        "utf-8"
                    )
                )

                self.remote_version = remote

            local_build = int(
                self.version[
                    "BUILD"
                ]
            )

            remote_build = int(
                remote[
                    "BUILD"
                ]
            )

            if remote_build > local_build:

                self.set_status(
                    "Update available: "
                    f'Version {remote["VERSION"]} • '
                    f'Build {remote["BUILD"]} '
                    '(<a href="changelog">'
                    'See changelog'
                    '</a>)'
                )

                self.add_button_class(
                    "update-button"
                )

                self.set_button_label(
                    "Update Now"
                )

            else:

                self.set_status(
                    "You're using the latest version."
                )

                self.remove_button_class(
                    "update-button"
                )

                self.set_button_label(
                    "Check for Updates"
                )

        except Exception as error:

            print(
                error
            )

            self.set_status(
                "Unable to check for updates."
            )

            self.remove_button_class(
                "update-button"
            )

            self.set_button_label(
                "Check for Updates"
            )

        finally:

            self.set_button_sensitive(
                True
            )

    # =====================================================
    # Parse Version
    # =====================================================

    def parse_version(
        self,
        text,
    ):

        data = {
            "VERSION": "Unknown",
            "CHANNEL": "Unknown",
            "CODENAME": "",
            "BUILD": "0",
        }

        for line in text.splitlines():

            line = line.strip()

            if "=" not in line:
                continue

            key, value = line.split(
                "=",
                1,
            )

            data[
                key.strip()
            ] = value.strip()

        return data

    # =====================================================
    # Download Update
    # =====================================================

    def download_update(
        self,
    ):

        self.button.set_sensitive(
            False
        )

        self.button.get_style_context().remove_class(
            "update-button"
        )

        self.button.set_label(
            "Downloading..."
        )

        self.set_status(
            "Downloading update..."
        )

        try:

            temp_dir = tempfile.gettempdir()

            self.zip_path = os.path.join(
                temp_dir,
                "ardana-themehub-update.zip",
            )

            urllib.request.urlretrieve(
                REMOTE_UPDATE,
                self.zip_path,
            )

            print(
                "Downloaded:",
                self.zip_path,
            )

            self.update_ready = True

            self.set_status(
                "Update is ready to install."
            )

            self.button.get_style_context().add_class(
                "update-button"
            )

            self.button.set_label(
                "Update Now"
            )

            self.show_install_dialog()

        except Exception as error:

            print(
                error
            )

            self.set_status(
                "Download failed. "
                "Check your connection."
            )

            self.button.set_label(
                "Update Now"
            )

            self.button.get_style_context().add_class(
                "update-button"
            )

        finally:

            self.button.set_sensitive(
                True
            )

    # =====================================================
    # Install Dialog
    # =====================================================

    def show_install_dialog(
        self,
    ):

        dialog = InstallDialog(
            self.get_toplevel(),
            self.install_update,
        )

        dialog.show_all()

    # =====================================================
    # Install Update
    # =====================================================

    def install_update(
        self,
        create_backup,
    ):

        self.button.set_sensitive(
            False
        )

        self.button.get_style_context().remove_class(
            "update-button"
        )

        self.button.set_label(
            "Installing..."
        )

        self.set_status(
            "Installing update..."
        )

        threading.Thread(
            target=self._install_update,
            args=(create_backup,),
            daemon=True,
        ).start()

    def _install_update(
        self,
        create_backup,
    ):

        print(
            "Backup:",
            create_backup,
        )

        try:

            if create_backup:

                self.create_backup()

            self.extract_update()

            self.copy_update()

            self.finish_install()

        except Exception as error:

            print(
                error
            )

            self.set_status(
                "Installation failed."
            )

            GLib.idle_add(
                self.button.set_label,
                "Update Now",
            )

            GLib.idle_add(
                lambda:
                self.button
                .get_style_context()
                .add_class(
                    "update-button"
                )
            )

            GLib.idle_add(
                self.button.set_sensitive,
                True,
            )

    # =====================================================
    # Extract Update
    # =====================================================

    def extract_update(
        self,
    ):

        self.set_status(
            "Extracting update..."
        )

        self.wait()

        temp_dir = tempfile.gettempdir()

        self.extract_dir = os.path.join(
            temp_dir,
            "ardana-themehub-update",
        )

        if os.path.exists(
            self.extract_dir
        ):

            shutil.rmtree(
                self.extract_dir
            )

        with zipfile.ZipFile(
            self.zip_path,
            "r",
        ) as archive:

            base = os.path.realpath(
                self.extract_dir
            )

            for member in archive.infolist():
                target = os.path.realpath(
                    os.path.join(
                        self.extract_dir,
                        member.filename,
                    )
                )

                if not (
                    target == base
                    or target.startswith(
                        base + os.sep
                    )
                ):
                    raise ValueError(
                        "Unsafe ZIP path"
                    )

            archive.extractall(
                self.extract_dir
            )

        print(
            "Extracted:",
            self.extract_dir,
        )

    # =====================================================
    # Copy Update
    # =====================================================

    def copy_update(
        self,
    ):
        self.wait()

        core = os.path.join(
            self.extract_dir,
            "core",
        )

        if os.path.isdir(core):
            self.set_status(
                "Updating Ardana Core..."
            )
            self.copy_tree(
                core,
                ARDANA_DIR,
            )

        themehub = os.path.join(
            self.extract_dir,
            "themehub",
        )

        if os.path.isdir(themehub):
            self.set_status(
                "Updating Ardana ThemeHub..."
            )
            self.copy_tree(
                themehub,
                THEMEHUB_DIR,
            )

        icons = os.path.join(
            self.extract_dir,
            "icons",
        )

        if os.path.isdir(icons):
            self.set_status(
                "Updating Ardana icons..."
            )

            for size in (
                "32x32",
                "48x48",
                "128x128",
                "256x256",
                "512x512",
            ):
                source_icon = os.path.join(
                    icons,
                    size,
                    "Ardana.png",
                )

                if not os.path.isfile(source_icon):
                    continue

                destination_dir = os.path.join(
                    ICON_DIR,
                    size,
                    "apps",
                )

                os.makedirs(
                    destination_dir,
                    exist_ok=True,
                )

                shutil.copy2(
                    source_icon,
                    os.path.join(
                        destination_dir,
                        "Ardana.png",
                    ),
                )

            subprocess.run(
                [
                    "gtk-update-icon-cache",
                    "-f",
                    "-t",
                    ICON_DIR,
                ],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                check=False,
            )

        app_path = os.path.join(
            THEMEHUB_DIR,
            "app.py",
        )

        if os.path.isfile(app_path):
            os.chmod(
                app_path,
                os.stat(app_path).st_mode | 0o111,
            )

        scripts_dir = os.path.join(
            ARDANA_DIR,
            "scripts",
        )

        if os.path.isdir(scripts_dir):
            for root, dirs, files in os.walk(
                scripts_dir
            ):
                for filename in files:
                    if not filename.endswith(".sh"):
                        continue

                    path = os.path.join(
                        root,
                        filename,
                    )

                    os.chmod(
                        path,
                        os.stat(path).st_mode | 0o111,
                    )

    # =====================================================
    # Merge Copy Helper
    # =====================================================

    def copy_tree(
        self,
        source,
        destination,
    ):
        """
        Merge source into destination.

        Existing files with the same relative path are
        overwritten. Files that exist only in the installed
        destination are preserved.
        """

        os.makedirs(
            destination,
            exist_ok=True,
        )

        for root, dirs, files in os.walk(
            source
        ):
            relative = os.path.relpath(
                root,
                source,
            )

            target_root = (
                destination
                if relative == "."
                else os.path.join(
                    destination,
                    relative,
                )
            )

            os.makedirs(
                target_root,
                exist_ok=True,
            )

            for filename in files:
                source_file = os.path.join(
                    root,
                    filename,
                )

                destination_file = os.path.join(
                    target_root,
                    filename,
                )

                shutil.copy2(
                    source_file,
                    destination_file,
                )

    # =====================================================
    # Finish Install
    # =====================================================

    def finish_install(
        self,
    ):

        self.set_status(
            "Finalizing installation..."
        )

        self.wait(
            0.5
        )

        self.refresh_version()
        self.refresh_logo()
        self.refresh_icon_cache()

        self.update_ready = False

        self.set_status(
            "Update installed successfully."
        )

        self.wait(
            1.0
        )

        self.remove_button_class(
            "update-button"
        )

        self.set_button_label(
            "Check for Updates"
        )

        self.set_button_sensitive(
            True
        )

        self.set_status(
            "You're using the latest version."
        )

    # =====================================================
    # Refresh Version
    # =====================================================

    def refresh_version(
        self,
    ):

        self.version = self.load_version()

        version = self.version[
            "VERSION"
        ]

        channel = self.version[
            "CHANNEL"
        ].title()

        codename = self.version[
            "CODENAME"
        ]

        build = self.version[
            "BUILD"
        ]

        if codename:

            title = (
                f'ARDANA "{codename}"'
            )

        else:

            title = "ARDANA"

        text = (
            f"{channel} • "
            f"Version {version} • "
            f"Build {build}"
        )

        GLib.idle_add(
            self.title_label.set_markup,
            (
                f"<span size='22000' "
                f"weight='bold'>"
                f"{title}"
                f"</span>"
            ),
        )

        GLib.idle_add(
            self.version_label.set_label,
            text,
        )

    # =====================================================
    # Refresh Logo
    # =====================================================

    def refresh_logo(
        self,
    ):

        def callback():
            try:
                if not os.path.isfile(
                    LOGO_PATH
                ):
                    return False

                pixbuf = (
                    GdkPixbuf.Pixbuf.new_from_file_at_scale(
                        LOGO_PATH,
                        width=208,
                        height=130,
                        preserve_aspect_ratio=True,
                    )
                )

                self.artwork.set_from_pixbuf(
                    pixbuf
                )
                self.artwork.show()

            except Exception as error:
                print(
                    "Failed to refresh logo:",
                    error,
                )

            return False

        GLib.idle_add(
            callback
        )

    # =====================================================
    # Refresh Icon Cache
    # =====================================================

    def refresh_icon_cache(
        self,
    ):

        def callback():
            try:
                subprocess.run(
                    [
                        "gtk-update-icon-cache",
                        "-f",
                        "-t",
                        ICON_DIR,
                    ],
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                    check=False,
                )

                applications_dir = os.path.join(
                    HOME,
                    ".local",
                    "share",
                    "applications",
                )

                if os.path.isdir(
                    applications_dir
                ):
                    subprocess.run(
                        [
                            "update-desktop-database",
                            applications_dir,
                        ],
                        stdout=subprocess.DEVNULL,
                        stderr=subprocess.DEVNULL,
                        check=False,
                    )

            except Exception as error:
                print(
                    "Failed to refresh icon cache:",
                    error,
                )

            return False

        GLib.idle_add(
            callback
        )

    # =====================================================
    # Create Backup
    # =====================================================

    def create_backup(
        self,
    ):

        self.set_status(
            "Creating backup..."
        )

        self.wait()

        backup_dir = os.path.join(
            THEMEHUB_DIR,
            "backups",
        )

        os.makedirs(
            backup_dir,
            exist_ok=True,
        )

        version = self.version[
            "VERSION"
        ]

        timestamp = datetime.now().strftime(
            "%Y%m%d-%H%M%S"
        )

        backup_file = os.path.join(
            backup_dir,
            f"ArdanaThemeHub-"
            f"{version}-"
            f"{timestamp}.zip",
        )

        with zipfile.ZipFile(
            backup_file,
            "w",
            zipfile.ZIP_DEFLATED,
        ) as archive:

            # -------------------------------------------------
            # Backup ThemeHub
            # -------------------------------------------------

            if os.path.isdir(
                THEMEHUB_DIR
            ):

                for root, dirs, files in os.walk(
                    THEMEHUB_DIR
                ):

                    for skip in (
                        "backups",
                        "__pycache__",
                    ):

                        if skip in dirs:

                            dirs.remove(
                                skip
                            )

                    for file in files:

                        path = os.path.join(
                            root,
                            file,
                        )

                        archive.write(
                            path,
                            os.path.join(
                                "themehub",
                                os.path.relpath(
                                    path,
                                    THEMEHUB_DIR,
                                ),
                            ),
                        )

            # -------------------------------------------------
            # Backup Ardana runtime
            # -------------------------------------------------

            if os.path.isdir(
                ARDANA_DIR
            ):

                for root, dirs, files in os.walk(
                    ARDANA_DIR
                ):

                    for skip in (
                        "__pycache__",
                    ):

                        if skip in dirs:

                            dirs.remove(
                                skip
                            )

                    for file in files:

                        path = os.path.join(
                            root,
                            file,
                        )

                        archive.write(
                            path,
                            os.path.join(
                                "ardana",
                                os.path.relpath(
                                    path,
                                    ARDANA_DIR,
                                ),
                            ),
                        )

        print(
            "Backup:",
            backup_file,
        )

    # =====================================================
    # UI Helpers
    # =====================================================

    def set_status(
        self,
        text,
    ):

        GLib.idle_add(
            self.status.set_markup,
            text,
        )

    def set_button_label(
        self,
        text,
    ):

        GLib.idle_add(
            self.button.set_label,
            text,
        )

    def add_button_class(
        self,
        name,
    ):

        def callback():

            self.button.get_style_context().add_class(
                name
            )

            return False

        GLib.idle_add(
            callback
        )

    def remove_button_class(
        self,
        name,
    ):

        def callback():

            self.button.get_style_context().remove_class(
                name
            )

            return False

        GLib.idle_add(
            callback
        )

    def set_button_sensitive(
        self,
        sensitive,
    ):

        GLib.idle_add(
            self.button.set_sensitive,
            sensitive,
        )

    # =====================================================
    # Helper
    # =====================================================

    def wait(
        self,
        seconds=2.0,
    ):

        time.sleep(
            seconds
        )

    # =====================================================
    # Changelog
    # =====================================================

    def on_link_clicked(
        self,
        label,
        uri,
    ):

        if uri == "changelog":

            self.show_changelog()

        return True

    def show_changelog(
        self,
    ):

        try:

            if not os.path.exists(
                self.changelog_path
            ):

                urllib.request.urlretrieve(
                    REMOTE_CHANGELOG,
                    self.changelog_path,
                )

            with open(
                self.changelog_path,
                "r",
                encoding="utf-8",
            ) as file:

                changelog = file.read()

            dialog = ChangelogDialog(
                self.get_toplevel(),
                changelog,
            )

            dialog.show_all()

        except Exception as error:

            print(
                error
            )

            self.set_status(
                "Unable to load changelog."
            )

    # =====================================================
    # Copy Tree
    # =====================================================

    def copy_tree(
        self,
        src_dir,
        dst_dir,
    ):

        os.makedirs(
            dst_dir,
            exist_ok=True,
        )

        for name in os.listdir(
            src_dir
        ):

            src = os.path.join(
                src_dir,
                name,
            )

            dst = os.path.join(
                dst_dir,
                name,
            )

            if os.path.isdir(
                src
            ):

                shutil.copytree(
                    src,
                    dst,
                    dirs_exist_ok=True,
                )

            else:

                shutil.copy2(
                    src,
                    dst,
                )
