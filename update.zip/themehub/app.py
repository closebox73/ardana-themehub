import gi

gi.require_version("Gtk", "3.0")
from gi.repository import Gtk, Gdk

from ui.dashboard import DashboardPage
from ui.market import MarketPage
from ui.about import AboutPage
from ui.settings import SettingsPage


APP_CSS = """
window {
    background-color: @theme_bg_color;
}

.main-window {
    background-color: @theme_bg_color;
}

/* =========================
   Window Decoration
   ========================= */

window,
window:focus,
window:backdrop {
    border: none;
    outline: none;
}

decoration,
decoration:backdrop {
    border: none;
    box-shadow: none;
}

/* =========================
   Navigation
   ========================= */

headerbar.navbar,
headerbar.navbar:backdrop {
    border: none;
    box-shadow: none;
}

.navbar {
    padding: 1px 16px;
}

.nav-item {
    background-color: transparent;
    border: none;
    border-radius: 4px;
    padding: 7px 25px;
    color: @theme_fg_color;
}

.nav-item:hover {
    background-color: alpha(@theme_selected_bg_color, 0.35);
    color: @theme_fg_color;
}

.nav-item.active {
    background-color: @theme_selected_bg_color;
    color: @theme_selected_fg_color;
}

.nav-icon {
    color: @theme_fg_color;
}

.nav-item:hover .nav-icon {
    color: @theme_selected_fg_color;
}

.nav-item.active .nav-icon {
    color: @theme_selected_fg_color;
}

.content {
    padding: 28px;
}

.page-title {
    color: @theme_fg_color;
    font-size: 22px;
    font-weight: bold;
}

.page-subtitle {
    color: @insensitive_fg_color;
    font-size: 14px;
}

/* =========================
   Theme Card
   ========================= */

.theme-card {
    background-color: @theme_base_color;
    border: 1px solid @borders;
    border-radius: 10px;
}

.theme-card:hover {
    border-color: @theme_selected_bg_color;
}

.theme-name {
    color: @theme_fg_color;
    font-size: 18px;
    font-weight: bold;
}

.theme-info {
    color: @insensitive_fg_color;
    font-size: 13px;
}

.customize-icon {
    font-size: 16px;
}

.customize-section-title {
    font-size: 18px;
    font-weight: bold;
}

/* =========================
   Common Widgets
   ========================= */

.card {
    background-color: shade(@theme_base_color, 0.96);
    border: 1px solid @borders;
    border-radius: 6px;
    padding: 28px;
}

.dim {
    color: @insensitive_fg_color;
}

.heading {
    color: @theme_fg_color;
    font-size: 15px;
    font-weight: bold;
}

.brand {
    color: shade(@theme_selected_bg_color, 1.15);
    font-weight: bold;
}

.update-button {
    background: @theme_selected_bg_color;
    color: @theme_selected_fg_color;
}

.update-button label {
    color: @theme_selected_fg_color;
}

.update-button:hover {
    background: shade(@theme_selected_bg_color, 1.08);
}

.update-button:active {
    background: shade(@theme_selected_bg_color, 0.92);
}

/* =========================
   Settings
   ========================= */

.settings-card {
    background-color: shade(@theme_base_color, 0.96);
    border: 1px solid @borders;
    border-radius: 6px;
    padding: 0;
}

.settings-card:hover {
    background-color: shade(@theme_base_color, 0.92);
    border-color: @theme_selected_bg_color;
}

.settings-card-selected {
    background-color: @theme_selected_bg_color;
    border-color: @theme_selected_bg_color;
}

.settings-card-selected:hover {
    background-color: @theme_selected_bg_color;
    border-color: @theme_selected_bg_color;
}

.settings-card-selected .heading,
.settings-card-selected .dim {
    color: @theme_selected_fg_color;
}

.warning {
    color: @warning_color;
    font-size: 12px;
}

button.refresh-changed {
    background: @theme_selected_bg_color;
    color: @theme_selected_fg_color;
}

button.refresh-changed label {
    color: @theme_selected_fg_color;
}

button.refresh-changed:hover {
    background: shade(@theme_selected_bg_color, 1.08);
}

button.refresh-changed:active {
    background: shade(@theme_selected_bg_color, 0.92);
}

.market-tab.active {
    background-color: @theme_selected_bg_color;
    color: @theme_selected_fg_color;
}

.market-update-button {
    color: @theme_fg_color;
    background-color: @success_color;
}

.market-delete-button {
    color: @theme_fg_color;
    background-color: @error_color;
}

"""


class ArdanaWindow(Gtk.Window):

    def __init__(self):
        super().__init__(
            title="Ardana ThemeHub"
        )

        self.set_default_size(900, 650)

        self.set_position(
            Gtk.WindowPosition.CENTER
        )

        self.load_css()

        # =========================
        # Main container
        # =========================

        main = Gtk.Box(
            orientation=Gtk.Orientation.VERTICAL
        )

        main.get_style_context().add_class(
            "main-window"
        )

        self.add(main)

        # =========================
        # Navigation
        # =========================

        self.navbar = Gtk.HeaderBar()

        self.navbar.set_show_close_button(
            False
        )

        self.navbar.set_title(
            None
        )

        self.navbar.set_subtitle(
            None
        )

        self.navbar.get_style_context().add_class(
            "navbar"
        )

        main.pack_start(
            self.navbar,
            False,
            False,
            0
        )

        # =========================
        # Center navigation
        # =========================

        self.nav_menu = Gtk.Box(
            orientation=Gtk.Orientation.HORIZONTAL,
            spacing=4
        )

        self.nav_menu.set_halign(
            Gtk.Align.CENTER
        )

        self.navbar.set_custom_title(
            self.nav_menu
        )

        # =========================
        # Pages
        # =========================

        self.stack = Gtk.Stack()

        self.stack.set_transition_type(
            Gtk.StackTransitionType.NONE
        )

        main.pack_start(
            self.stack,
            True,
            True,
            0
        )

        self.dashboard_page = DashboardPage()
        self.market_page = MarketPage()
        self.settings_page = SettingsPage()
        self.about_page = AboutPage()

        self.stack.add_named(
            self.dashboard_page,
            "dashboard"
        )

        self.stack.add_named(
            self.market_page,
            "market"
        )

        self.stack.add_named(
            self.settings_page,
            "settings"
        )

        self.stack.add_named(
            self.about_page,
            "about"
        )

        # =========================
        # Navigation buttons
        # =========================

        self.nav_buttons = {}

        self.create_nav_item(
            "dashboard",
            "go-home-symbolic",
            "Dashboard"
        )

        self.create_nav_item(
            "market",
            "folder-symbolic",
            "Market"
        )

        self.create_nav_item(
            "settings",
            "emblem-system-symbolic",
            "Settings"
        )

        self.create_nav_item(
            "about",
            "dialog-information-symbolic",
            "About"
        )

        # =========================
        # Initial page
        # =========================

        self.set_page(
            "dashboard"
        )

    # =====================================================
    # Navigation
    # =====================================================

    def create_nav_item(
        self,
        page_name,
        icon,
        text
    ):

        button = Gtk.Button()

        button.set_relief(
            Gtk.ReliefStyle.NONE
        )

        button.get_style_context().add_class(
            "nav-item"
        )

        box = Gtk.Box(
            orientation=Gtk.Orientation.HORIZONTAL,
            spacing=9
        )

        image = Gtk.Image.new_from_icon_name(
            icon,
            Gtk.IconSize.BUTTON
        )

        image.get_style_context().add_class(
            "nav-icon"
        )

        label = Gtk.Label(
            label=text
        )

        box.pack_start(
            image,
            False,
            False,
            0
        )

        box.pack_start(
            label,
            False,
            False,
            0
        )

        button.add(
            box
        )

        button.connect(
            "clicked",
            self.on_nav_clicked,
            page_name
        )

        self.nav_menu.pack_start(
            button,
            False,
            False,
            0
        )

        self.nav_buttons[
            page_name
        ] = button

    def on_nav_clicked(
        self,
        button,
        page_name
    ):

        self.set_page(
            page_name
        )

    def set_page(
        self,
        page_name
    ):

        self.stack.set_visible_child_name(
            page_name
        )

        for name, button in self.nav_buttons.items():

            context = (
                button.get_style_context()
            )

            if name == page_name:
                context.add_class(
                    "active"
                )
            else:
                context.remove_class(
                    "active"
                )

    # =====================================================
    # CSS
    # =====================================================

    def load_css(self):

        provider = Gtk.CssProvider()

        provider.load_from_data(
            APP_CSS.encode()
        )

        Gtk.StyleContext.add_provider_for_screen(
            Gdk.Screen.get_default(),
            provider,
            Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION
        )


def main():

    window = ArdanaWindow()

    window.connect(
        "destroy",
        Gtk.main_quit
    )

    window.show_all()

    Gtk.main()


if __name__ == "__main__":
    main()
