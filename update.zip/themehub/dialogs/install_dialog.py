#!/usr/bin/env python3

import gi

gi.require_version("Gtk", "3.0")

from gi.repository import (
    Gtk,
    Pango,
)


class InstallDialog(Gtk.Dialog):

    def __init__(
        self,
        parent,
        callback,
    ):

        super().__init__(
            title="Warning",
            transient_for=parent,
            modal=True,
        )

        self.callback = callback

        self.set_default_size(
            430,
            -1,
        )

        self.set_resizable(False)

        content = self.get_content_area()

        # =====================================================
        # Main Box
        # =====================================================

        root = Gtk.Box(
            orientation=Gtk.Orientation.VERTICAL,
            spacing=18,
        )

        root.set_margin_top(24)
        root.set_margin_bottom(24)
        root.set_margin_start(24)
        root.set_margin_end(24)

        content.pack_start(
            root,
            False,
            False,
            0,
        )

        # =====================================================
        # Title
        # =====================================================

        title = Gtk.Label()

        title.set_markup(
            "<span size='18000' weight='bold'>Install Ardana Update?</span>"
        )

        title.set_xalign(0)

        root.pack_start(
            title,
            False,
            False,
            0,
        )

        # =====================================================
        # Description
        # =====================================================

        desc = Gtk.Label(
            label=(
                "The latest version of Ardana is ready to install."
            )
        )

        desc.get_style_context().add_class(
            "dim"
        )

        desc.set_line_wrap(True)
        desc.set_line_wrap_mode(
            Pango.WrapMode.WORD_CHAR
        )

        desc.set_xalign(0)

        root.pack_start(
            desc,
            False,
            False,
            0,
        )

        # =====================================================
        # Information
        # =====================================================

        info = Gtk.Box(
            orientation=Gtk.Orientation.VERTICAL,
            spacing=8,
        )

        root.pack_start(
            info,
            False,
            False,
            0,
        )

        items = [
            "✓ Existing theme(s) will be preserved",
            "✓ Existing settings will be preserved",
            "✓ Existing state data will be preserved",
        ]

        for text in items:

            label = Gtk.Label(
                label=text
            )

            label.set_xalign(0)

            info.pack_start(
                label,
                False,
                False,
                0,
            )

        # =====================================================
        # Backup
        # =====================================================

        backup_box = Gtk.Box(
            orientation=Gtk.Orientation.VERTICAL,
            spacing=4,
        )

        backup_box.set_margin_top(8)

        root.pack_start(
            backup_box,
            False,
            False,
            0,
        )

        self.backup = Gtk.CheckButton(
            label="Create a backup before installing"
        )

        self.backup.set_active(True)

        backup_box.pack_start(
            self.backup,
            False,
            False,
            0,
        )

        note = Gtk.Label(
            label="Recommended before installing major updates."
        )

        note.get_style_context().add_class(
            "dim"
        )

        note.set_xalign(0)

        backup_box.pack_start(
            note,
            False,
            False,
            22,
        )

        # =====================================================
        # Buttons
        # =====================================================

        buttons = Gtk.Box(
            orientation=Gtk.Orientation.HORIZONTAL,
            spacing=10,
        )

        buttons.set_margin_top(12)

        root.pack_start(
            buttons,
            False,
            False,
            0,
        )

        # =====================================================
        # Cancel
        # =====================================================

        cancel = Gtk.Button(
            label="Cancel"
        )

        cancel.set_hexpand(True)

        cancel.connect(
            "clicked",
            self.on_cancel,
        )

        buttons.pack_start(
            cancel,
            True,
            True,
            0,
        )

        # =====================================================
        # Install
        # =====================================================

        install = Gtk.Button(
            label="Install Update"
        )

        install.set_hexpand(True)

        install.get_style_context().add_class(
            "suggested-action"
        )

        install.connect(
            "clicked",
            self.on_install,
        )

        buttons.pack_start(
            install,
            True,
            True,
            0,
        )

        self.show_all()

    # =====================================================
    # Cancel
    # =====================================================

    def on_cancel(
        self,
        button,
    ):

        self.destroy()

    # =====================================================
    # Install
    # =====================================================

    def on_install(
        self,
        button,
    ):

        self.callback(
            self.backup.get_active()
        )

        self.destroy()
