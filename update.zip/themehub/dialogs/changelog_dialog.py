#!/usr/bin/env python3

import gi

gi.require_version("Gtk", "3.0")

from gi.repository import (
    GLib,
    Gtk,
    Pango,
)


class ChangelogDialog(Gtk.Dialog):

    def __init__(
        self,
        parent,
        changelog,
    ):

        super().__init__(
            title="Changelog",
            transient_for=parent,
            modal=True,
        )

        self.set_default_size(
            500,
            420,
        )

        content = self.get_content_area()

        # =====================================================
        # Main Box
        # =====================================================

        root = Gtk.Box(
            orientation=Gtk.Orientation.VERTICAL,
            spacing=18,
        )

        root.set_margin_top(18)
        root.set_margin_bottom(18)
        root.set_margin_start(18)
        root.set_margin_end(18)

        content.add(root)

        # =====================================================
        # Scroll
        # =====================================================

        scroll = Gtk.ScrolledWindow()

        scroll.set_hexpand(True)
        scroll.set_vexpand(True)

        root.pack_start(
            scroll,
            True,
            True,
            0,
        )

        # =====================================================
        # Changelog
        # =====================================================

        label = Gtk.Label()

        label.set_markup(
            self.markdown_to_markup(
                changelog
            )
        )

        label.set_selectable(False)
        label.set_line_wrap(True)
        label.set_line_wrap_mode(
            Pango.WrapMode.WORD_CHAR
        )
        label.set_xalign(0)
        label.set_yalign(0)

        scroll.add(label)

        # =====================================================
        # Actions
        # =====================================================

        actions = Gtk.Box(
            orientation=Gtk.Orientation.HORIZONTAL,
        )

        actions.set_halign(
            Gtk.Align.END,
        )

        root.pack_start(
            actions,
            False,
            False,
            0,
        )

        close_button = Gtk.Button(
            label="Close",
        )

        close_button.connect(
            "clicked",
            lambda *_: self.destroy(),
        )

        actions.pack_end(
            close_button,
            False,
            False,
            0,
        )

        self.show_all()

    # =====================================================
    # Markdown
    # =====================================================

    def markdown_to_markup(
        self,
        text,
    ):

        lines = []

        for line in text.splitlines():

            line = line.rstrip()

            if line.startswith("# "):

                lines.append(
                    f'<span size="xx-large" weight="bold">'
                    f'{GLib.markup_escape_text(line[2:])}'
                    "</span>"
                )

            elif line.startswith("## "):

                lines.append("")

                lines.append(
                    f'<span size="x-large" weight="bold">'
                    f'{GLib.markup_escape_text(line[3:])}'
                    "</span>"
                )

            elif line.startswith("### "):

                lines.append("")

                lines.append(
                    f'<span size="large" weight="bold">'
                    f'{GLib.markup_escape_text(line[4:])}'
                    "</span>"
                )

            elif line.startswith("- "):

                lines.append(
                    "• "
                    + GLib.markup_escape_text(
                        line[2:]
                    )
                )

            else:

                lines.append(
                    GLib.markup_escape_text(
                        line
                    )
                )

        return "\n".join(lines)
