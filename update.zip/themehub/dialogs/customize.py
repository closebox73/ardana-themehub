import os
import re
import json
import signal
import subprocess

import gi

gi.require_version(
    "Gtk",
    "3.0"
)

from gi.repository import (
    Gtk,
    Gdk,
)


class CustomizeDialog(Gtk.Dialog):

    def __init__(
        self,
        parent,
        theme_name,
        theme_path,
        metadata,
    ):

        super().__init__(
            title="Customize",
            transient_for=parent,
            flags=Gtk.DialogFlags.MODAL,
        )

        self.theme_name = theme_name
        self.theme_path = theme_path
        self.metadata = metadata

        self.original_colors = {}
        self.color_widgets = {}

        self.original_scale = None
        self.scale_entry = None

        self.apply_button = None
        self.reset_button = None
        self.default_data = self.load_default()

        self.set_default_size(
            600,
            560,
        )

        self.set_resizable(
            True
        )

        # =========================
        # Content
        # =========================

        content = self.get_content_area()

        content.set_border_width(
            0
        )

        content.set_spacing(
            0
        )

        main_box = Gtk.Box(
            orientation=Gtk.Orientation.VERTICAL,
            spacing=0,
        )

        content.pack_start(
            main_box,
            True,
            True,
            0,
        )

        # =========================
        # Header
        # =========================

        header = Gtk.Box(
            orientation=Gtk.Orientation.HORIZONTAL,
            spacing=12,
        )

        header.set_border_width(
            16
        )

        main_box.pack_start(
            header,
            False,
            False,
            0,
        )

        title = Gtk.Label(
            label="Customize"
        )

        title.set_xalign(
            0
        )

        title.get_style_context().add_class(
            "page-title"
        )

        header.pack_start(
            title,
            True,
            True,
            0,
        )

        self.apply_button = Gtk.Button(
            label="Apply"
        )

        self.apply_button.set_sensitive(
            False
        )

        self.apply_button.connect(
            "clicked",
            self.on_apply_clicked,
        )

        header.pack_end(
            self.apply_button,
            False,
            False,
            0,
        )

        # =========================
        # Scrolled Content
        # =========================

        scrolled = Gtk.ScrolledWindow()

        scrolled.set_policy(
            Gtk.PolicyType.NEVER,
            Gtk.PolicyType.AUTOMATIC,
        )

        scrolled.set_hexpand(
            True
        )

        scrolled.set_vexpand(
            True
        )

        main_box.pack_start(
            scrolled,
            True,
            True,
            0,
        )

        options = Gtk.Box(
            orientation=Gtk.Orientation.VERTICAL,
            spacing=24,
        )

        options.set_border_width(
            20
        )

        scrolled.add(
            options
        )

        # =========================
        # Colors
        # =========================

        self.build_colors_section(
            options
        )

        # =========================
        # Scale
        # =========================

        self.build_scale_section(
            options
        )

        # =========================
        # Reset
        # =========================

        reset_area = Gtk.Box(
            orientation=Gtk.Orientation.VERTICAL,
            spacing=6,
        )

        reset_area.set_border_width(
            16
        )

        self.reset_button = Gtk.Button(
            label="Reset to Default"
        )

        self.reset_button.set_hexpand(
            True
        )

        self.reset_button.set_sensitive(
            bool(self.default_data)
        )

        self.reset_button.connect(
            "clicked",
            self.on_reset_clicked,
        )

        reset_area.pack_start(
            self.reset_button,
            False,
            False,
            0,
        )

        reset_note = Gtk.Label(
            label=(
                "Restore colors, scale, and geometry "
                "to the theme's original defaults."
            )
        )

        reset_note.set_xalign(
            0.5
        )

        reset_note.set_line_wrap(
            True
        )

        reset_note.get_style_context().add_class(
            "dim-label"
        )

        reset_area.pack_start(
            reset_note,
            False,
            False,
            0,
        )

        options.pack_start(
            reset_area,
            False,
            False,
            0,
        )

        # =========================
        # Close
        # =========================

        self.add_button(
            "Close",
            Gtk.ResponseType.CLOSE,
        )

        self.connect(
            "response",
            self.on_response,
        )

        self.show_all()

        self.check_changes()

    # =====================================================
    # Default State
    # =====================================================

    def load_default(
        self,
    ):
        default_file = os.path.join(
            self.theme_path,
            "default.json",
        )

        if not os.path.isfile(
            default_file
        ):
            print(
                f"Default configuration not found: "
                f"{default_file}"
            )
            return {}

        try:
            with open(
                default_file,
                "r",
                encoding="utf-8",
            ) as file:
                data = json.load(file)

            if not isinstance(data, dict):
                return {}

            return data

        except Exception as error:
            print(
                f"Failed to load default.json: "
                f"{error}"
            )
            return {}

    # =====================================================
    # Colors Section
    # =====================================================

    def build_colors_section(
        self,
        parent,
    ):

        section = Gtk.Box(
            orientation=Gtk.Orientation.VERTICAL,
            spacing=12,
        )

        parent.pack_start(
            section,
            False,
            False,
            0,
        )

        title = Gtk.Label(
            label="Colors"
        )

        title.set_xalign(
            0
        )

        title.get_style_context().add_class(
            "customize-section-title"
        )

        section.pack_start(
            title,
            False,
            False,
            0,
        )

        colors = self.read_colors()

        if not colors:

            empty = Gtk.Label(
                label="No customizable colors found."
            )

            empty.set_xalign(
                0
            )

            section.pack_start(
                empty,
                False,
                False,
                0,
            )

            return

        self.original_colors = colors.copy()

        for name, hex_color in colors.items():

            row = Gtk.Box(
                orientation=Gtk.Orientation.HORIZONTAL,
                spacing=10,
            )

            section.pack_start(
                row,
                False,
                False,
                0,
            )

            label = Gtk.Label(
                label=name
            )

            label.set_xalign(
                0
            )

            row.pack_start(
                label,
                True,
                True,
                0,
            )

            # =========================
            # HEX Entry
            # =========================

            color_entry = Gtk.Entry()

            color_entry.set_width_chars(
                8
            )

            color_entry.set_max_length(
                7
            )

            color_entry.set_text(
                f"#{hex_color}"
            )

            # =========================
            # Color Button
            # =========================

            color_button = Gtk.ColorButton()

            color_button.set_use_alpha(
                False
            )

            color = Gdk.RGBA()

            color.parse(
                f"#{hex_color}"
            )

            color_button.set_rgba(
                color
            )

            # =========================
            # Signals
            # =========================

            color_button.connect(
                "color-set",
                self.on_color_picker_changed,
                color_entry,
            )

            color_entry.connect(
                "changed",
                self.on_color_entry_changed,
                color_button,
            )

            # =========================
            # Store
            # =========================

            self.color_widgets[name] = {
                "button": color_button,
                "entry": color_entry,
            }

            row.pack_end(
                color_entry,
                False,
                False,
                0,
            )

            row.pack_end(
                color_button,
                False,
                False,
                0,
            )

    # =====================================================
    # Read Colors
    # =====================================================

    def read_colors(
        self,
    ):

        color_file = os.path.join(
            self.theme_path,
            "lua",
            "color.lua",
        )

        if not os.path.isfile(
            color_file
        ):
            return {}

        colors = {}

        pattern = re.compile(
            r"^\s*([A-Za-z_][A-Za-z0-9_]*)"
            r"\s*=\s*0x([0-9A-Fa-f]{6})"
            r"\s*,?"
        )

        try:

            with open(
                color_file,
                "r",
                encoding="utf-8",
            ) as file:

                for line in file:

                    match = pattern.match(
                        line
                    )

                    if not match:
                        continue

                    name = match.group(
                        1
                    )

                    value = match.group(
                        2
                    ).upper()

                    colors[name] = value

        except Exception as error:

            print(
                f"Failed to read color.lua: "
                f"{error}"
            )

        return colors

    # =====================================================
    # Scale Section
    # =====================================================

    def build_scale_section(
        self,
        parent,
    ):

        section = Gtk.Box(
            orientation=Gtk.Orientation.VERTICAL,
            spacing=12,
        )

        parent.pack_start(
            section,
            False,
            False,
            0,
        )

        title = Gtk.Label(
            label="Scale"
        )

        title.set_xalign(
            0
        )

        title.get_style_context().add_class(
            "customize-section-title"
        )

        section.pack_start(
            title,
            False,
            False,
            0,
        )

        current_scale = self.read_scale()

        if current_scale is None:

            empty = Gtk.Label(
                label="Scale configuration not found."
            )

            empty.set_xalign(
                0
            )

            section.pack_start(
                empty,
                False,
                False,
                0,
            )

            return

        self.original_scale = current_scale

        # =========================
        # Presets
        # =========================

        # Scale uses 1366px width as the 1.00 baseline.
        # Values are kept to two decimals to match the UI presets.
        presets = [
            ("1024×768", 0.75),
            ("1280×720", 0.93),
            ("1366×768", 1.00),
            ("1600×900", 1.17),
            ("1920×1080", 1.40),
            ("2560×1440", 1.87),
            ("3840×2160", 2.81),
        ]

        preset_box = Gtk.FlowBox()

        preset_box.set_selection_mode(
            Gtk.SelectionMode.NONE
        )

        preset_box.set_max_children_per_line(
            3
        )

        preset_box.set_column_spacing(
            8
        )

        preset_box.set_row_spacing(
            8
        )

        section.pack_start(
            preset_box,
            False,
            False,
            0,
        )

        for label, value in presets:

            button = Gtk.Button()

            button_box = Gtk.Box(
                orientation=Gtk.Orientation.VERTICAL,
                spacing=2,
            )

            resolution = Gtk.Label(
                label=label
            )

            scale = Gtk.Label(
                label=f"{value:.2f}"
            )

            button_box.pack_start(
                resolution,
                False,
                False,
                0,
            )

            button_box.pack_start(
                scale,
                False,
                False,
                0,
            )

            button.add(
                button_box
            )

            button.connect(
                "clicked",
                self.on_preset_clicked,
                value,
            )

            preset_box.add(
                button
            )

        # =========================
        # Manual Scale
        # =========================

        manual_label = Gtk.Label(
            label="Custom Scale"
        )

        manual_label.set_xalign(
            0
        )

        section.pack_start(
            manual_label,
            False,
            False,
            0,
        )

        self.scale_entry = Gtk.Entry()

        self.scale_entry.set_text(
            f"{current_scale:.2f}"
        )

        self.scale_entry.connect(
            "changed",
            self.on_scale_changed,
        )

        section.pack_start(
            self.scale_entry,
            False,
            False,
            0,
        )

    # =====================================================
    # Read Scale
    # =====================================================

    def read_scale(
        self,
    ):

        scale_file = os.path.join(
            self.theme_path,
            "lua",
            "scale.lua",
        )

        if not os.path.isfile(
            scale_file
        ):
            return None

        pattern = re.compile(
            r"^\s*Scale\s*=\s*"
            r"([0-9]+(?:\.[0-9]+)?)"
        )

        try:

            with open(
                scale_file,
                "r",
                encoding="utf-8",
            ) as file:

                for line in file:

                    match = pattern.match(
                        line
                    )

                    if match:

                        return float(
                            match.group(
                                1
                            )
                        )

        except Exception as error:

            print(
                f"Failed to read scale.lua: "
                f"{error}"
            )

        return None

    # =====================================================
    # Auto Scale
    # =====================================================

    def calculate_auto_scale(
        self,
        width,
    ):
        try:
            width = float(width)
            # 1366px is the baseline for Scale 1.00.
            # Truncate to two decimals so 1920 becomes 1.40.
            return int((width / 1366.0) * 100) / 100.0
        except (TypeError, ValueError):
            return 1.00

    # =====================================================
    # Preset
    # =====================================================

    def on_preset_clicked(
        self,
        button,
        value,
    ):

        if not self.scale_entry:
            return

        self.scale_entry.set_text(
            f"{value:.2f}"
        )

    # =====================================================
    # Color Picker Changed
    # =====================================================

    def on_color_picker_changed(
        self,
        button,
        entry,
    ):

        rgba = button.get_rgba()

        red = round(
            rgba.red * 255
        )

        green = round(
            rgba.green * 255
        )

        blue = round(
            rgba.blue * 255
        )

        hex_color = (
            f"#{red:02X}"
            f"{green:02X}"
            f"{blue:02X}"
        )

        entry.set_text(
            hex_color
        )

        self.check_changes()

    # =====================================================
    # Color Entry Changed
    # =====================================================

    def on_color_entry_changed(
        self,
        entry,
        button,
    ):

        value = entry.get_text().strip()

        if not value.startswith(
            "#"
        ):
            value = f"#{value}"

        if not re.fullmatch(
            r"#[0-9A-Fa-f]{6}",
            value,
        ):

            self.check_changes()

            return

        color = Gdk.RGBA()

        if color.parse(
            value
        ):

            button.set_rgba(
                color
            )

        self.check_changes()

    # =====================================================
    # Scale Changed
    # =====================================================

    def on_scale_changed(
        self,
        entry,
    ):

        self.check_changes()

    # =====================================================
    # Current Colors
    # =====================================================

    def get_current_colors(
        self,
    ):

        colors = {}

        for name, widgets in self.color_widgets.items():

            value = (
                widgets["entry"]
                .get_text()
                .strip()
            )

            value = value.lstrip(
                "#"
            ).upper()

            if not re.fullmatch(
                r"[0-9A-F]{6}",
                value,
            ):
                return None

            colors[name] = value

        return colors

    # =====================================================
    # Current Scale
    # =====================================================

    def get_current_scale(
        self,
    ):

        if not self.scale_entry:
            return None

        try:

            value = float(
                self.scale_entry.get_text()
            )

            if value <= 0:
                return None

            return value

        except ValueError:

            return None

    # =====================================================
    # Write Colors
    # =====================================================

    def write_colors(
        self,
        colors,
    ):

        color_file = os.path.join(
            self.theme_path,
            "lua",
            "color.lua",
        )

        if not os.path.isfile(
            color_file
        ):
            return False

        try:

            with open(
                color_file,
                "r",
                encoding="utf-8",
            ) as file:

                content = file.read()

            for name, value in colors.items():

                pattern = (
                    r"(\b"
                    + re.escape(name)
                    + r"\s*=\s*)"
                    + r"0x[0-9A-Fa-f]{6}"
                )

                replacement = (
                    r"\g<1>"
                    + f"0x{value}"
                )

                content = re.sub(
                    pattern,
                    replacement,
                    content,
                )

            with open(
                color_file,
                "w",
                encoding="utf-8",
            ) as file:

                file.write(
                    content
                )

            return True

        except Exception as error:

            print(
                f"Failed to write color.lua: "
                f"{error}"
            )

            return False


    # =====================================================
    # Write Scale
    # =====================================================

    def write_scale(
        self,
        scale,
    ):

        scale_file = os.path.join(
            self.theme_path,
            "lua",
            "scale.lua",
        )

        if not os.path.isfile(
            scale_file
        ):
            return False

        try:

            with open(
                scale_file,
                "r",
                encoding="utf-8",
            ) as file:

                content = file.read()

            content = re.sub(
                r"(^\s*Scale\s*=\s*)"
                r"[0-9]+(?:\.[0-9]+)?",
                r"\g<1>"
                + f"{scale:.2f}",
                content,
                flags=re.MULTILINE,
            )

            with open(
                scale_file,
                "w",
                encoding="utf-8",
            ) as file:

                file.write(
                    content
                )

            return True

        except Exception as error:

            print(
                f"Failed to write scale.lua: "
                f"{error}"
            )

            return False


    # =====================================================
    # Update Config Geometry
    # =====================================================

    def update_config_geometry(
        self,
        scale,
    ):

        configs = self.metadata.get(
            "configs",
            {}
        )

        success = True

        for config_name, config_data in configs.items():

            geometry = config_data.get(
                "geometry",
                {}
            )

            if not geometry:
                continue

            config_path = os.path.join(
                self.theme_path,
                config_name,
            )

            if not os.path.isfile(
                config_path
            ):

                print(
                    f"Config not found: "
                    f"{config_path}"
                )

                success = False

                continue

            try:

                with open(
                    config_path,
                    "r",
                    encoding="utf-8",
                ) as file:

                    content = file.read()

                for key, base_value in geometry.items():

                    value = round(
                        base_value * scale
                    )

                    pattern = (
                        r"(^\s*"
                        + re.escape(key)
                        + r"\s*=\s*)"
                        + r"-?\d+"
                        + r"(\s*,)"
                    )

                    replacement = (
                        r"\g<1>"
                        + str(value)
                        + r"\g<2>"
                    )

                    content, count = re.subn(
                        pattern,
                        replacement,
                        content,
                        flags=re.MULTILINE,
                    )

                    if count == 0:

                        print(
                            f"Geometry key not found "
                            f"in {config_name}: {key}"
                        )

                        success = False

                with open(
                    config_path,
                    "w",
                    encoding="utf-8",
                ) as file:

                    file.write(
                        content
                    )

            except Exception as error:

                print(
                    f"Failed to update "
                    f"{config_name}: {error}"
                )

                success = False

        return success

    # =====================================================
    # Button State
    # =====================================================

    def set_apply_state(
        self,
        active,
    ):
        if not self.apply_button:
            return

        context = self.apply_button.get_style_context()
        context.remove_class("suggested-action")

        if active:
            context.add_class("suggested-action")

        self.apply_button.set_sensitive(bool(active))

    def set_reset_state(
        self,
        active,
    ):
        if not self.reset_button:
            return

        context = self.reset_button.get_style_context()
        context.remove_class("destructive-action")

        if active:
            context.add_class("destructive-action")

        self.reset_button.set_sensitive(
            bool(self.default_data)
        )

    def get_current_geometry(
        self,
    ):
        configs = self.default_data.get("configs", {})
        result = {}

        for config_name, config_data in configs.items():
            geometry = config_data.get("geometry", {})
            if not geometry:
                continue

            config_path = os.path.join(self.theme_path, config_name)
            if not os.path.isfile(config_path):
                return None

            try:
                with open(config_path, "r", encoding="utf-8") as file:
                    content = file.read()

                current = {}
                for key in geometry:
                    if key == "alignment":
                        match = re.search(
                            r"^\s*alignment\s*=\s*['\"]([^'\"]+)['\"]",
                            content, flags=re.MULTILINE
                        )
                        if not match:
                            return None
                        current[key] = match.group(1)
                    else:
                        match = re.search(
                            r"^\s*" + re.escape(key) +
                            r"\s*=\s*(-?\d+(?:\.\d+)?)",
                            content, flags=re.MULTILINE
                        )
                        if not match:
                            return None
                        value = float(match.group(1))
                        current[key] = int(value) if value.is_integer() else value

                result[config_name] = current
            except Exception:
                return None

        return result

    def is_default_geometry(
        self,
    ):
        expected = self.default_data.get("configs", {})
        current = self.get_current_geometry()
        if current is None:
            return False

        for config_name, config_data in expected.items():
            expected_geometry = config_data.get("geometry", {})
            if not expected_geometry:
                continue

            current_geometry = current.get(config_name, {})
            for key, expected_value in expected_geometry.items():
                actual_value = current_geometry.get(key)
                if key == "alignment":
                    if str(actual_value) != str(expected_value):
                        return False
                else:
                    try:
                        if float(actual_value) != float(expected_value):
                            return False
                    except (TypeError, ValueError):
                        return False

        return True

    def is_default_state(
        self,
        current_colors,
        current_scale,
    ):
        if not self.default_data:
            return False

        default_colors = self.default_data.get("colors", {})
        normalized_default_colors = {}
        for name, value in default_colors.items():
            value = str(value).strip().upper()
            if value.startswith("0X"):
                value = value[2:]
            if value.startswith("#"):
                value = value[1:]
            normalized_default_colors[name] = value

        colors_match = (
            current_colors is not None
            and current_colors == normalized_default_colors
        )

        default_scale = self.default_data.get("scale", {}).get("Scale")
        try:
            scale_match = (
                current_scale is not None
                and default_scale is not None
                and abs(float(current_scale) - float(default_scale)) < 0.0001
            )
        except (TypeError, ValueError):
            scale_match = False

        return colors_match and scale_match and self.is_default_geometry()

    # =====================================================
    # Check Changes
    # =====================================================

    def check_changes(
        self,
    ):
        current_colors = self.get_current_colors()
        current_scale = self.get_current_scale()

        colors_valid = current_colors is not None
        scale_valid = current_scale is not None

        colors_changed = (
            colors_valid
            and current_colors != self.original_colors
        )

        scale_changed = (
            scale_valid
            and current_scale != self.original_scale
        )

        values_valid = colors_valid and scale_valid
        has_changes = colors_changed or scale_changed

        self.set_apply_state(
            has_changes and values_valid
        )

        self.set_reset_state(
            not self.is_default_state(
                current_colors,
                current_scale,
            )
        )

    # =====================================================
    # Apply
    # =====================================================

    def on_apply_clicked(
        self,
        button,
    ):

        current_colors = (
            self.get_current_colors()
        )

        current_scale = (
            self.get_current_scale()
        )

        if current_colors is None:
            return

        if current_scale is None:
            return

        colors_changed = (
            current_colors
            !=
            self.original_colors
        )

        scale_changed = (
            current_scale
            !=
            self.original_scale
        )

        # =========================
        # Apply Colors
        # =========================

        if colors_changed:

            success = self.write_colors(
                current_colors
            )

            if success:

                self.original_colors = (
                    current_colors.copy()
                )

        # =========================
        # Apply Scale
        # =========================

        if scale_changed:

            scale_written = self.write_scale(
                current_scale
            )

            geometry_updated = (
                self.update_config_geometry(
                    current_scale
                )
            )

            if (
                scale_written
                and
                geometry_updated
            ):

                self.original_scale = (
                    current_scale
                )

                # Scale changes affect
                # Conky window geometry.
                # Reload active instances here.

                self.reload_active_configs()

        # =========================
        # Update Apply State
        # =========================

        self.check_changes()



        # TODO:
        #
        # COLORS:
        # - Rewrite lua/color.lua
        # - No SIGUSR1 required
        #
        # SCALE:
        # - Rewrite lua/scale.lua
        # - Rewrite related .conf files
        # - Send SIGUSR1 only to active
        #   instances of this theme

    # =====================================================
    # Reload Active Configs
    # =====================================================

    def reload_active_configs(
        self,
    ):
        for config_name in self.default_data.get(
            "configs",
            {}
        ):
            config_path = os.path.join(
                self.theme_path,
                config_name,
            )

            if not os.path.isfile(
                config_path
            ):
                continue

            try:
                result = subprocess.run(
                    [
                        "pgrep",
                        "-af",
                        "conky",
                    ],
                    capture_output=True,
                    text=True,
                    check=False,
                )

                real_path = os.path.realpath(
                    config_path
                )

                for line in result.stdout.splitlines():
                    parts = line.split(
                        None,
                        1
                    )

                    if len(parts) < 2:
                        continue

                    pid = int(parts[0])
                    command = parts[1]

                    if (
                        real_path in command
                        and pid != os.getpid()
                    ):
                        os.kill(
                            pid,
                            signal.SIGUSR1,
                        )

            except Exception as error:
                print(
                    f"Failed to reload "
                    f"{config_name}: {error}"
                )

    # =====================================================
    # Reset
    # =====================================================

    def write_default_colors(
        self,
        colors,
    ):
        color_file = os.path.join(
            self.theme_path,
            "lua",
            "color.lua",
        )

        if not os.path.isfile(
            color_file
        ):
            return False

        try:
            with open(
                color_file,
                "r",
                encoding="utf-8",
            ) as file:
                content = file.read()

            for name, value in colors.items():
                value = str(value)

                if value.lower().startswith("0x"):
                    value = value[2:]

                pattern = (
                    r"(\b"
                    + re.escape(name)
                    + r"\s*=\s*)"
                    + r"0x[0-9A-Fa-f]{6}"
                )

                replacement = (
                    r"\g<1>"
                    + f"0x{value.upper()}"
                )

                content = re.sub(
                    pattern,
                    replacement,
                    content,
                )

            with open(
                color_file,
                "w",
                encoding="utf-8",
            ) as file:
                file.write(content)

            return True

        except Exception as error:
            print(
                f"Failed to reset colors: "
                f"{error}"
            )
            return False

    def write_default_scale(
        self,
        scale_data,
    ):
        scale_file = os.path.join(
            self.theme_path,
            "lua",
            "scale.lua",
        )

        if not os.path.isfile(
            scale_file
        ):
            return False

        value = scale_data.get(
            "Scale"
        )

        if value is None:
            return False

        try:
            with open(
                scale_file,
                "r",
                encoding="utf-8",
            ) as file:
                content = file.read()

            content = re.sub(
                r"(^\s*Scale\s*=\s*)"
                r"[0-9]+(?:\.[0-9]+)?",
                r"\g<1>"
                + f"{float(value):.2f}",
                content,
                flags=re.MULTILINE,
            )

            with open(
                scale_file,
                "w",
                encoding="utf-8",
            ) as file:
                file.write(content)

            return True

        except Exception as error:
            print(
                f"Failed to reset scale: "
                f"{error}"
            )
            return False

    def write_default_geometry(
        self,
        configs,
    ):
        success = True

        for config_name, config_data in configs.items():
            geometry = config_data.get(
                "geometry",
                {}
            )

            config_path = os.path.join(
                self.theme_path,
                config_name,
            )

            if not geometry:
                continue

            if not os.path.isfile(
                config_path
            ):
                success = False
                continue

            try:
                with open(
                    config_path,
                    "r",
                    encoding="utf-8",
                ) as file:
                    content = file.read()

                for key, value in geometry.items():
                    if key == "alignment":
                        pattern = (
                            r"(^\s*alignment\s*=\s*)"
                            r"['\"][^'\"]+['\"]"
                        )
                        replacement = (
                            r"\g<1>"
                            + f"'{value}'"
                        )
                    else:
                        pattern = (
                            r"(^\s*"
                            + re.escape(key)
                            + r"\s*=\s*)"
                            + r"-?\d+(?:\.\d+)?"
                            + r"(\s*,)"
                        )
                        replacement = (
                            r"\g<1>"
                            + str(value)
                            + r"\g<2>"
                        )

                    content, count = re.subn(
                        pattern,
                        replacement,
                        content,
                        flags=re.MULTILINE,
                    )

                    if count == 0:
                        print(
                            f"Default geometry key not found "
                            f"in {config_name}: {key}"
                        )
                        success = False

                with open(
                    config_path,
                    "w",
                    encoding="utf-8",
                ) as file:
                    file.write(content)

            except Exception as error:
                print(
                    f"Failed to reset "
                    f"{config_name}: {error}"
                )
                success = False

        return success

    def update_widgets_from_default(
        self,
    ):
        colors = self.default_data.get(
            "colors",
            {}
        )

        for name, value in colors.items():
            widgets = self.color_widgets.get(
                name
            )

            if widgets is None:
                continue

            value = str(value)

            if value.lower().startswith("0x"):
                value = value[2:]

            value = value.upper()

            widgets["entry"].set_text(
                f"#{value}"
            )

            color = Gdk.RGBA()

            if color.parse(
                f"#{value}"
            ):
                widgets["button"].set_rgba(
                    color
                )

        scale = self.default_data.get(
            "scale",
            {}
        ).get(
            "Scale"
        )

        if (
            scale is not None
            and self.scale_entry is not None
        ):
            self.scale_entry.set_text(
                f"{float(scale):.2f}"
            )

        self.original_colors = (
            self.read_colors()
        )

        self.original_scale = (
            self.read_scale()
        )

    def on_reset_clicked(
        self,
        button,
    ):
        if not self.default_data:
            return

        dialog = Gtk.MessageDialog(
            transient_for=self,
            flags=Gtk.DialogFlags.MODAL,
            message_type=Gtk.MessageType.QUESTION,
            buttons=Gtk.ButtonsType.CANCEL,
            text="Reset customization?",
        )

        dialog.format_secondary_text(
            "All customized colors, scale, and geometry "
            "will be restored to the theme defaults."
        )

        dialog.add_button(
            "Reset",
            Gtk.ResponseType.OK,
        )

        response = dialog.run()
        dialog.destroy()

        if response != Gtk.ResponseType.OK:
            return

        colors = self.default_data.get(
            "colors",
            {}
        )

        scale = self.default_data.get(
            "scale",
            {}
        )

        configs = self.default_data.get(
            "configs",
            {}
        )

        colors_ok = True
        scale_ok = True
        geometry_ok = True

        if colors:
            colors_ok = self.write_default_colors(
                colors
            )

        if scale:
            scale_ok = self.write_default_scale(
                scale
            )

        if configs:
            geometry_ok = self.write_default_geometry(
                configs
            )

        self.update_widgets_from_default()

        self.apply_button.set_sensitive(
            False
        )

        if (
            scale_ok
            and geometry_ok
        ):
            self.reload_active_configs()

    # =====================================================
    # Response
    # =====================================================

    def on_response(
        self,
        dialog,
        response,
    ):

        self.destroy()
